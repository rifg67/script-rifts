---

### ⚡ **GitHub Stats**
<p align="center">
  <img src="https://github-readme-stats.vercel.app/api?username=PeyxDev&show_icons=true&theme=tokyonight&hide_border=true" alt="GitHub Stats"/>
</p>

<p align="center">
  <img src="https://github-readme-streak-stats.herokuapp.com?user=PeyxDev&theme=tokyonight&hide_border=true" alt="GitHub Streak"/>
</p>

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=PeyxDev&layout=compact&theme=tokyonight&hide_border=true" alt="Top Languages"/>
</p>

---

### 🔥 **Languages & Tools**
<p align="center">
  <img src="https://skillicons.dev/icons?i=python,js,html,css,nodejs,react,linux,vscode,github,git&theme=dark" />
</p>

---

<h3 align="center">✨ Thanks for Visiting! ✨</h3>
<p align="center">
  <img src="https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZTFkOGJkNjMyNzYwNDQxNDg0ZTNiOGI5ZWM3ZmE4YWMxMGFlNGMwNyZlcD12MV9naWZzX3NlYXJjaCZjdD1n/gf7bMpF5rTPIs/giphy.gif" width="250px" alt="Thank You Anime"/>
</p>

---

### INSTALL SCRIPT UBUNTU
<pre><code>apt install -y screen && wget -q https://raw.githubusercontent.com/rifg67/script-rifts/main/setup.sh && chmod +x setup.sh && ./setup.sh
</code></pre>

---

### INSTALL SCRIPT DEBIAN
<pre><code>apt update && apt install -y screen bsdextrautils util-linux coreutils wget curl && wget -q https://raw.githubusercontent.com/rifg67/script-rifts/main/setup.sh && chmod +x setup.sh && ./setup.sh

</code></pre>

### TESTED ON OS 
- UBUNTU 20.04 22 24.04 24.10
- DEBIAN 10 11 12


### FITUR TAMBAHAN
- Lakukan Uji Coba dengan memilih Trial Pada Licensi Key
- Tambah Swap 2 GiB
- Pemasangan yang dinamis
- Register IP Dari VPS
- Pointing Domain 
- Xray Core
- Penambahan fail2ban
- Auto block sebagian ads indo by default
- Auto clear log per 10 menit
- Auto deler expired
- User Details Akun
- Lock Xray
- Lock SSH
- Limit IP SSH on
- Limit IP Xray On
- Limit Qouta Xray On

### PORT INFO
```
- TROJAN WS 443
- TROJAN GRPC 443
- SHADOWSOCKS WS 443
- SHADOWSOCKS GRPC 443
- VLESS WS 443
- VLESS GRPC 443
- VLESS NONTLS 80
- VMESS WS 443
- VMESS GRPC 443
- VMESS NONTLS 80
- SSH WS / TLS 443
- SSH NON TLS 80 8880 8080 2080 2082 
- SLOWDNS 5300
```

### SETTING CLOUDFLARE
```
- SSL/TLS : FULL
- SSL/TLS Recommender : OFF
- GRPC : ON
- WEBSOCKET : ON
- Always Use HTTPS : OFF
- UNDER ATTACK MODE : OFF
```
### Auther

### CONTACT PX-OFFICIAL <br>
<a href="https://t.me/frel01" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br><a href="https://wa.me/6283151636921" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Whatsapp&label=Whatsapp&message=Click%20Here&color=green"></a><br>
