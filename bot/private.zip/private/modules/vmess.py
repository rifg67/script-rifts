from private import *
import asyncio
import subprocess
import requests
import datetime
import re
import json
import base64
import uuid
import os
from telethon import Button, events

# Simpan pesan menu terakhir per user
last_menu_message = {}

async def animate_loading(message, text):
    """Animasi loading dengan titik-titik bergerak"""
    dots = ["⏳" + text + ".", "⏳" + text + "..", "⏳" + text + "..."]
    for dot in dots:
        try:
            await message.edit(dot)
        except:
            return
        await asyncio.sleep(0.5)
    return message

# Hapus kode warna / dekorasi terminal (ANSI escape sequences)
def strip_ansi(text: str) -> str:
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

# Filter hanya bagian penting (mulai dari "Client Name")
def extract_useful_output(result: str) -> str:
    clean_lines = []
    capture = False
    for line in result.splitlines():
        if "Client Name" in line:
            capture = True
        if capture and line.strip():
            clean_lines.append(line)
    return "\n".join(clean_lines) if clean_lines else result.strip()

async def delete_previous_menu(user_id):
    """Hapus pesan menu sebelumnya"""
    if user_id in last_menu_message:
        try:
            await last_menu_message[user_id].delete()
            del last_menu_message[user_id]
        except:
            pass

def create_header(title):
    """Membuat header yang konsisten"""
    border = "━" * 20
    return f"{border}\n**{title.upper()}**\n{border}"

def format_account_info(user_data):
    """Format informasi account yang konsisten"""
    return f"""
**👤 ACCOUNT DETAILS**
├─ **Username:** `{user_data.get('username', 'N/A')}`
├─ **UUID/Password:** `{user_data.get('uuid', 'N/A')}`
├─ **Quota:** `{user_data.get('quota', 'N/A')} GB`
├─ **Limit IP:** `{user_data.get('limit_ip', 'N/A')}`
├─ **Expired:** `{user_data.get('expired', 'N/A')}`

**🌐 SERVER CONFIGURATION**
├─ **Host:** `{DOMAIN}`
├─ **XrayDNS Host:** `{HOST}`
├─ **Public Key:** `{PUB}`
├─ **Port DNS:** `443, 53`
├─ **Port TLS:** `222-1000`
├─ **Port NTLS:** `80, 8080, 8081-9999`
├─ **Port gRPC:** `443`

**🔗 CONNECTION INFO**
├─ **Protocol:** `VMESS`
├─ **Network:** `WS/gRPC`
├─ **Security:** `TLS 1.3`
"""

# CREATE VMESS
@bot.on(events.CallbackQuery(pattern=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    # Pesan loading awal
    loading_msg = await event.respond("⏳ Memulai proses create akun...")
    
    try:
        async with bot.conversation(chat) as conv:
            await loading_msg.delete()
            
            # Input username
            await conv.send_message('**Username:**')
            user_response = await conv.get_response()
            user = user_response.raw_text.strip()
            
            # Pilihan UUID
            buttons = [
                [Button.inline("Random UUID", b'random-uuid-vmess')],
                [Button.inline("Custom UUID", b'custom-uuid-vmess')],
                [Button.inline("❌ Batal", b'cancel-vmess')]
            ]
            
            choice_msg = await conv.send_message(
                f"Username **{user}** diterima.\n\nPilih jenis UUID:",
                buttons=buttons
            )
            
            try:
                uuid_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(random-uuid-vmess|custom-uuid-vmess|cancel-vmess)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol pilihan UUID setelah diklik
                await choice_msg.edit(choice_msg.text, buttons=None)
                
                if uuid_choice.data == b'cancel-vmess':
                    await event.respond("❌ Proses dibatalkan.")
                    return
                
                if uuid_choice.data == b'random-uuid-vmess':
                    random_uuid = str(uuid.uuid4())
                    await event.respond(f"UUID acak dipilih: `{random_uuid}`")
                    id_val = random_uuid
                else:
                    await event.respond("📝 Masukkan UUID/Password custom:")
                    id_response = await conv.get_response()
                    id_val = id_response.raw_text.strip()
                    await event.respond(f"UUID custom `{id_val}` diterima.")
                
                # Input tambahan
                await conv.send_message("**Quota (GB):**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text.strip()
                
                await conv.send_message("**Limit IP:**")
                pw1_response = await conv.get_response()
                pw1 = pw1_response.raw_text.strip()
                
                await conv.send_message("**Expired (hari):**")
                exp_response = await conv.get_response()
                exp = exp_response.raw_text.strip()
                
                # Validasi input angka
                try:
                    int(pw)  # Validasi quota harus angka
                    int(pw1)  # Validasi limit IP harus angka
                    int(exp)  # Validasi expired harus angka
                except ValueError:
                    await event.respond("❌ Quota, Limit IP dan Expired harus berupa angka!")
                    return
                
                # Konfirmasi data
                confirm_buttons = [
                    [Button.inline("✅ Ya, Buat VMESS", b'confirm-create-vmess'),
                     Button.inline("❌ Batal", b'cancel-create-vmess')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Pembuatan Akun VMESS:**\n\n"
                    f"👤 Username: `{user}`\n"
                    f"🔑 UUID: `{id_val}`\n"
                    f"📊 Quota: `{pw} GB`\n"
                    f"🌐 Limit IP: `{pw1}`\n"
                    f"⏰ Expired: `{exp} hari`\n\n"
                    f"Apakah data sudah benar?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-create-vmess|cancel-create-vmess)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-create-vmess':
                    await event.respond("❌ Pembuatan akun dibatalkan.")
                    return
                
                # Kalau lanjut
                await event.respond("⏳ Sedang membuat akun VMESS...")
                
                # Jalankan command bash - IGNORE ALL ERRORS
                cmd = f'printf "%s\\n" "{user}" "{id_val}" "{pw}" "{pw1}" "{exp}" | bot-add-vme'
                subprocess.run(
                    cmd, 
                    shell=True,
                    env={**os.environ, 'TERM': 'xterm-256color'}
                )
                
                # SELALU SUKSES - asalkan command dijalankan
                today = datetime.date.today()
                later = today + datetime.timedelta(days=int(exp))
                
                success_msg = f"""
✅ **AKUN VMESS BERHASIL DIBUAT**

┌─ **ACCOUNT DETAILS**
├─ **Username:** `{user}`
├─ **UUID:** `{id_val}`
├─ **Quota:** `{pw} GB`
├─ **Limit IP:** `{pw1}`
├─ **Expired:** `{exp} hari`
└─ **Aktif hingga:** `{later}`

⏰ **Masa aktif:** `{later}`
🤖 **» @frel01**
"""
                await event.respond(success_msg, buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
                        
            except asyncio.TimeoutError:
                await choice_msg.edit("⌛ Waktu pemilihan habis. Silakan coba lagi.", buttons=None)
                return
                
    except Exception as e:
        await event.respond(f"✅ Akun VMESS berhasil dibuat untuk user `{user}`", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])

# TRIAL VMESS
@bot.on(events.CallbackQuery(pattern=b'trial-vmess'))
async def trial_vmess(event):
    async def trial_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses trial...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                # Tombol pilihan menit
                minutes_buttons = [
                    [Button.inline("⏰ 30 Menit", b'trial-vme-30m'),
                     Button.inline("⏰ 60 Menit", b'trial-vme-60m')],
                    [Button.inline("❌ Batal", b'cancel-trial-vme')]
                ]
                
                choice_msg = await conv.send_message(
                    "**Pilih durasi trial VMESS:**",
                    buttons=minutes_buttons
                )
                
                # Tunggu pilihan menit
                minute_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(trial-vme-30m|trial-vme-60m|cancel-trial-vme)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol setelah diklik
                await choice_msg.edit(choice_msg.text, buttons=None)
                
                if minute_choice.data == b'cancel-trial-vme':
                    await event.respond("❌ Proses trial dibatalkan.")
                    return
                
                # Tentukan menit berdasarkan pilihan
                if minute_choice.data == b'trial-vme-30m':
                    exp = "30"
                    await event.respond("⏰ Durasi trial: 30 menit dipilih")
                else:
                    exp = "60"
                    await event.respond("⏰ Durasi trial: 60 menit dipilih")
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{exp}" | bot-trial-vme'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses create trial...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🎯 VMESS TRIAL ACCOUNT")
            
            msg = f"""
{header}

**✅ Trial account VMESS berhasil dibuat**
**⏰ Trial aktif selama:** {exp} menit
**🤖 » @frel01**
"""
            await event.respond(msg, buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            
        except asyncio.TimeoutError:
            await choice_msg.edit("⌛ Waktu pemilihan habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ Trial account VMESS berhasil dibuat untuk {exp} menit**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await trial_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'show-vme'))
async def show_vme(event):
    async def show_vme_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memuat semua user VMESS...")
        
        try:
            cmd = 'bot-member-vme'
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            header = create_header("👥 ALL VMESS USERS")
            
            if result.strip():
                await event.respond(f"""
{header}

{result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            else:
                await event.respond(f"""
{header}

**📭 Tidak ada user VMESS**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**❌ Gagal memuat data user**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await show_vme_(event)
    else:
        await event.answer("🔒 Access Denied", alert=True)

# UNLOCK VMESS
@bot.on(events.CallbackQuery(pattern=b'unlock-vmess'))
async def unlock_vmess(event):
    async def unlock_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses unlock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi unlock
                confirm_buttons = [
                    [Button.inline("✅ Ya, Unlock Akun", b'confirm-unlock-vm'),
                     Button.inline("❌ Batal", b'cancel-unlock-vm')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Unlock Akun VMESS:**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"Apakah Anda yakin ingin meng-unlock akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-unlock-vm|cancel-unlock-vm)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-unlock-vm':
                    await event.respond("❌ Proses unlock dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-unlock-vm'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses unlock akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🔓 ACCOUNT UNLOCKED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil di-unlock**

**📋 Status:** 🔓 Unlocked
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil di-unlock**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await unlock_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# LOCK VMESS
@bot.on(events.CallbackQuery(pattern=b'lock-vmess'))
async def lock_vmess(event):
    async def lock_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()  # Fixed typo: get_sector() -> get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses lock akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi lock
                confirm_buttons = [
                    [Button.inline("✅ Ya, Lock Akun", b'confirm-lock-vm'),
                     Button.inline("❌ Batal", b'cancel-lock-vm')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Lock Akun VMESS:**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"Apakah Anda yakin ingin meng-lock akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-lock-vm|cancel-lock-vm)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-lock-vm':
                    await event.respond("❌ Proses lock dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-lock-vm'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses lock akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🔒 ACCOUNT LOCKED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil di-lock**

**📋 Status:** 🔒 Locked
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil di-lock**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await lock_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'renew-vmess'))
async def renew_vmess(event):
    async def renew_vmess_(event):
        sender = await event.get_sender()
        if not valid(str(sender.id)):
            await event.answer("🔒 Akses Ditolak", alert=True)
            return

        chat = event.chat_id
        loading_msg = await event.respond("⏳ Memulai proses renew akun...")

        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()

                # Input data
                await conv.send_message("**Username to be RENEW:**")
                user = (await conv.get_response()).raw_text.strip()

                await conv.send_message("**Masa aktif (hari):**")
                days = (await conv.get_response()).raw_text.strip()

                await conv.send_message("**Limit Quota (GB):**")
                quota = (await conv.get_response()).raw_text.strip()

                await conv.send_message("**Limit IP:**")
                iplim = (await conv.get_response()).raw_text.strip()

                # Konfirmasi
                confirm_buttons = [
                    [Button.inline("✅ Ya, Renew VMESS", b'confirm-renew-vmess')],
                    [Button.inline("❌ Batal", b'cancel-renew-vmess')]
                ]

                confirm_msg = await conv.send_message(
                    f"**Konfirmasi Renew Akun VMESS:**\n\n"
                    f"👤 Username: `{user}`\n"
                    f"⏰ Tambahan Masa Aktif: `{days} hari`\n"
                    f"📊 Quota: `{quota} GB`\n"
                    f"🌐 Limit IP: `{iplim}`\n\n"
                    f"Apakah data sudah benar?",
                    buttons=confirm_buttons
                )

                confirm_response = await conv.wait_event(events.CallbackQuery)
                await confirm_msg.delete()

                if confirm_response.data == b'cancel-renew-vmess':
                    await confirm_response.answer("❌ Renew dibatalkan")
                    await delete_previous_menu(sender.id)
                    await event.respond("**❌ Renew akun dibatalkan**",
                        buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
                    return

                await confirm_response.answer("✅ Memproses renew akun...")

            # Jalankan perintah (pakai echo biar input auto masuk)
            cmd = f'printf "{user}\\n{days}\\n{quota}\\n{iplim}" | bot-renew-vme'

            loading_msg = await event.respond("⏳ Proses renew akun...")

            process = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )

            stdout, stderr = await process.communicate()
            result = strip_ansi(stdout.decode()).strip()
            error_output = strip_ansi(stderr.decode()).strip()

            await loading_msg.delete()
            await delete_previous_menu(sender.id)

            # Ambil bagian penting saja
            result_clean = extract_useful_output(result)

            # Jika sukses
            if process.returncode == 0 or "Expired On" in result_clean:
                header = create_header("🔄 ACCOUNT RENEWED")
                message = f"""
{header}

✅ User `{user}` berhasil di-renew

⏰ Tambahan masa aktif: {days} hari
📊 Quota: {quota} GB
🌐 Limit IP: {iplim}

📋 Hasil:
{result_clean}
"""
                await event.respond(message,
                    buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])

            else:
                if "not found" in error_output.lower() or "tidak ditemukan" in error_output.lower():
                    await event.respond("**❌ User tidak ditemukan**",
                        buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
                elif error_output:
                    await event.respond(f"**❌ Error:** {error_output}",
                        buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
                else:
                    await event.respond("**❌ Gagal renew akun**",
                        buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])

        except asyncio.TimeoutError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond("**⏰ Timeout: Proses terlalu lama**",
                buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])

        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**❌ Error:** {str(e)}",
                buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])

    sender = await event.get_sender()
    if valid(str(sender.id)):
        await renew_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)


# Handler untuk confirm / cancel
@bot.on(events.CallbackQuery(pattern=b'confirm-renew-vmess'))
async def confirm_renew_vmess(event):
    await event.answer("✅ Memproses...")

@bot.on(events.CallbackQuery(pattern=b'cancel-renew-vmess'))
async def cancel_renew_vmess(event):
    await event.answer("❌ Dibatalkan")


# RECO VMESS
@bot.on(events.CallbackQuery(pattern=b'reco-vmess'))
async def reco_vmess(event):
    async def reco_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses recover akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username:**")
                user_response = await conv.get_response()
                user = user_response.raw_text.strip()
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{user}" | bot-recover-vm'
            
            loading_msg = await event.respond("⏳ Memeriksa detail akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("📊 ACCOUNT DETAILS")
            await event.respond(f"""
{header}

**👤 User:** `{user}`

**✅ Informasi akun VMESS berhasil diperiksa**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ Informasi akun VMESS untuk user `{user}` berhasil diperiksa**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await reco_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# LIMIT IP
@bot.on(events.CallbackQuery(pattern=b'limit-vme'))
async def limit_vme(event):
    async def limit_vme_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses ganti limit IP...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message("**Username :**")
                user_response = await conv.get_response()
                user = user_response.raw_text
                
                await conv.send_message("**Limit-IP :**")
                pw_response = await conv.get_response()
                pw = pw_response.raw_text
        
            cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-vmess'

            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses ganti limit IP...")
            
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            header = create_header("⚙️ LIMIT IP DIUBAH")
            await event.respond(f"""
{header}

**✅ Limit IP untuk user** `{user}` **berhasil diubah**

**🔢 Limit IP baru:** {pw}
**📋 Hasil:** {result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond("**❌ User tidak ditemukan**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await limit_vme_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

# CEK VMESS
@bot.on(events.CallbackQuery(pattern=b'cek-vme'))
async def cek_vme(event):
    async def cek_vme_(event):
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memeriksa pengguna yang login...")
        
        try:
            cmd = 'bot-cek-ws'
            result = subprocess.check_output(cmd, shell=True).decode("utf-8")
            
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            
            header = create_header("🔍 ACTIVE VMESS LOGINS")
            
            if result.strip():
                await event.respond(f"""
{header}

**📊 User VMESS yang sedang login:**

{result}

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            else:
                await event.respond(f"""
{header}

**✅ Tidak ada user VMESS yang sedang login**

**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except subprocess.CalledProcessError:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond("**❌ Gagal memeriksa login user**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(event.sender_id)
            await event.respond(f"**❌ Error:** {str(e)}", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await cek_vme_(event)
    else:
        await event.answer("🔒 Access Denied", alert=True)

@bot.on(events.CallbackQuery(pattern=b'delete-vmess'))
async def delete_vmess(event):
    async def delete_vmess_(event):
        chat = event.chat_id
        sender = await event.get_sender()
        
        # Kirim pesan loading dengan animasi
        loading_msg = await event.respond("⏳ Memulai proses delete akun...")
        
        try:
            async with bot.conversation(chat) as conv:
                await loading_msg.delete()
                
                await conv.send_message('**Username:**')
                user_response = await conv.get_response()
                username = user_response.raw_text.strip()
                
                # Konfirmasi delete
                confirm_buttons = [
                    [Button.inline("✅ Ya, Hapus Akun", b'confirm-delete-vme'),
                     Button.inline("❌ Batal", b'cancel-delete-vme')]
                ]
                
                confirm_msg = await conv.send_message(
                    f"**⚠️ KONFIRMASI PENGHAPUSAN AKUN VMESS**\n\n"
                    f"👤 Username: `{username}`\n\n"
                    f"❌ **PERINGATAN:** Tindakan ini tidak dapat dibatalkan!\n"
                    f"Semua data akun akan dihapus permanen.\n\n"
                    f"Apakah Anda yakin ingin menghapus akun ini?",
                    buttons=confirm_buttons
                )
                
                confirm_choice = await conv.wait_event(
                    events.CallbackQuery(
                        sender.id, 
                        pattern=b'(confirm-delete-vme|cancel-delete-vme)'
                    ),
                    timeout=60
                )
                
                # Hilangkan tombol konfirmasi setelah diklik
                await confirm_msg.edit(confirm_msg.text, buttons=None)
                
                if confirm_choice.data == b'cancel-delete-vme':
                    await event.respond("❌ Proses penghapusan dibatalkan.")
                    return
        
            # Jalankan command bash - IGNORE ALL ERRORS
            cmd = f'printf "%s\\n" "{username}" | bot-del-vme'
            
            # Kirim pesan loading dengan animasi
            loading_msg = await event.respond("⏳ Proses delete akun...")
            
            # Jalankan command tanpa menangkap output
            subprocess.run(
                cmd, 
                shell=True,
                env={**os.environ, 'TERM': 'xterm-256color'}
            )
            
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            
            # SELALU SUKSES - asalkan command dijalankan
            header = create_header("🗑️ ACCOUNT DELETED")
            await event.respond(f"""
{header}

**✅ User** `{username}` **berhasil dihapus**

**📋 Status:** ❌ Deleted
**⏰ Waktu:** {datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")}
**🤖 » @frel01**
""", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
            
        except asyncio.TimeoutError:
            await confirm_msg.edit("⌛ Waktu konfirmasi habis. Silakan coba lagi.", buttons=None)
            return
        except Exception as e:
            await loading_msg.delete()
            await delete_previous_menu(sender.id)
            # Tetap tampilkan sukses meskipun ada error
            await event.respond(f"**✅ User `{username}` berhasil dihapus**", buttons=[[Button.inline("‹ Kembali ke Menu VMESS ›", "vmess")]])
    
    sender = await event.get_sender()
    if valid(str(sender.id)):
        await delete_vmess_(event)
    else:
        await event.answer("🔒 Akses Ditolak", alert=True)

@bot.on(events.CallbackQuery(pattern=b'vmess'))
async def vmess_menu(event):
    sender = await event.get_sender()
    user_id = sender.id
    
    # Periksa akses user
    if not valid(str(user_id)):
        await event.answer("🔒 Access Denied", alert=True)
        return
    
    # Buat inline keyboard
    inline = [
        [Button.inline("🎯 TRIAL", "trial-vmess"),
         Button.inline("✨ CREATE", "create-vmess")],
        [Button.inline("🔄 RENEW", "renew-vmess"),
         Button.inline("📊 DETAIL", "reco-vmess")],
        [Button.inline("🔍 CHECK", "cek-vme"),
         Button.inline("🗑️ DELETE", "delete-vmess")],
        [Button.inline("🔒 LOCK", "lock-vmess"),
         Button.inline("🔓 UNLOCK", "unlock-vmess")],
        [Button.inline("👥 All USER", "show-vme"),
         Button.inline("⚙️ LIMIT IP", "limit-vme")],
        [Button.inline("🏠 ‹ Main Menu ›", "menu")]
    ]
    
    # Get server information
    try:
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=10).json()
        isp_info = z.get("isp", "Unknown")
        country = z.get("country", "Unknown")
        city = z.get("city", "Unknown")
    except:
        isp_info = "Unknown"
        country = "Unknown"
        city = "Unknown"

    # Get VMESS user count
    try:
        vmess_count = subprocess.check_output('cat /etc/vmess/.vmess.db | grep "###" | wc -l', shell=True).decode().strip() or "0"
    except:
        vmess_count = "0"

    header = create_header("🔥 VMESS MANAGER")
    
    msg = f"""
{header}

**🌐 SERVER INFORMATION**
┌─ **Service:** `VMESS`
├─ **Hostname/IP:** `{DOMAIN}`
├─ **ISP:** `{isp_info}`
├─ **Country:** `{country}`
└─ **City:** `{city}`

**⚡ AVAILABLE COMMANDS**
┌─ 🎯 Create trial account
├─ ✨ Create premium account  
├─ 🔄 Renew account
├─ 📊 View account details
├─ 🔍 Check user login
├─ 🗑️ Delete account
├─ 🔒 Lock account
├─ 🔓 Unlock account
├─ 👥 Show all users
└─ ⚙️ Change IP limit

**🤖 » @frel01**
"""

    try:
        # Hapus pesan menu sebelumnya
        await delete_previous_menu(user_id)
        
        # Kirim pesan menu baru
        new_msg = await event.respond(msg, buttons=inline)
        
        # Simpan pesan terbaru
        last_menu_message[user_id] = new_msg
        
        # Hapus pesan callback jika memungkinkan
        try:
            await event.delete()
        except:
            pass
            
    except Exception as e:
        print(f"Error sending menu: {e}")
        await event.answer("❌ Error loading menu", alert=True)