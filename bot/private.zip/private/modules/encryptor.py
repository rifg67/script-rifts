from private import *
import asyncio
import os
import secrets
import subprocess
import tempfile
from telethon import Button, events
from telethon.tl.types import DocumentAttributeFilename

# ============================================================
# Module: Encrypt / Decrypt Script (AES-256, via openssl)
#
# Dipakai buat nge-enkripsi setup.sh / update.sh sebelum di-push
# ke GitHub publik, dan buat ngedekripsi balik kalau diperlukan.
# File .enc yang keluar itu binary -- nggak kebaca sampai ada
# password yang benar.
#
# CATATAN KEAMANAN:
# - Password yang diketik user di chat otomatis dihapus pesannya
#   (best effort) begitu bot sudah membacanya.
# - File plaintext (.sh) dan file enkripsi sementara selalu dihapus
#   dari disk VPS setelah dikirim ke Telegram -- tidak pernah
#   disimpan permanen di server.
# - Modul ini otomatis ter-proteksi gerbang admin global di
#   private/__init__.py (_global_admin_gate), jadi hanya admin
#   terdaftar di tabel `admin` yang bisa memicunya.
# ============================================================

OPENSSL_ITER = 200000


async def _run_openssl(args: list, input_path: str, output_path: str):
    """Jalankan openssl enc, return (ok, stderr_text)."""
    cmd = ["openssl", "enc"] + args + ["-in", input_path, "-out", output_path]
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    return proc.returncode == 0, stderr.decode(errors="ignore").strip()


def _safe_remove(*paths):
    for p in paths:
        try:
            if p and os.path.exists(p):
                os.remove(p)
        except Exception:
            pass


async def _ask_password(conv, prompt: str):
    """Minta password sekali, lalu hapus pesan user dari chat (best effort)."""
    await conv.send_message(prompt)
    resp = await conv.get_response()
    pw = resp.raw_text.strip()
    try:
        await resp.delete()
    except Exception:
        pass
    return pw


@bot.on(events.NewMessage(pattern=r"(?:\.encrypt|/encrypt)$"))
@bot.on(events.CallbackQuery(data=b"encrypt_script"))
async def cmd_encrypt(event):
    if valid(str(event.sender_id)) != "true":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except Exception:
            await event.reply("Akses Ditolak")
        return

    chat = event.chat_id
    workdir = tempfile.mkdtemp(prefix="enc_")
    in_path = out_path = None
    try:
        async with bot.conversation(chat, timeout=300) as conv:
            await conv.send_message(
                "📤 Kirim file `.sh` yang mau dienkripsi (sebagai dokumen/file)."
            )
            file_msg = await conv.wait_event(
                events.NewMessage(func=lambda e: e.chat_id == chat and e.document)
            )
            orig_name = file_msg.file.name or "script.sh"
            in_path = os.path.join(workdir, orig_name)
            await file_msg.download_media(file=in_path)

            pw = await _ask_password(
                conv, "🔑 Ketik password enkripsi.\n(Pesan ini akan otomatis dihapus setelah dibaca.)"
            )
            pw2 = await _ask_password(conv, "🔑 Ulangi password yang sama untuk konfirmasi:")

            if not pw or pw != pw2:
                await conv.send_message("❌ Password kosong atau tidak cocok. Dibatalkan.")
                return

            out_path = os.path.join(workdir, "out.bin")  # nama internal, tidak dikirim ke user
            ok, err = await _run_openssl(
                ["-aes-256-cbc", "-pbkdf2", "-iter", str(OPENSSL_ITER), "-salt", "-k", pw],
                in_path, out_path,
            )
            del pw, pw2  # keluar dari scope sesegera mungkin

            if not ok:
                await conv.send_message(f"❌ Enkripsi gagal: `{err or 'unknown error'}`")
                return

            await conv.send_file(
                out_path,
                attributes=[DocumentAttributeFilename(orig_name)],  # nama/ekstensi tetap sama persis
                caption=(
                    f"✅ **{orig_name}** (sudah dienkripsi)\n\n"
                    "File ini aman di-upload ke GitHub publik — tanpa password yang benar, "
                    "isinya tidak bisa dibaca atau dijalankan.\n"
                    "Simpan password-nya baik-baik, tidak ada cara mengulang kalau lupa."
                ),
            )
    except asyncio.TimeoutError:
        try:
            await bot.send_message(chat, "⏱️ Waktu habis, proses dibatalkan.")
        except Exception:
            pass
    except Exception as e:
        try:
            await bot.send_message(chat, f"⚠️ Terjadi error tak terduga: `{type(e).__name__}: {e}`")
        except Exception:
            pass
    finally:
        _safe_remove(in_path, out_path)
        try:
            os.rmdir(workdir)
        except Exception:
            pass


@bot.on(events.NewMessage(pattern=r"(?:\.decrypt|/decrypt)$"))
@bot.on(events.CallbackQuery(data=b"decrypt_script"))
async def cmd_decrypt(event):
    if valid(str(event.sender_id)) != "true":
        try:
            await event.answer("Akses Ditolak", alert=True)
        except Exception:
            await event.reply("Akses Ditolak")
        return

    chat = event.chat_id
    workdir = tempfile.mkdtemp(prefix="dec_")
    in_path = out_path = None
    try:
        async with bot.conversation(chat, timeout=300) as conv:
            await conv.send_message("📤 Kirim file `.enc` yang mau didekripsi.")
            file_msg = await conv.wait_event(
                events.NewMessage(func=lambda e: e.chat_id == chat and e.document)
            )
            orig_name = file_msg.file.name or "file.enc"
            in_path = os.path.join(workdir, orig_name)
            await file_msg.download_media(file=in_path)

            pw = await _ask_password(
                conv, "🔑 Ketik password dekripsi.\n(Pesan ini akan otomatis dihapus setelah dibaca.)"
            )

            out_path = os.path.join(workdir, "out.bin")  # nama internal, tidak dikirim ke user
            ok, err = await _run_openssl(
                ["-d", "-aes-256-cbc", "-pbkdf2", "-iter", str(OPENSSL_ITER), "-k", pw],
                in_path, out_path,
            )
            del pw

            if not ok:
                await conv.send_message(
                    "❌ Gagal dekripsi. Password salah, atau file rusak/korup.\n"
                    f"`{err or ''}`"
                )
                return

            await conv.send_file(
                out_path,
                attributes=[DocumentAttributeFilename(orig_name)],  # nama/ekstensi tetap sama persis
                caption=(
                    f"✅ **{orig_name}**\n\n"
                    "⚠️ Ini isi asli (plaintext). Jangan diteruskan ke orang lain / "
                    "jangan di-upload ke repo publik."
                ),
            )
    except asyncio.TimeoutError:
        try:
            await bot.send_message(chat, "⏱️ Waktu habis, proses dibatalkan.")
        except Exception:
            pass
    except Exception as e:
        try:
            await bot.send_message(chat, f"⚠️ Terjadi error tak terduga: `{type(e).__name__}: {e}`")
        except Exception:
            pass
    finally:
        _safe_remove(in_path, out_path)
        try:
            os.rmdir(workdir)
        except Exception:
            pass
