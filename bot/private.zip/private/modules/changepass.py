from private import *
import asyncio
import subprocess
import secrets
import string
import datetime as DT
from telethon import Button, events

# Module: Ganti Password Root VPS via Bot Telegram
# Hanya admin terdaftar (valid()) yang bisa akses fitur ini.
# Alur: tombol "GANTI PASSWORD" -> konfirmasi (Ya/Tidak) -> generate password acak
#       -> apply ke sistem (chpasswd) -> kirim password baru ke admin yang request.

def generate_strong_password(length: int = 16) -> str:
    """Generate password acak yang kuat (huruf besar, kecil, angka, simbol aman)"""
    alphabet = string.ascii_letters + string.digits + "!@#%^&*-_="
    # pakai secrets (bukan random biasa) supaya cryptographically secure, gak gampang ditebak
    return ''.join(secrets.choice(alphabet) for _ in range(length))


async def run_cmd(cmd: str, timeout: int = 30):
    """Jalankan command shell, return (success, output)"""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout
        )
        return result.returncode == 0, (result.stdout.strip() or result.stderr.strip())
    except subprocess.TimeoutExpired:
        return False, "Command timed out"
    except Exception as e:
        return False, str(e)


class ChangePasswordHandler:
    def __init__(self):
        self.bot = bot
        self.setup_handlers()

    def setup_handlers(self):
        self.bot.on(events.CallbackQuery(pattern=r'^changepass$'))(self.cb_changepass)
        self.bot.on(events.CallbackQuery(pattern=r'^confirm_changepass$'))(self.cb_confirm_changepass)

    async def cb_changepass(self, event):
        """Tombol awal: minta konfirmasi sebelum ganti password root"""
        # FIX KEAMANAN: cek admin SEBELUM menampilkan apapun, bukan setelah konfirmasi
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return

        confirm = await event.respond(
            "⚠️ **KONFIRMASI GANTI PASSWORD ROOT VPS**\n\n"
            "Password root VPS akan diganti dengan password acak baru.\n"
            "Sesi SSH yang sedang aktif TIDAK akan langsung terputus, "
            "tapi login berikutnya wajib pakai password baru.\n\n"
            "Lanjutkan?",
            buttons=[
                [Button.inline("✅ Ya, Ganti Sekarang", "confirm_changepass")],
                [Button.inline("❌ Batal", "menu")]
            ]
        )

        try:
            response = await self.bot.wait_for(
                events.CallbackQuery(from_users=event.sender_id),
                timeout=30
            )
            if response.data == b'menu':
                await confirm.delete()
        except asyncio.TimeoutError:
            await confirm.delete()
            await event.respond("⏰ Waktu konfirmasi habis. Password TIDAK diubah.",
                                 buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

    async def cb_confirm_changepass(self, event):
        """Eksekusi ganti password setelah dikonfirmasi"""
        # FIX KEAMANAN: cek admin LAGI di sini (defense in depth), jangan percaya step sebelumnya saja
        if valid(str(event.sender_id)) != "true":
            await event.answer("Access Denied", alert=True)
            return

        loading_msg = await event.respond("⏳ Mengganti password root...")

        new_password = generate_strong_password(16)

        # chpasswd lebih aman dari segi shell-escaping dibanding `passwd` dengan echo pipe,
        # karena password tidak pernah lewat sebagai argumen command line (tidak masuk ke /proc atau history)
        success, output = await run_cmd(
            f"echo 'root:{new_password}' | chpasswd"
        )

        await loading_msg.delete()

        if not success:
            await event.respond(
                f"❌ **GAGAL mengganti password**\nError: `{output}`\n\n"
                "Password root TIDAK berubah.",
                buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
            )
            return

        timestamp = DT.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        requester = event.sender_id

        # Kirim password baru HANYA ke admin yang melakukan request (private message),
        # bukan broadcast ke semua admin/channel, supaya tidak ada jejak password di tempat lain
        await event.respond(
            "✅ **PASSWORD ROOT BERHASIL DIGANTI**\n\n"
            f"**» Password Baru :** `{new_password}`\n"
            f"**» Diganti oleh  :** `{requester}`\n"
            f"**» Waktu         :** `{timestamp}`\n\n"
            "⚠️ Simpan password ini sekarang. Pesan ini sebaiknya dihapus setelah dicatat.",
            buttons=[[Button.inline("‹ Main Menu ›", "menu")]]
        )

        # Catat log lokal di VPS untuk jejak audit (siapa ganti password, kapan)
        # supaya kalau ada penyalahgunaan, ada riwayat yang bisa dicek manual dari VPS
        try:
            with open("/var/log/bot-password-changes.log", "a") as f:
                f.write(f"{timestamp} | changed_by_telegram_id={requester}\n")
        except Exception:
            pass  # logging gagal tidak boleh membatalkan proses ganti password yang sudah berhasil


# Initialize handler
changepass_handler = ChangePasswordHandler()
