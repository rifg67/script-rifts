from private import *
import asyncio
import json
import os
import stat
import requests
from telethon import Button, events

# ============================================================
# Module: Cloudflare for SaaS - Auto Add Custom Hostname + DNS Pointing
# ============================================================
# Alur: Tombol "ADD BUG" -> (kalau belum ada token) bot tanya CF API Token
#       & Zone ID sekali -> simpan ke file config lokal -> tanya nama bug
#       -> tanya IP VPS -> eksekusi 3 step API ke Cloudflare -> kirim hasil
#
# PENTING: Token & Zone ID TIDAK ditulis langsung di file ini. Tiap server
# yang install bot ini akan punya token Cloudflare-nya SENDIRI, disimpan di
# CF_CONFIG_PATH (chmod 600, hanya bisa dibaca root). Ini supaya kalau file
# .py ini ikut kebawa/keshare, akun Cloudflare pemilik bot tidak otomatis
# bisa diakses orang lain.
#
# Command teks /addbug [nama_bug] [ip_vps] tetap bisa dipakai juga
# kalau mau langsung satu baris tanpa tanya-jawab (token tetap wajib
# sudah pernah diisi sebelumnya lewat alur tombol).
# ============================================================

CF_CONFIG_PATH = "/usr/bin/private/cf_config.json"
CF_BASE_URL = "https://api.cloudflare.com/client/v4"


def load_cf_config():
    """Baca token & zone id milik server ini dari file config lokal.
    Return dict {"token":..., "zone_id":...} atau None kalau belum diisi."""
    try:
        with open(CF_CONFIG_PATH, "r") as f:
            data = json.load(f)
        if data.get("token") and data.get("zone_id"):
            return data
        return None
    except Exception:
        return None


def save_cf_config(token: str, zone_id: str):
    """Simpan token & zone id ke file lokal, permission 600 (cuma owner/root
    yang bisa baca) supaya tidak gampang dibaca user lain di server yang sama."""
    data = {"token": token.strip(), "zone_id": zone_id.strip()}
    with open(CF_CONFIG_PATH, "w") as f:
        json.dump(data, f)
    try:
        os.chmod(CF_CONFIG_PATH, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except Exception:
        pass


def cf_headers(token: str):
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }


def cf_add_custom_hostname(hostname: str, token: str, zone_id: str):
    """Step 1: Tambah Custom Hostname ke Cloudflare for SaaS"""
    url = f"{CF_BASE_URL}/zones/{zone_id}/custom_hostnames"
    payload = {
        "hostname": hostname,
        "ssl": {
            "method": "txt",
            "type": "dv",
            "settings": {
                "min_tls_version": "1.0"
            }
        }
    }
    try:
        resp = requests.post(url, headers=cf_headers(token), json=payload, timeout=20)
        data = resp.json()
        return resp.status_code, data
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def cf_get_custom_hostname(hostname_id: str, token: str, zone_id: str):
    """GET ulang detail custom hostname. Dipakai untuk retry mengambil
    ssl.validation_records, karena response POST awal sering BELUM
    menyertakan data ini (perlu jeda beberapa detik dulu)."""
    url = f"{CF_BASE_URL}/zones/{zone_id}/custom_hostnames/{hostname_id}"
    try:
        resp = requests.get(url, headers=cf_headers(token), timeout=20)
        data = resp.json()
        return resp.status_code, data
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def cf_add_dns_record(record_type: str, name: str, content: str, token: str, zone_id: str, proxied: bool = False, ttl: int = 1):
    """Step 2 & 3: Tambah DNS record (TXT atau A) ke zone Cloudflare"""
    url = f"{CF_BASE_URL}/zones/{zone_id}/dns_records"
    payload = {
        "type": record_type,
        "name": name,
        "content": content,
        "ttl": ttl,
        "proxied": proxied
    }
    try:
        resp = requests.post(url, headers=cf_headers(token), json=payload, timeout=20)
        data = resp.json()
        return resp.status_code, data
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def extract_all_ssl_validation_txt(custom_hostname_response: dict):
    """
    Ekstrak SEMUA Name & Value dari ssl.validation_records.

    PENTING: Cloudflare dashboard mengonfirmasi bahwa SEMUA entry di
    validation_records (termasuk yang Name-nya sama tapi Value beda) memang
    perlu dipasang semua ke DNS -- ini BUKAN duplikat/token basi, melainkan
    beberapa Certificate Authority yang masing-masing butuh TXT validation
    sendiri. Jangan filter berdasar status, ambil semua pasangan (name, value)
    yang unik.
    """
    records = []
    try:
        result = custom_hostname_response.get("result", {})
        ssl_info = result.get("ssl", {})
        validation_records = ssl_info.get("validation_records", [])
        seen = set()
        for rec in validation_records:
            name, value = rec.get("txt_name"), rec.get("txt_value")
            if name and value and (name, value) not in seen:
                records.append((name, value))
                seen.add((name, value))
    except Exception:
        pass
    return records


def extract_ownership_verification_txt(custom_hostname_response: dict):
    """
    Ekstrak Name & Value dari ownership_verification -- TXT record untuk
    verifikasi KEPEMILIKAN hostname (bukan untuk SSL), formatnya
    '_cf-custom-hostname.xxx'. Sebagian setup memerlukan ini juga,
    tergantung apakah hostname sudah pernah path verification sebelumnya.
    """
    try:
        result = custom_hostname_response.get("result", {})
        ov = result.get("ownership_verification")
        if ov and ov.get("type") == "txt":
            return ov.get("name"), ov.get("value")
        return None, None
    except Exception:
        return None, None


def is_valid_ip(ip: str) -> bool:
    """Validasi sederhana format IPv4"""
    parts = ip.strip().split(".")
    if len(parts) != 4:
        return False
    for p in parts:
        if not p.isdigit() or not 0 <= int(p) <= 255:
            return False
    return True


# Kamus terjemahan pesan error Cloudflare yang paling sering muncul,
# supaya admin langsung paham tanpa harus translate manual.
# Pencocokan pakai substring (lowercase) karena Cloudflare kadang menambahkan
# detail tambahan di belakang pesan inti.
ERROR_TRANSLATIONS = {
    "duplicate custom hostname found": "Hostname ini SUDAH PERNAH didaftarkan sebelumnya di Cloudflare. Pakai nama lain, atau hapus dulu yang lama dari dashboard kalau memang mau didaftarkan ulang.",
    "duplicate dns record": "Record DNS dengan nama & isi yang sama SUDAH ADA. Tidak perlu ditambahkan lagi.",
    "hostname does not match the zone": "Nama bug yang dimasukkan bukan subdomain dari zone/domain yang terdaftar di CF_ZONE_ID. Pastikan nama bug diakhiri dengan domain utama yang benar.",
    "invalid hostname": "Format nama bug/subdomain tidak valid. Cek lagi penulisannya (tidak boleh ada spasi, simbol aneh, dll).",
    "authentication error": "API Token Cloudflare salah/sudah tidak berlaku. Ketik `/resetcf` untuk masukin token baru.",
    "invalid request headers": "API Token Cloudflare tidak valid atau format request salah. Ketik `/resetcf` untuk masukin token baru.",
    "unable to authenticate": "Gagal autentikasi ke Cloudflare. Ketik `/resetcf` untuk masukin token baru.",
    "zone could not be found": "Zone ID yang diisi tidak ditemukan di akun Cloudflare. Ketik `/resetcf` untuk masukin ulang.",
    "invalid zone identifier": "Zone ID yang diisi formatnya salah. Ketik `/resetcf` untuk masukin ulang.",
    "rate limited": "Terlalu banyak request ke Cloudflare dalam waktu singkat. Tunggu sebentar lalu coba lagi.",
    "you have hit a rate limit": "Terlalu banyak request ke Cloudflare dalam waktu singkat. Tunggu sebentar lalu coba lagi.",
    "record already exists": "Record DNS dengan data ini sudah ada sebelumnya, tidak perlu ditambahkan lagi.",
    "custom hostname is not pending": "Custom hostname ini statusnya sudah bukan 'pending', mungkin sudah aktif atau dalam proses lain.",
    "ssl validation method": "Ada masalah dengan metode validasi SSL yang dipilih. Cek pengaturan SSL for SaaS di dashboard Cloudflare.",
    "an unexpected error occurred": "Terjadi error tak terduga dari pihak Cloudflare. Coba lagi beberapa saat, atau cek status Cloudflare di cloudflarestatus.com.",
    "could not connect": "Tidak bisa terhubung ke server Cloudflare. Cek koneksi internet VPS.",
    "ssl for saas is not enabled": "Fitur Cloudflare for SaaS / SSL for SaaS belum diaktifkan di zone ini. Aktifkan dulu di dashboard Cloudflare.",
    "value is not a valid ip": "IP yang dimasukkan tidak valid menurut Cloudflare.",
}


def translate_error(err_text: str) -> str:
    """Coba terjemahkan pesan error Cloudflare ke Bahasa Indonesia.
    Kalau tidak ada di kamus, kembalikan pesan asli (lebih baik tampil
    pesan asli daripada menyembunyikan informasi yang mungkin penting)."""
    err_lower = err_text.lower()
    for key, translation in ERROR_TRANSLATIONS.items():
        if key in err_lower:
            return f"{translation}\n\n_Pesan asli: {err_text}_"
    return err_text


def extract_error_text(data: dict, status_code=None) -> str:
    """Ekstrak & gabungkan semua pesan error dari response Cloudflare,
    lalu terjemahkan ke Bahasa Indonesia. Dibuat defensif karena format
    response Cloudflare bisa bervariasi (errors kosong, message tidak ada, dll)."""
    raw_text = ""
    try:
        err_list = data.get("errors") if isinstance(data, dict) else None
        if err_list and isinstance(err_list, list) and len(err_list) > 0:
            parts = []
            for e in err_list:
                if isinstance(e, dict):
                    msg = e.get("message") or e.get("error") or str(e)
                    code = e.get("code")
                    parts.append(f"{msg} (code: {code})" if code else msg)
                else:
                    parts.append(str(e))
            raw_text = "; ".join(parts)
        elif isinstance(data, dict) and data.get("message"):
            raw_text = str(data.get("message"))
    except Exception:
        raw_text = ""

    if not raw_text:
        # Fallback terakhir: tampilkan apa adanya supaya tetap ada info untuk debug,
        # jangan biarkan kosong tanpa keterangan apapun.
        raw_text = f"Respon dari Cloudflare tidak mengandung pesan error yang jelas. Data mentah: `{str(data)[:300]}`"
        if status_code:
            raw_text = f"HTTP {status_code} - " + raw_text

    return translate_error(raw_text)


class CloudflareBugHandler:
    def __init__(self):
        self.bot = bot
        self.setup_handlers()

    def setup_handlers(self):
        # Command teks langsung (tetap didukung untuk yang mau cara cepat)
        self.bot.on(events.NewMessage(pattern=r"^/addbug(?:\s+(\S+)\s+(\S+))?$"))(self.cmd_addbug)
        # Tombol -> alur tanya jawab
        self.bot.on(events.CallbackQuery(pattern=r'^addbug_btn$'))(self.cb_addbug_button)
        # Reset token/zone id Cloudflare yang tersimpan
        self.bot.on(events.NewMessage(pattern=r"^/resetcf$"))(self.cmd_resetcf)

    async def cmd_resetcf(self, event):
        sender = await event.get_sender()
        if valid(str(sender.id)) != "true":
            await event.reply("❌ Akses Ditolak. Command ini khusus admin.")
            return

        async with self.bot.conversation(event.chat_id, timeout=180) as conv:
            cf_config = await self.ask_cf_credentials(conv, sender.id)
            if cf_config:
                await conv.send_message("✅ Token & Zone ID Cloudflare berhasil diperbarui.")

    async def ask_cf_credentials(self, conv, sender_id):
        """Tanya token & zone id Cloudflare SEKALI ke admin, simpan ke file
        lokal milik server ini. Return dict {"token","zone_id"} atau None
        kalau dibatalkan/timeout."""
        await conv.send_message(
            "🔑 **Setup Cloudflare (cuma sekali)**\n\n"
            "Belum ada token Cloudflare yang tersimpan di server ini.\n"
            "Masukkan **API Token** Cloudflare punya akun lo sendiri "
            "(buat di dash.cloudflare.com > Profile > API Tokens, scope minimal "
            "`Zone.DNS Edit` + `Zone.SSL and Certificates Edit`).\n\n"
            "Ketik `batal` untuk membatalkan.",
            parse_mode="markdown"
        )
        try:
            resp = await conv.wait_event(events.NewMessage(from_users=sender_id))
            token = resp.raw_text.strip()
        except asyncio.TimeoutError:
            await conv.send_message("⏰ Waktu input habis. Dibatalkan.")
            return None

        if not token or token.lower() == "batal":
            await conv.send_message("❌ Dibatalkan.")
            return None

        await conv.send_message(
            "📌 **Masukkan Zone ID** domain lo di Cloudflare\n\n"
            "Bisa dilihat di dashboard Cloudflare > pilih domain > Overview, "
            "kolom 'Zone ID' di sebelah kanan bawah.",
            parse_mode="markdown"
        )
        try:
            resp2 = await conv.wait_event(events.NewMessage(from_users=sender_id))
            zone_id = resp2.raw_text.strip()
        except asyncio.TimeoutError:
            await conv.send_message("⏰ Waktu input habis. Dibatalkan.")
            return None

        if not zone_id or zone_id.lower() == "batal":
            await conv.send_message("❌ Dibatalkan.")
            return None

        save_cf_config(token, zone_id)
        await conv.send_message(
            "✅ Token & Zone ID tersimpan untuk server ini. Lanjut ke proses ADD WILDCARD.",
            parse_mode="markdown"
        )
        return {"token": token, "zone_id": zone_id}

    async def ask_and_run(self, event, sender_id):
        """Alur tanya nama bug, lalu tanya IP, lalu eksekusi"""
        async with self.bot.conversation(event.chat_id, timeout=180) as conv:
            cf_config = load_cf_config()
            if not cf_config:
                cf_config = await self.ask_cf_credentials(conv, sender_id)
                if not cf_config:
                    return

            await conv.send_message(
                "📌 **Masukkan nama bug/subdomain**\n\n"
                "Contoh: `support.zoom.us.rifganss-store.my.id`",
                parse_mode="markdown"
            )
            try:
                resp1 = await conv.wait_event(events.NewMessage(from_users=sender_id))
                nama_bug = resp1.raw_text.strip()
            except asyncio.TimeoutError:
                await conv.send_message("⏰ Waktu input habis. Dibatalkan.")
                return

            if not nama_bug or " " in nama_bug:
                await conv.send_message("❌ Nama bug tidak valid. Dibatalkan, coba lagi dari menu.")
                return

            await conv.send_message(
                "📌 **Masukkan IP VPS tujuan**\n\n"
                "Contoh: `103.253.244.111`",
                parse_mode="markdown"
            )
            try:
                resp2 = await conv.wait_event(events.NewMessage(from_users=sender_id))
                ip_vps = resp2.raw_text.strip()
            except asyncio.TimeoutError:
                await conv.send_message("⏰ Waktu input habis. Dibatalkan.")
                return

            if not is_valid_ip(ip_vps):
                await conv.send_message(f"❌ `{ip_vps}` bukan format IPv4 yang valid. Dibatalkan, coba lagi dari menu.", parse_mode="markdown")
                return

            await self.process_addbug(conv, nama_bug, ip_vps, cf_config["token"], cf_config["zone_id"])

    async def cb_addbug_button(self, event):
        sender = await event.get_sender()
        if valid(str(sender.id)) != "true":
            await event.answer("Access Denied", alert=True)
            return
        await event.answer()
        await self.ask_and_run(event, sender.id)

    async def cmd_addbug(self, event):
        sender = await event.get_sender()

        if valid(str(sender.id)) != "true":
            await event.reply("❌ Akses Ditolak. Command ini khusus admin.")
            return

        cf_config = load_cf_config()
        if not cf_config:
            await event.reply(
                "⚠️ **Token Cloudflare belum diset di server ini.**\n"
                "Pakai tombol **ADD WILDCARD** di menu Settings dulu (mode tanya-jawab) "
                "untuk setup token & Zone ID sekali, baru command `/addbug` ini bisa dipakai.",
                parse_mode="markdown"
            )
            return

        match = event.pattern_match
        nama_bug = match.group(1)
        ip_vps = match.group(2)

        if not nama_bug or not ip_vps:
            await event.reply(
                "**📌 Format Command**\n\n"
                "`/addbug [nama_bug] [ip_vps]`\n\n"
                "**Contoh:**\n"
                "`/addbug support.zoom.us.rifganss-store.my.id 192.168.1.1`\n\n"
                "Atau pakai tombol **ADD BUG** di menu Settings untuk mode tanya-jawab.",
                parse_mode="markdown"
            )
            return

        if not is_valid_ip(ip_vps):
            await event.reply(f"❌ `{ip_vps}` bukan format IPv4 yang valid.", parse_mode="markdown")
            return

        await self.process_addbug(event, nama_bug, ip_vps, cf_config["token"], cf_config["zone_id"])

    async def process_addbug(self, event_or_conv, nama_bug: str, ip_vps: str, token: str, zone_id: str):
        """Eksekusi 3 step API Cloudflare. event_or_conv bisa event biasa atau conversation object,
        keduanya punya method .respond()/.send_message() yang kompatibel dipakai di sini lewat reply helper."""

        async def send(text):
            if hasattr(event_or_conv, "respond"):
                return await event_or_conv.respond(text, parse_mode="markdown")
            else:
                return await event_or_conv.send_message(text, parse_mode="markdown")

        msg = await send(f"⏳ Memproses bug `{nama_bug}` ...")

        # ===== STEP 1: Add Custom Hostname =====
        await msg.edit(f"⏳ [1/3] Menambahkan Custom Hostname `{nama_bug}` ...", parse_mode="markdown")
        status1, data1 = cf_add_custom_hostname(nama_bug, token, zone_id)

        if status1 not in (200, 201):
            err_text = extract_error_text(data1, status1)
            await msg.edit(
                f"❌ **GAGAL di Tahap 1 (Tambah Custom Hostname)**\n"
                f"Hostname: `{nama_bug}`\n\n"
                f"**Penyebab:**\n{err_text}",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
            )
            return

        # ===== Ambil hostname ID untuk keperluan GET ulang (polling) =====
        hostname_id = data1.get("result", {}).get("id")

        # ===== Polling: tunggu ssl.validation_records muncul =====
        # Berdasar dokumentasi resmi Cloudflare, response POST awal SERING BELUM
        # menyertakan ssl.validation_records -- perlu GET ulang dengan jeda.
        await msg.edit(f"⏳ [1/3] Menunggu data SSL validation dari Cloudflare ...", parse_mode="markdown")

        ssl_records = extract_all_ssl_validation_txt(data1)
        current_data = data1

        if not ssl_records and hostname_id:
            for attempt in range(5):
                await asyncio.sleep(3)
                status_chk, data_chk = cf_get_custom_hostname(hostname_id, token, zone_id)
                if status_chk in (200, 201):
                    current_data = data_chk
                    ssl_records = extract_all_ssl_validation_txt(data_chk)
                    if ssl_records:
                        break

        if not ssl_records:
            await msg.edit(
                f"⚠️ **Custom Hostname berhasil dibuat**, tapi data TXT untuk SSL validation "
                f"belum tersedia setelah beberapa kali percobaan.\n"
                f"Hostname: `{nama_bug}`\n\n"
                f"Cek manual di dashboard Cloudflare > SSL/TLS > Custom Hostnames > pilih hostname ini, "
                f"lihat 'Certificate validation TXT name/value'.",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
            )
            return

        # ===== STEP 2: Add TXT Record(s) =====
        # Kirim SEMUA TXT record SSL validation (bisa lebih dari 1, misal untuk
        # beberapa CA sekaligus) -- WAJIB untuk SSL aktif. Kalau ownership_verification
        # juga ada dan namanya berbeda dari semua yang sudah dikirim, kirim juga.
        added_txt_lines = []
        failed_txt_lines = []

        for idx, (rec_name, rec_value) in enumerate(ssl_records, start=1):
            await msg.edit(
                f"⏳ [2/3] Menambahkan TXT record SSL validation ({idx}/{len(ssl_records)}) ...\nName: `{rec_name}`",
                parse_mode="markdown"
            )
            status_txt, data_txt = cf_add_dns_record("TXT", rec_name, rec_value, token, zone_id, proxied=False)
            if status_txt in (200, 201):
                added_txt_lines.append(f"`{rec_name}` ✅")
            else:
                err_text = extract_error_text(data_txt, status_txt)
                failed_txt_lines.append(f"`{rec_name}`\nPenyebab: {err_text}\nValue: `{rec_value}`")

        if failed_txt_lines:
            failed_block = "\n\n".join(failed_txt_lines)
            await msg.edit(
                f"❌ **GAGAL di Tahap 2 (Tambah TXT Record SSL Validation)**\n"
                f"Hostname: `{nama_bug}`\n"
                f"Custom Hostname SUDAH berhasil dibuat (tahap 1 sukses), tapi ada TXT record yang gagal ditambahkan.\n\n"
                f"**Yang gagal, tambahkan manual:**\n{failed_block}",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
            )
            return

        ownership_added_note = ""

        # ===== STEP 3: Add A Record (proxied/orange cloud) =====
        await msg.edit(f"⏳ [3/3] Menambahkan A record `{nama_bug}` -> `{ip_vps}` (proxied) ...", parse_mode="markdown")
        status3, data3 = cf_add_dns_record("A", nama_bug, ip_vps, token, zone_id, proxied=True)

        if status3 not in (200, 201):
            err_text = extract_error_text(data3, status3)
            await msg.edit(
                f"❌ **GAGAL di Tahap 3 (Tambah A Record)**\n"
                f"Hostname: `{nama_bug}`\n"
                f"Custom Hostname & TXT record SUDAH berhasil dibuat (tahap 1-2 sukses), tapi A record gagal.\n\n"
                f"**Penyebab:**\n{err_text}\n\n"
                f"**Tambahkan manual A record di dashboard Cloudflare:**\nName: `{nama_bug}`\nContent: `{ip_vps}`\nProxied: `true`",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
            )
            return

        # ===== SEMUA SUKSES =====
        await msg.edit(
            "✅ **WILDCARD BERHASIL DITAMBAHKAN**\n\n"
            f"**» Hostname    :** `{nama_bug}`\n"
            f"**» IP VPS      :** `{ip_vps}`\n"
            f"**» TXT SSL     :** {', '.join(added_txt_lines)}{ownership_added_note}\n"
            f"**» Proxied     :** ✅ (orange cloud)\n"
            f"**» SSL Status  :** Pending validation (Cloudflare butuh beberapa menit)\n\n"
            f"Cek status SSL di dashboard Cloudflare > SSL/TLS > Custom Hostnames.",
            parse_mode="markdown",
            buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
        )


# Initialize handler
cfbug_handler = CloudflareBugHandler()
