from private import *
import asyncio
import requests
from telethon import Button, events

# ============================================================
# Module: DNS Record Manager (Cloudflare)
# ============================================================
# Fitur CRUD penuh buat DNS record di Cloudflare: List, Add, Edit, Delete.
# Modul ini TERPISAH dari cfbug.py (ADD WILDCARD) -- tidak mengubah logic
# atau alur fitur ADD WILDCARD sama sekali.
#
# Tetap NEBENG file config token yang sama (cf_config.json) dari cfbug.py
# supaya admin tidak perlu setup token Cloudflare dua kali. Kalau token
# belum pernah diisi sama sekali, modul ini ngarahin admin untuk setup
# lewat ADD WILDCARD / /resetcf dulu (satu sumber token, tidak duplikat).
# ============================================================

from private.modules.cfbug import load_cf_config, cf_headers, CF_BASE_URL, is_valid_ip

RECORD_TYPES = ["A", "AAAA", "CNAME", "TXT", "MX", "NS", "SRV"]
PROXIABLE_TYPES = {"A", "AAAA", "CNAME"}


def _g(event, n=1, default=None):
    """Ambil group dari event.pattern_match dan decode ke str.
    Telethon callback data itu bytes, jadi group() bisa balik bytes (b'A')
    kalau tidak di-decode -- ini yang bikin error 'bytes is not JSON serializable'."""
    m = event.pattern_match
    val = m.group(n) if m else None
    if val is None:
        return default
    if isinstance(val, bytes):
        return val.decode()
    return val


def require_cf_config():
    return load_cf_config()


def cf_list_dns_records(token: str, zone_id: str, page: int = 1, per_page: int = 50):
    url = f"{CF_BASE_URL}/zones/{zone_id}/dns_records"
    try:
        resp = requests.get(
            url, headers=cf_headers(token),
            params={"page": page, "per_page": per_page, "order": "type"},
            timeout=20
        )
        return resp.status_code, resp.json()
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def cf_create_dns_record(token: str, zone_id: str, rtype: str, name: str, content: str, proxied: bool, ttl: int = 1):
    url = f"{CF_BASE_URL}/zones/{zone_id}/dns_records"
    payload = {"type": rtype, "name": name, "content": content, "ttl": ttl}
    if rtype in PROXIABLE_TYPES:
        payload["proxied"] = proxied
    try:
        resp = requests.post(url, headers=cf_headers(token), json=payload, timeout=20)
        return resp.status_code, resp.json()
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def cf_update_dns_record(token: str, zone_id: str, record_id: str, rtype: str, name: str, content: str, proxied: bool, ttl: int = 1):
    url = f"{CF_BASE_URL}/zones/{zone_id}/dns_records/{record_id}"
    payload = {"type": rtype, "name": name, "content": content, "ttl": ttl}
    if rtype in PROXIABLE_TYPES:
        payload["proxied"] = proxied
    try:
        resp = requests.put(url, headers=cf_headers(token), json=payload, timeout=20)
        return resp.status_code, resp.json()
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def cf_delete_dns_record(token: str, zone_id: str, record_id: str):
    url = f"{CF_BASE_URL}/zones/{zone_id}/dns_records/{record_id}"
    try:
        resp = requests.delete(url, headers=cf_headers(token), timeout=20)
        return resp.status_code, resp.json()
    except Exception as e:
        return None, {"errors": [{"message": str(e)}]}


def extract_error_text(data, status_code=None) -> str:
    try:
        err_list = data.get("errors") if isinstance(data, dict) else None
        if err_list:
            return "; ".join(e.get("message", str(e)) if isinstance(e, dict) else str(e) for e in err_list)
    except Exception:
        pass
    return f"HTTP {status_code} - response tidak jelas: {str(data)[:200]}"


class DNSManagerHandler:
    def __init__(self):
        self.bot = bot
        self.setup_handlers()

    def setup_handlers(self):
        self.bot.on(events.CallbackQuery(pattern=r'^dnsmenu$'))(self.cb_dns_menu)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_list_(\d+)$'))(self.cb_dns_list)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_add$'))(self.cb_dns_add_start)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_addtype_(\w+)$'))(self.cb_dns_add_pick_type)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_pick_(.+)$'))(self.cb_dns_pick_record)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_edit_(.+)$'))(self.cb_dns_edit_start)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_del_(.+)$'))(self.cb_dns_delete_confirm)
        self.bot.on(events.CallbackQuery(pattern=r'^dns_delyes_(.+)$'))(self.cb_dns_delete_execute)

    async def _require_admin(self, event):
        sender = await event.get_sender()
        if valid(str(sender.id)) != "true":
            await event.answer("Access Denied", alert=True)
            return None
        return sender

    async def _require_cf(self, event):
        cfg = require_cf_config()
        if not cfg:
            await event.edit(
                "⚠️ **Token Cloudflare belum diset di server ini.**\n"
                "Setup dulu lewat tombol **ADD WILDCARD** atau command `/resetcf`, "
                "baru fitur DNS Records ini bisa dipakai (token-nya dipakai bareng).",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke Settings ›", "setting")]]
            )
            return None
        return cfg

    # ===================== Menu utama =====================
    async def cb_dns_menu(self, event):
        if not await self._require_admin(event):
            return
        await event.answer()
        await event.edit(
            "🌐 **DNS RECORDS MANAGER**\n\nKelola DNS record Cloudflare untuk domain di server ini.",
            parse_mode="markdown",
            buttons=[
                [Button.inline("📋 List Records", "dns_list_1")],
                [Button.inline("➕ Add Record", "dns_add")],
                [Button.inline("‹ Kembali ke Settings ›", "setting")]
            ]
        )

    # ===================== List =====================
    async def cb_dns_list(self, event):
        if not await self._require_admin(event):
            return
        cfg = await self._require_cf(event)
        if not cfg:
            return
        await event.answer()

        page = int(_g(event, 1, "1"))
        status, data = cf_list_dns_records(cfg["token"], cfg["zone_id"], page=page)
        if status not in (200, 201):
            await event.edit(
                f"❌ Gagal ambil daftar record.\n{extract_error_text(data, status)}",
                buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
            )
            return

        records = data.get("result", [])
        if not records:
            await event.edit(
                "📋 **DNS Records**\n\nTidak ada record di halaman ini.",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
            )
            return

        lines = ["📋 **DNS Records**\n"]
        buttons = []
        for rec in records:
            proxied_icon = " 🟧" if rec.get("proxied") else ""
            lines.append(f"`{rec['type']:<6}` `{rec['name']}` → `{rec['content']}`{proxied_icon}")
            label = f"{rec['type']} | {rec['name'][:28]}"
            buttons.append([Button.inline(label, f"dns_pick_{rec['id']}")])

        nav = []
        info = data.get("result_info", {})
        if info.get("page", 1) > 1:
            nav.append(Button.inline("‹ Prev", f"dns_list_{page-1}"))
        if info.get("page", 1) < info.get("total_pages", 1):
            nav.append(Button.inline("Next ›", f"dns_list_{page+1}"))
        if nav:
            buttons.append(nav)
        buttons.append([Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")])

        await event.edit("\n".join(lines), parse_mode="markdown", buttons=buttons)

    async def cb_dns_pick_record(self, event):
        """Setelah pilih record dari list, tawarin Edit atau Delete"""
        if not await self._require_admin(event):
            return
        await event.answer()
        record_id = _g(event, 1)
        await event.edit(
            "Mau diapain record ini?",
            buttons=[
                [Button.inline("✏️ Edit", f"dns_edit_{record_id}"), Button.inline("🗑️ Delete", f"dns_del_{record_id}")],
                [Button.inline("‹ Kembali ke List ›", "dns_list_1")]
            ]
        )

    # ===================== Add =====================
    async def cb_dns_add_start(self, event):
        if not await self._require_admin(event):
            return
        if not await self._require_cf(event):
            return
        await event.answer()
        buttons = [[Button.inline(t, f"dns_addtype_{t}")] for t in RECORD_TYPES]
        buttons.append([Button.inline("‹ Batal ›", "dnsmenu")])
        await event.edit("➕ **Add DNS Record**\n\nPilih tipe record:", parse_mode="markdown", buttons=buttons)

    async def cb_dns_add_pick_type(self, event):
        sender = await self._require_admin(event)
        if not sender:
            return
        await event.answer()
        rtype = _g(event, 1)

        async with self.bot.conversation(event.chat_id, timeout=180) as conv:
            await conv.send_message(
                f"📌 **Nama/host untuk record `{rtype}`**\n\nContoh: `sub.domain.com` atau `@` untuk root domain.",
                parse_mode="markdown"
            )
            try:
                r1 = await conv.wait_event(events.NewMessage(from_users=sender.id))
                name = r1.raw_text.strip()
            except asyncio.TimeoutError:
                await conv.send_message("⏰ Waktu habis. Dibatalkan.")
                return
            if not name:
                await conv.send_message("❌ Nama tidak boleh kosong. Dibatalkan.")
                return

            await conv.send_message(f"📌 **Isi/content untuk `{rtype}`**\n\nContoh: IP (buat A) atau target host (buat CNAME).", parse_mode="markdown")
            try:
                r2 = await conv.wait_event(events.NewMessage(from_users=sender.id))
                content = r2.raw_text.strip()
            except asyncio.TimeoutError:
                await conv.send_message("⏰ Waktu habis. Dibatalkan.")
                return
            if not content:
                await conv.send_message("❌ Content tidak boleh kosong. Dibatalkan.")
                return
            if rtype == "A" and not is_valid_ip(content):
                await conv.send_message(f"❌ `{content}` bukan format IPv4 yang valid. Dibatalkan.", parse_mode="markdown")
                return

            proxied = False
            if rtype in PROXIABLE_TYPES:
                await conv.send_message(
                    "📌 **Proxied (orange cloud)?**",
                    buttons=[[Button.inline("✅ Ya", "dns_proxy_yes"), Button.inline("❌ Tidak", "dns_proxy_no")]]
                )
                try:
                    cb = await conv.wait_event(events.CallbackQuery(chats=event.chat_id))
                    while cb.sender_id != sender.id:
                        cb = await conv.wait_event(events.CallbackQuery(chats=event.chat_id))
                    await cb.answer()
                    proxied = cb.data == b"dns_proxy_yes"
                except asyncio.TimeoutError:
                    await conv.send_message("⏰ Waktu habis. Dibatalkan.")
                    return
                except Exception as e:
                    await conv.send_message(f"❌ **Error tak terduga saat baca pilihan Proxied:**\n`{e}`", parse_mode="markdown")
                    return

            try:
                cfg = require_cf_config()
                status, data = cf_create_dns_record(cfg["token"], cfg["zone_id"], rtype, name, content, proxied)
            except Exception as e:
                await conv.send_message(
                    f"❌ **Error tak terduga saat proses ke Cloudflare:**\n`{e}`",
                    parse_mode="markdown",
                    buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
                )
                return

            if status not in (200, 201):
                await conv.send_message(
                    f"❌ **Gagal menambah record.**\n{extract_error_text(data, status)}",
                    parse_mode="markdown",
                    buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
                )
                return

            await conv.send_message(
                f"✅ **Record berhasil ditambahkan**\n`{rtype}` `{name}` → `{content}`" + (" (proxied)" if proxied else ""),
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
            )

    # ===================== Edit =====================
    async def cb_dns_edit_start(self, event):
        sender = await self._require_admin(event)
        if not sender:
            return
        cfg = await self._require_cf(event)
        if not cfg:
            return
        await event.answer()
        record_id = _g(event, 1)

        status, data = cf_list_dns_records(cfg["token"], cfg["zone_id"], per_page=200)
        record = None
        if status in (200, 201):
            for r in data.get("result", []):
                if r["id"] == record_id:
                    record = r
                    break
        if not record:
            await event.edit("❌ Record tidak ditemukan (mungkin sudah dihapus).", buttons=[[Button.inline("‹ Kembali ke List ›", "dns_list_1")]])
            return

        async with self.bot.conversation(event.chat_id, timeout=180) as conv:
            await conv.send_message(
                f"✏️ **Edit Record**\n`{record['type']}` `{record['name']}`\nContent sekarang: `{record['content']}`\n\n"
                "Masukkan content baru:",
                parse_mode="markdown"
            )
            try:
                r1 = await conv.wait_event(events.NewMessage(from_users=sender.id))
                new_content = r1.raw_text.strip()
            except asyncio.TimeoutError:
                await conv.send_message("⏰ Waktu habis. Dibatalkan.")
                return
            if not new_content:
                await conv.send_message("❌ Content tidak boleh kosong. Dibatalkan.")
                return

            status_u, data_u = cf_update_dns_record(
                cfg["token"], cfg["zone_id"], record_id,
                record["type"], record["name"], new_content,
                record.get("proxied", False)
            )
            if status_u not in (200, 201):
                await conv.send_message(
                    f"❌ **Gagal update record.**\n{extract_error_text(data_u, status_u)}",
                    parse_mode="markdown",
                    buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
                )
                return

            await conv.send_message(
                f"✅ **Record berhasil diupdate**\n`{record['type']}` `{record['name']}` → `{new_content}`",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
            )

    # ===================== Delete =====================
    async def cb_dns_delete_confirm(self, event):
        if not await self._require_admin(event):
            return
        await event.answer()
        record_id = _g(event, 1)
        await event.edit(
            "⚠️ **Yakin mau hapus record ini?** Tindakan ini tidak bisa dibatalkan.",
            parse_mode="markdown",
            buttons=[
                [Button.inline("✅ Ya, Hapus", f"dns_delyes_{record_id}"), Button.inline("❌ Batal", "dns_list_1")]
            ]
        )

    async def cb_dns_delete_execute(self, event):
        if not await self._require_admin(event):
            return
        cfg = await self._require_cf(event)
        if not cfg:
            return
        await event.answer()
        record_id = _g(event, 1)

        status, data = cf_delete_dns_record(cfg["token"], cfg["zone_id"], record_id)
        if status not in (200, 201):
            await event.edit(
                f"❌ **Gagal menghapus record.**\n{extract_error_text(data, status)}",
                parse_mode="markdown",
                buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
            )
            return

        await event.edit(
            "✅ Record berhasil dihapus.",
            buttons=[[Button.inline("‹ Kembali ke DNS Menu ›", "dnsmenu")]]
        )


# Initialize handler
dnsmanager_handler = DNSManagerHandler()
