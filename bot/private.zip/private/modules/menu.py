from private import *
import asyncio
import time
import subprocess
from datetime import timedelta
from telethon import Button, events
import logging

# Setup logging untuk debug
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot_start_time = time.time()
last_menu_message = {}

# Cache untuk informasi sistem dengan waktu kedaluwarsa
class SystemInfoCache:
    def __init__(self, duration=30):
        self.cache = {}
        self.duration = duration
    
    def get(self, key):
        if key in self.cache:
            value, timestamp = self.cache[key]
            if time.time() - timestamp < self.duration:
                return value
        return None
    
    def set(self, key, value):
        self.cache[key] = (value, time.time())
    
    def clear(self):
        count = len(self.cache)
        self.cache = {}
        return count

system_info_cache = SystemInfoCache()

# Cache untuk validasi user
user_access_cache = {}

async def get_cached_system_info(key, command, default="Unknown", timeout=3):
    """Cache informasi sistem untuk mengurangi panggilan subprocess"""
    cached = system_info_cache.get(key)
    if cached is not None:
        return cached
    
    try:
        # Gunakan asyncio untuk proses non-blocking
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout)
        result = stdout.decode().strip() or default
        
        system_info_cache.set(key, result)
        return result
    except (asyncio.TimeoutError, subprocess.SubprocessError) as e:
        logger.error(f"Error executing command {command}: {str(e)}")
        system_info_cache.set(key, default)
        return default

# Preload data yang sering digunakan
async def preload_common_data():
    """Preload data yang sering digunakan untuk respon lebih cepat"""
    common_commands = {
        "ssh": 'cat /etc/passwd | grep "home" | grep "false" | wc -l',
        "vms": 'cat /etc/vmess/.vmess.db | grep "###" | wc -l',
        "vls": 'cat /etc/vless/.vless.db | grep "###" | wc -l',
        "trj": 'cat /etc/trojan/.trojan.db | grep "###" | wc -l',
        "ss": 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l',
        "os": 'cat /etc/os-release | grep "PRETTY_NAME" | cut -d= -f2 | tr -d \'"\'',
        "ip": 'curl -s ifconfig.me || curl -s ipinfo.io/ip || hostname -I | awk \'{print $1}\''
    }
    
    # Preload data secara paralel
    tasks = []
    for key, cmd in common_commands.items():
        tasks.append(get_cached_system_info(key, cmd))
    
    await asyncio.gather(*tasks)
    logger.info("Preload data completed")

async def handle_access_denied(event):
    """Menangani akses ditolak dengan lebih efisien"""
    try:
        if isinstance(event, events.CallbackQuery.Event):
            await event.answer("Akses Ditolak", alert=True)
        else:
            await event.reply("❌ **Akses Ditolak**\nAnda tidak memiliki izin untuk menggunakan bot ini.")
    except Exception as e:
        logger.error(f"Error in handle_access_denied: {str(e)}")

# Ubah handler menu
@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
@bot.on(events.CallbackQuery(data=b'refresh'))
async def menu(event):
    try:
        sender = await event.get_sender()
        user_id = sender.id

        # === Animasi progress bar khusus refresh ===
        if isinstance(event, events.CallbackQuery.Event) and event.data == b"refresh":
            frames = [
                "🔃 Refreshing BOT [▯▯▯▯]",
                "🔃 Refreshing BOT [▮▯▯▯]",
                "🔃 Refreshing BOT [▮▮▯▯]",
                "🔃 Refreshing BOT [▮▮▮▯]",
                "🔃 Refreshing BOT [▮▮▮▮]",
            ]
            for frame in frames:
                try:
                    await event.edit(frame)
                    await asyncio.sleep(0.5)
                except:
                    pass
        # ==========================================

        # Layout button
        buttons = [
    [Button.inline("🛡️ SSH OVPN", b"ssh")],
    [Button.inline("⚡ VMESS", b"vmess"), Button.inline("🚀 VLESS", b"vless")],
    [Button.inline("🔒 TROJAN", b"trojan"), Button.inline("🌐 SOCKS", b"shadowsocks")],
    [Button.inline("📊 INFO VPS", b"info"), Button.inline("⚙️ SETTINGS", b"setting")],
    [Button.inline("❓ HELP", b"help"), Button.inline("🗑️ CLEAR CACHE", b"clear_cache")],
    [Button.inline("🔃 REFRESH", b"refresh")],   # ⬅ diganti refresh
]

        # === ambil data (ssh, vms, vls, trj, ss, namaos, ipsaya, dll.) ===
        ssh, vms, vls, trj, ss, namaos, ipsaya = await asyncio.gather(
            get_cached_system_info("ssh", 'cat /etc/passwd | grep "home" | grep "false" | wc -l', "0"),
            get_cached_system_info("vms", 'cat /etc/vmess/.vmess.db | grep "###" | wc -l', "0"),
            get_cached_system_info("vls", 'cat /etc/vless/.vless.db | grep "###" | wc -l', "0"),
            get_cached_system_info("trj", 'cat /etc/trojan/.trojan.db | grep "###" | wc -l', "0"),
            get_cached_system_info("ss", 'cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l', "0"),
            get_cached_system_info("os", 'cat /etc/os-release | grep "PRETTY_NAME" | cut -d= -f2 | tr -d \'"\''),
            get_cached_system_info("ip", 'curl -s ifconfig.me || curl -s ipinfo.io/ip || hostname -I | awk \'{print $1}\'', timeout=3)
        )

        try:
            city_task = asyncio.create_task(get_cached_system_info("city", 'curl -s ipinfo.io/city 2>/dev/null || echo "Tidak Diketahui"', timeout=2))
            isp_task = asyncio.create_task(get_cached_system_info("isp", 'curl -s ipinfo.io/org 2>/dev/null | cut -d" " -f2- || echo "Tidak Diketahui"', timeout=2))
            city, isp_info = await asyncio.gather(city_task, isp_task)
        except:
            city = isp_info = "Tidak Diketahui"

        uptime_seconds = int(time.time() - bot_start_time)
        uptime_str = str(timedelta(seconds=uptime_seconds))

        start_time = time.time()
        try:
            if hasattr(event, 'data'):
                await event.answer()
            ping_time = round((time.time() - start_time) * 1000, 2)
        except:
            ping_time = 0.0

        total_accounts = sum(int(x) for x in [ssh, vms, vls, trj, ss])
        cache_count = len(system_info_cache.cache)

        try:
            domain_info = DOMAIN
        except:
            domain_info = "Tidak Diketahui"

        username = f"@{sender.username}" if sender.username else "Tidak Ada Username"
        full_name = f"{sender.first_name or ''} {sender.last_name or ''}".strip()

        msg = f"""
╔═════════════════════╗
          **VPN MANAGEMENT BOT** 
╚═════════════════════╝

👤 **INFORMASI PENGGUNA**
┌─ **Nama:** `{full_name}`
├─ **Username:** `{username}`
└─ **User ID:** `{user_id}`

🖥️ **INFORMASI SISTEM**
┌─ **OS:** `{namaos}`
├─ **ISP:** `{isp_info}`
├─ **Lokasi:** `{city}`
├─ **Domain:** `{domain_info}`
├─ **IP Address:** `{ipsaya}`
└─ **Cache Items:** `{cache_count}` item

📊 **STATISTIK AKUN**
┌─ 🛡️ **SSH OVPN:** `{ssh}` akun
├─ ⚡ **VMESS:** `{vms}` akun
├─ 🚀 **VLESS:** `{vls}` akun
├─ 🔒 **TROJAN:** `{trj}` akun
├─ 🌐 **SHADOWSOCKS:** `{ss}` akun
└─**Total:** `{total_accounts}` akun

🤖 **INFORMASI BOT**
┌─ **Runtime:** `{uptime_str}`
└─**Ping:** `{ping_time} ms`

═══════════════════════
🔰 **Pilih layanan untuk dikelola:**
"""

        if isinstance(event, events.CallbackQuery.Event):
            message = await event.edit(msg, buttons=buttons)
        else:
            if user_id in last_menu_message:
                try:
                    await last_menu_message[user_id].delete()
                except:
                    pass
            message = await event.reply(msg, buttons=buttons)

        last_menu_message[user_id] = message

    except Exception as e:
        logger.error(f"Error in menu handler: {str(e)}")
        try:
            if isinstance(event, events.CallbackQuery.Event):
                await event.answer("Menu diperbarui", alert=False)
            else:
                await event.reply("Silakan pilih layanan:", buttons=[[Button.inline("‹ Coba Lagi ›", b'menu')]])
        except Exception as inner_e:
            logger.error(f"Error in fallback: {str(inner_e)}")

@bot.on(events.CallbackQuery(data=b'ignore'))
async def ignore_button(event):
    await event.answer("⏳ Sedang proses refresh...", alert=False)
    

# Handler untuk clear cache
@bot.on(events.CallbackQuery(data=b'clear_cache'))
async def clear_cache_handler(event):
    """Handler untuk menghapus cache sistem"""
    try:
        # Hapus cache
        cleared_count = system_info_cache.clear()
        global user_access_cache
        user_access_cache = {}
        
        # Kirim konfirmasi
        confirm_msg = f"""
🗑️ **CLEAR CACHE BERHASIL**

✅ Berhasil menghapus `{cleared_count}` item cache.

Cache sistem informasi telah dibersihkan dan akan diperbarui otomatis pada permintaan berikutnya.
"""
        await event.edit(confirm_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])
        
    except Exception as e:
        error_msg = f"""
❌ **GAGAL CLEAR CACHE**

Error: `{str(e)}`

Silakan coba lagi atau hubungi administrator.
"""
        await event.edit(error_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])

# Handler untuk bantuan
@bot.on(events.CallbackQuery(data=b'help'))
async def help_handler(event):
    help_msg = """
❓ **PANDUAN & BANTUAN**
━━━━━━━━━━━━━━━━━━━━━━

**Perintah yang Tersedia:**
• `/menu` - Menampilkan menu utama
• `/start` - Memulai bot

**Layanan yang Didukung:**
• 🛡️ SSH OVPN - Protokol SSH & OpenVPN
• ⚡ VMESS - Protokol VMess (WebSocket)
• 🚀 VLESS - Protokol VLess (lebih ringan & cepat)
• 🔒 TROJAN - Protokol Trojan (lebih aman)
• 🌐 SHADOWSOCKS - Protokol Shadowsocks

**Fitur Utama:**
• Membuat akun baru
• Perpanjang akun yang sudah ada
• Hapus akun
• Cek status login pengguna
• Lihat detail akun
• Ubah batas jumlah IP
• Monitoring server
• Clear Cache System

━━━━━━━━━━━━━━━━━━━━━━━
**Dukungan:** @frel01
"""
    try:
        await event.edit(help_msg, buttons=[[Button.inline("‹ Kembali ke Menu ›", b'menu')]])
    except:
        await event.answer("Error showing help", alert=True)

# Jalankan preload saat bot mulai
@bot.on(events.NewMessage(pattern='/preload'))
async def preload_command(event):
    """Command manual untuk preload data"""
    await preload_common_data()
    await event.reply("✅ Preload data completed!")

# Fungsi utama untuk menjalankan bot
async def main():
    """Jalankan bot dan preload data"""
    try:
        # Jalankan preload data
        await preload_common_data()
        
        # Mulai bot
        await bot.start()
        logger.info("Bot started successfully")
        
        # Jalankan bot sampai dihentikan
        await bot.run_until_disconnected()
        
    except Exception as e:
        logger.error(f"Error starting bot: {str(e)}")

# Jalankan aplikasi
if __name__ == '__main__':
    # Pastikan file private.py berisi semua yang diperlukan
    try:
        # Coba jalankan preload data dan mulai bot
        import asyncio
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")