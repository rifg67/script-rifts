from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math
import logging
logging.basicConfig(level=logging.INFO)
uptime = DT.datetime.now()

exec(open("/usr/bin/private/var.txt","r").read())
bot = TelegramClient("ddsdswl","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
try:
	open("/usr/bin/private/database.db")
except:
	x = sqlite3.connect("/usr/bin/private/database.db")
	c = x.cursor()
	c.execute("CREATE TABLE admin (user_id)")
	c.execute("INSERT INTO admin (user_id) VALUES (?)",(ADMIN,))
	x.commit()

def get_db():
	x = sqlite3.connect("/usr/bin/private/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
	db = get_db()
	x = db.execute("SELECT user_id FROM admin").fetchall()
	a = [v[0] for v in x]
	if id in a:
		return "true"
	else:
		return "false"

# ============================================================
# GERBANG AKSES GLOBAL (satu pintu untuk semua handler)
#
# Handler ini didaftarkan di sini, di __init__.py, SEBELUM
# __main__.py meng-import module lain (menu.py, ssh.py, setting.py,
# dst). Telethon memanggil handler yang cocok sesuai URUTAN
# didaftarkan. Karena handler ini didaftarkan paling awal, dia
# SELALU jadi yang pertama menerima setiap pesan/tombol.
#
# Kalau pengirimnya bukan admin terdaftar, kita langsung
# raise StopPropagation -> Telethon otomatis membatalkan
# pemanggilan SEMUA handler lain untuk update itu (start, menu,
# create-ssh, restartbot, listip, dst) - apapun cara mereka
# didaftarkan (decorator biasa maupun class-based seperti di
# setting.py). Hasilnya: bot benar-benar diam, tanpa balasan
# apapun, untuk siapapun yang bukan admin.
# ============================================================
@bot.on(events.NewMessage())
@bot.on(events.CallbackQuery())
async def _global_admin_gate(event):
	sender_id = event.sender_id
	if sender_id is None or valid(str(sender_id)) != "true":
		raise events.StopPropagation

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])
