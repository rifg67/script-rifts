// ==================== VMESS MODULE ====================
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const AKUN_FILE = path.join(__dirname, 'akun.json');

async function callAPI(server, endpoint, payload = null, method = 'POST') {
    try {
        const url = `${server.apiUrl}${endpoint}`;
        const headers = {
            'x-api-key': server.authKey,
            'Content-Type': 'application/json'
        };
        
        let response;
        if (method === 'POST') {
            response = await axios.post(url, payload, { headers, timeout: 30000 });
        } else {
            response = await axios.get(url, { headers, timeout: 30000 });
        }
        return response.data;
    } catch (error) {
        return { success: false, message: error.message };
    }
}

// ==================== SERVICE STATUS ====================
async function serviceStatus(server) {
    return await callAPI(server, '/api/services/status', {}, 'POST');
}

// ==================== VMESS FUNCTIONS ====================
async function createVmess(server, username, uuid, days, iplimit, quota = 500) {
    return await callAPI(server, '/api/vmess/create', {
        username, 
        uuid,
        days: parseInt(days),
        ip_limit: parseInt(iplimit),
        quota: parseInt(quota)
    });
}

async function renewVmess(server, username, days, iplimit = 1, quota = 500) {
    return await callAPI(server, '/api/vmess/renew', {
        username,
        days: parseInt(days)
    });
}

async function deleteVmess(server, username) {
    return await callAPI(server, '/api/vmess/delete', { username });
}

async function trialVmess(server, username, duration) {
    return await callAPI(server, '/api/vmess/trial', {
        username,
        minutes: parseInt(duration)
    });
}

// ==================== LOCK & UNLOCK VMESS ====================
async function lockVmess(server, username) {
    return await callAPI(server, '/api/vmess/lock', { username });
}

async function unlockVmess(server, username) {
    return await callAPI(server, '/api/vmess/unlock', { username });
}

async function detailVmess(server, username) {
    return await callAPI(server, '/api/vmess/detail', { username });
}

async function listVmess(server) {
    return await callAPI(server, '/api/vmess/list', {}, 'POST');
}

// ==================== UNTUK SYNC ====================
async function listAllVmess(server) {
    const result = await listVmess(server);
    if (result && result.success && result.data) {
        return {
            status: 'success',
            users: result.data.map(user => ({
                username: user.username,
                expiry_date: user.expired,
                status: user.status || 'active'
            }))
        };
    }
    return { status: 'error', users: [], message: result?.message || 'Failed' };
}

function generateRandomPassword(length = 10) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function saveAccount(service, serverName, username, data) {
    try {
        let accounts = {};
        if (fs.existsSync(AKUN_FILE)) {
            accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        }
        if (!accounts.services) accounts.services = {};
        if (!accounts.services[service]) accounts.services[service] = {};
        if (!accounts.services[service][serverName]) accounts.services[service][serverName] = {};
        
        accounts.services[service][serverName][username] = {
            username: username,
            data: data,
            saved_at: new Date().toISOString()
        };
        fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        return true;
    } catch (error) {
        return false;
    }
}

function deleteAccount(service, serverName, username) {
    try {
        if (!fs.existsSync(AKUN_FILE)) return true;
        const accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        if (accounts.services && accounts.services[service] && 
            accounts.services[service][serverName] && 
            accounts.services[service][serverName][username]) {
            delete accounts.services[service][serverName][username];
            fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        }
        return true;
    } catch (error) {
        return false;
    }
}

module.exports = {
    serviceStatus,
    createVmess, renewVmess, deleteVmess, trialVmess, detailVmess, listVmess, listAllVmess,
    lockVmess, unlockVmess, generateRandomPassword, saveAccount, deleteAccount
};