// ==================== SSH MODULE ====================
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const AKUN_FILE = path.join(__dirname, 'akun.json');

async function callAPI(server, endpoint, payload = null, method = 'POST') {
    try {
        const url = `${server.apiUrl}${endpoint}`;
        const headers = {
            'x-api-key': server.authKey,
            'Content-Type': 'application/json'
        };
        
        let response;
        if (method === 'POST') {
            response = await axios.post(url, payload, { headers, timeout: 15000 });
        } else {
            response = await axios.get(url, { headers, timeout: 15000 });
        }
        return response.data;
    } catch (error) {
        return { success: false, message: error.message };
    }
}

// ==================== SERVICE STATUS ====================
async function serviceStatus(server) {
    return await callAPI(server, '/api/services/status', {}, 'POST');
}

// ==================== SSH FUNCTIONS ====================
async function trialSSH(server, username, duration) {
    return await callAPI(server, '/api/ssh/trial', { username, minutes: duration });
}

async function createSSH(server, username, password, days, iplimit, quota = 500) {
    return await callAPI(server, '/api/ssh/create', { 
        username, 
        password, 
        days: parseInt(days), 
        ip_limit: parseInt(iplimit),
        quota: parseInt(quota)
    });
}

async function renewSSH(server, username, days, iplimit = 1, quota = 500) {
    return await callAPI(server, '/api/ssh/renew', { 
        username, 
        days: parseInt(days)
    });
}

async function deleteSSH(server, username) {
    return await callAPI(server, '/api/ssh/delete', { username });
}

// ==================== LOCK & UNLOCK SSH ====================
async function lockSSH(server, username) {
    return await callAPI(server, '/api/ssh/lock', { username });
}

async function unlockSSH(server, username) {
    return await callAPI(server, '/api/ssh/unlock', { username });
}

async function detailSSH(server, username) {
    return await callAPI(server, '/api/ssh/detail', { username });
}

async function listSSH(server) {
    return await callAPI(server, '/api/ssh/list', {}, 'POST');
}

// ==================== UNTUK SYNC ====================
async function listAllSSH(server) {
    const result = await listSSH(server);
    if (result && result.success && result.data) {
        return {
            status: 'success',
            users: result.data.map(user => ({
                username: user.username,
                expiry_date: user.expired,
                status: user.status || 'active'
            }))
        };
    }
    return { status: 'error', users: [], message: result?.message || 'Failed' };
}

function generateRandomPassword(length = 10) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function saveAccount(service, serverName, username, data) {
    try {
        let accounts = {};
        if (fs.existsSync(AKUN_FILE)) {
            accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        }
        if (!accounts.services) accounts.services = {};
        if (!accounts.services[service]) accounts.services[service] = {};
        if (!accounts.services[service][serverName]) accounts.services[service][serverName] = {};
        
        accounts.services[service][serverName][username] = {
            username: username,
            data: data,
            saved_at: new Date().toISOString()
        };
        fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        return true;
    } catch (error) {
        return false;
    }
}

function deleteAccount(service, serverName, username) {
    try {
        if (!fs.existsSync(AKUN_FILE)) return true;
        const accounts = JSON.parse(fs.readFileSync(AKUN_FILE, 'utf8'));
        if (accounts.services && accounts.services[service] && 
            accounts.services[service][serverName] && 
            accounts.services[service][serverName][username]) {
            delete accounts.services[service][serverName][username];
            fs.writeFileSync(AKUN_FILE, JSON.stringify(accounts, null, 2));
        }
        return true;
    } catch (error) {
        return false;
    }
}

// Handler functions untuk bot
async function handleTrial(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur trial SSH sedang dikembangkan...');
}
async function handleCreate(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur create SSH sedang dikembangkan...');
}
async function handleRenew(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur renew SSH sedang dikembangkan...');
}
async function handleDetail(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur detail SSH sedang dikembangkan...');
}
async function handleDelete(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur delete SSH sedang dikembangkan...');
}
async function handleLock(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur lock SSH sedang dikembangkan...');
}
async function handleUnlock(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur unlock SSH sedang dikembangkan...');
}
async function handleList(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur list SSH sedang dikembangkan...');
}
async function handleServiceStatus(chatId, userId, callbackQuery, bot, SERVERS) {
    await bot.sendMessage(chatId, '⏳ Fitur service status SSH sedang dikembangkan...');
}

module.exports = {
    serviceStatus,
    trialSSH, createSSH, renewSSH, deleteSSH, lockSSH, unlockSSH, detailSSH, listSSH, listAllSSH,
    handleTrial, handleCreate, handleRenew, handleDetail, handleDelete, handleLock, handleUnlock, handleList, handleServiceStatus,
    generateRandomPassword, saveAccount, deleteAccount
};