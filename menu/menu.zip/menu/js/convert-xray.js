const fs = require('fs');
const path = require('path');

// Fungsi untuk menambahkan header/notes pada YAML
function addYamlNotes(proxyType, configName = "") {
    const now = new Date();
    const timestamp = now.toLocaleString('id-ID');
    
    let notes = `# ========================================\n`;
    notes += `# KONFIGURASI ${proxyType.toUpperCase()} - PX STORE\n`;
    notes += `# ========================================\n`;
    notes += `# - Pastikan server dalam keadaan aktif\n`;
    notes += `# - Untuk masalah koneksi, cek status server\n`;
    if (configName) {
        notes += `# - Nama: ${configName}\n`;
    }
    notes += `# - Generated on: ${timestamp}\n\n`;
    
    return notes;
}

// Fungsi untuk parse VMess link - DIPERBAIKI
function parseVMessLink(link) {
    try {
        console.log('🔗 Parsing VMess link');
        const base64Data = link.split('://')[1];
        const decoded = Buffer.from(base64Data, 'base64').toString();
        console.log('📋 Decoded VMess:', decoded);
        
        const config = JSON.parse(decoded);
        console.log('📋 VMess config parsed:', config);
        
        // Normalisasi data VMess - handle berbagai format
        const normalizedConfig = {
            id: config.id || config.uuid || config.userID || "66ce30e3-4c14-42f6-b708-2f4dd60a161f",
            add: config.add || config.address || config.host || config.server || "server.example.com",
            port: parseInt(config.port) || 443,
            ps: config.ps || config.remarks || config.name || "vmess-proxy",
            type: 'vmess',
            aid: parseInt(config.aid) || parseInt(config.alterId) || 0,
            cipher: config.cipher || config.security || "auto",
            tls: config.tls === "tls" || config.security === "tls" || false,
            sni: config.sni || config.host || (config.add || "server.example.com"),
            host: config.host || config.add,
            net: config.net || config.type || "tcp",
            path: config.path || "/",
            skipCertVerify: config.skipCertVerify !== undefined ? config.skipCertVerify : true,
            udp: config.udp !== undefined ? config.udp : true
        };

        console.log('✅ VMess config normalized:', normalizedConfig);
        return normalizedConfig;
    } catch (error) {
        console.error('❌ VMess parsing error:', error);
        throw new Error('Format link VMess tidak valid: ' + error.message);
    }
}

// Fungsi untuk parse VLESS link - DIPERBAIKI
function parseVLessLink(link) {
    try {
        console.log('🔗 Parsing VLESS link:', link);
        const url = new URL(link);
        const params = new URLSearchParams(url.search);
        
        const config = {
            id: url.username || "66ce30e3-4c14-42f6-b708-2f4dd60a161f",
            add: url.hostname || "server.example.com",
            port: parseInt(url.port) || 443,
            type: 'vless',
            ps: url.hash ? decodeURIComponent(url.hash.substring(1)) : 'vless-proxy',
            tls: params.get('security') === 'tls' || params.get('encryption') === 'tls' ? 'tls' : 'none',
            sni: params.get('sni') || params.get('host') || url.hostname,
            host: params.get('host') || params.get('sni') || url.hostname,
            net: params.get('type') || params.get('network') || 'tcp',
            path: params.get('path') || '/',
            aid: 0,
            cipher: 'auto',
            udp: true,
            skipCertVerify: true,
            flow: params.get('flow') || ''
        };
        
        console.log('✅ VLESS config parsed:', config);
        return config;
    } catch (error) {
        console.error('❌ VLESS parsing error:', error);
        throw new Error('Format link VLESS tidak valid: ' + error.message);
    }
}

// Fungsi untuk parse Trojan link - DIPERBAIKI
function parseTrojanLink(link) {
    try {
        console.log('🔗 Parsing Trojan link:', link);
        const url = new URL(link);
        const params = new URLSearchParams(url.search);
        
        // Decode path jika ada encoding
        let path = params.get('path') || '/';
        try {
            path = decodeURIComponent(path);
        } catch (e) {
            // Jika decode gagal, gunakan path asli
        }
        
        const config = {
            password: url.username || "password",
            server: url.hostname || "server.example.com",
            port: parseInt(url.port) || 443,
            sni: params.get('sni') || params.get('host') || url.hostname,
            allowInsecure: params.get('allowInsecure') === '1' || true,
            name: url.hash ? decodeURIComponent(url.hash.substring(1)) : 'trojan-proxy',
            type: 'trojan',
            network: params.get('type') || params.get('network') || 'tcp',
            path: path,
            host: params.get('host') || params.get('sni') || url.hostname,
            udp: true
        };
        
        console.log('✅ Trojan config parsed:', config);
        return config;
    } catch (error) {
        console.error('❌ Trojan parsing error:', error);
        throw new Error('Format link Trojan tidak valid: ' + error.message);
    }
}

// Fungsi untuk generate V2Ray YAML - DIPERBAIKI
function generateV2RayYaml(v2rayConfig, configName = "") {
    console.log('🛠️ Generating V2Ray YAML from:', v2rayConfig);
    
    // Validasi config
    if (!v2rayConfig.id || !v2rayConfig.add) {
        throw new Error('Konfigurasi tidak valid: missing ID atau address');
    }
    
    const proxyName = v2rayConfig.ps || v2rayConfig.name || "v2ray-proxy";
    const server = v2rayConfig.add || v2rayConfig.address || v2rayConfig.server || "server.example.com";
    const port = v2rayConfig.port || 443;
    const uuid = v2rayConfig.id || v2rayConfig.uuid || "66ce30e3-4c14-42f6-b708-2f4dd60a161f";
    const alterId = v2rayConfig.aid || v2rayConfig.alterId || 0;
    const cipher = v2rayConfig.cipher || "auto";
    const tls = v2rayConfig.tls === "tls" || v2rayConfig.tls === true || v2rayConfig.security === "tls";
    const skipVerify = v2rayConfig.skipCertVerify !== undefined ? v2rayConfig.skipCertVerify : true;
    const servername = v2rayConfig.sni || v2rayConfig.servername || v2rayConfig.host || server;
    const network = v2rayConfig.net || v2rayConfig.network || "tcp";
    const wsPath = v2rayConfig.path || "/";
    const wsHost = v2rayConfig.host || v2rayConfig.sni || servername;
    const udp = v2rayConfig.udp !== undefined ? v2rayConfig.udp : true;
    
    const proxyType = v2rayConfig.type === 'vless' ? 'vless' : 'vmess';
    
    console.log(`🔧 YAML parameters: ${proxyType}://${uuid}@${server}:${port}`);
    console.log(`🔧 Network: ${network}, TLS: ${tls}, SNI: ${servername}, Path: ${wsPath}, Host: ${wsHost}`);
    
    // Tambahkan note/header di awal YAML
    let yaml = addYamlNotes(proxyType, configName);
    
    yaml += "proxies:\n";
    yaml += `  - name: ${proxyName}\n`;
    yaml += `    server: ${server}\n`;
    yaml += `    port: ${port}\n`;
    yaml += `    type: ${proxyType}\n`;
    yaml += `    uuid: ${uuid}\n`;
    
    if (proxyType === 'vmess') {
        yaml += `    alterId: ${alterId}\n`;
        yaml += `    cipher: ${cipher}\n`;
    }
    
    yaml += `    tls: ${tls}\n`;
    yaml += `    skip-cert-verify: ${skipVerify}\n`;
    
    // SELALU tambahkan servername jika tersedia
    if (servername) {
        yaml += `    servername: ${servername}\n`;
    }
    
    yaml += `    network: ${network}\n`;
    
    // Handle different network types
    if (network === "ws") {
        yaml += `    ws-opts:\n`;
        yaml += `      path: "${wsPath}"\n`;
        // SELALU tambahkan headers Host jika tersedia
        if (wsHost) {
            yaml += `      headers:\n`;
            yaml += `        Host: ${wsHost}\n`;
        }
    } else if (network === "grpc") {
        yaml += `    grpc-opts:\n`;
        yaml += `      grpc-service-name: "${wsPath}"\n`;
    } else if (network === "h2") {
        yaml += `    h2-opts:\n`;
        yaml += `      path: "${wsPath}"\n`;
        if (wsHost) {
            yaml += `      host: ["${wsHost}"]\n`;
        }
    } else if (network === "tcp") {
        // Untuk TCP dengan custom header
        if (wsHost) {
            yaml += `    http-opts:\n`;
            yaml += `      headers:\n`;
            yaml += `        Host: ${wsHost}\n`;
        }
    }
    
    // Tambahkan flow untuk VLESS
    if (proxyType === 'vless' && v2rayConfig.flow) {
        yaml += `    flow: ${v2rayConfig.flow}\n`;
    }
    
    yaml += `    udp: ${udp}\n`;
    
    console.log('✅ YAML generated successfully');
    console.log('📄 Generated YAML:\n', yaml);
    return yaml;
}

// Fungsi untuk generate Trojan YAML - DIPERBAIKI
function generateTrojanYaml(trojanConfig, configName = "") {
    console.log('🛠️ Generating Trojan YAML from:', trojanConfig);
    
    // Validasi config
    if (!trojanConfig.password || !trojanConfig.server) {
        throw new Error('Konfigurasi Trojan tidak valid: missing password atau server');
    }
    
    const proxyName = trojanConfig.name || trojanConfig.ps || "trojan-proxy";
    const server = trojanConfig.server || trojanConfig.add || "server.example.com";
    const port = trojanConfig.port || 443;
    const password = trojanConfig.password || "password";
    const sni = trojanConfig.sni || trojanConfig.host || server;
    const allowInsecure = trojanConfig.allowInsecure !== undefined ? trojanConfig.allowInsecure : true;
    const network = trojanConfig.network || trojanConfig.net || "tcp";
    const wsPath = trojanConfig.path || "/";
    const wsHost = trojanConfig.host || trojanConfig.sni || server;
    const udp = trojanConfig.udp !== undefined ? trojanConfig.udp : true;
    
    console.log(`🔧 YAML parameters: trojan://${password}@${server}:${port}`);
    console.log(`🔧 Network: ${network}, SNI: ${sni}, Path: ${wsPath}, Host: ${wsHost}`);
    
    // Tambahkan note/header di awal YAML
    let yaml = addYamlNotes('trojan', configName);
    
    yaml += "proxies:\n";
    yaml += `  - name: ${proxyName}\n`;
    yaml += `    server: ${server}\n`;
    yaml += `    port: ${port}\n`;
    yaml += `    type: trojan\n`;
    yaml += `    password: ${password}\n`;
    yaml += `    skip-cert-verify: ${allowInsecure}\n`;
    
    // SELALU tambahkan SNI jika tersedia
    if (sni) {
        yaml += `    sni: ${sni}\n`;
    }
    
    yaml += `    network: ${network}\n`;
    
    if (network === "ws") {
        yaml += `    ws-opts:\n`;
        yaml += `      path: "${wsPath}"\n`;
        // SELALU tambahkan headers Host jika tersedia
        if (wsHost) {
            yaml += `      headers:\n`;
            yaml += `        Host: ${wsHost}\n`;
        }
    }
    
    yaml += `    udp: ${udp}\n`;
    
    console.log('✅ Trojan YAML generated successfully');
    console.log('📄 Generated YAML:\n', yaml);
    return yaml;
}

// State management untuk konversi
const userStates = new Map();

// Fungsi untuk menampilkan menu utama convert Xray - DIPERBARUI
async function showConvertXrayMenu(chatId, user, bot, userMessages, messageId = null) {
    try {
        // Hapus menu utama jika messageId valid
        if (messageId) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
        }

        const menuText = `
🤖 <b>XRAY CONVERTER BOT</b>

Konversi konfigurasi Xray/V2Ray/Trojan ke format YAML untuk Clash, Shadowrocket, dll.

<b>Format yang didukung:</b>
• 🔗 VMess Link
• 🔗 VLESS Link  
• 🔗 Trojan Link

<b>Cara menggunakan:</b>
1. Pilih tipe konfigurasi
2. Kirim link konfigurasi Anda
3. Dapatkan file YAML

Pilih tipe konfigurasi yang ingin dikonversi:
    `;

        const options = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🚀 VMess/VLESS', callback_data: 'xray_type_v2ray' },
                        { text: '🔒 Trojan', callback_data: 'xray_type_trojan' }
                    ],
                    [
                        { text: '📖 Cara Penggunaan', callback_data: 'xray_help' }
                    ],
                    [
                        { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            },
            parse_mode: 'HTML'
        };

        const msg = await bot.sendMessage(chatId, menuText, options);
        
        // Simpan message ID untuk auto-delete system
        if (!userMessages.has(chatId)) {
            userMessages.set(chatId, {
                menuMessageId: null,
                actionMessages: [],
                tempMessages: []
            });
        }
        const userData = userMessages.get(chatId);
        userData.actionMessages.push(msg.message_id);
        
    } catch (error) {
        console.error('❌ Show Convert Xray Menu Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal menampilkan menu convert Xray');
    }
}

// Fungsi untuk menampilkan help - DIPERBARUI
async function showXrayHelp(chatId, bot, userMessages, messageId = null) {
    try {
        // Hapus pesan sebelumnya jika ada
        if (messageId) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
        }

        const helpText = `
📖 <b>CARA MENGGUNAKAN XRAY CONVERTER</b>

<b>Langkah-langkah:</b>
1. Pilih tipe konfigurasi (V2Ray/Trojan)
2. Kirim link konfigurasi Anda
3. Bot akan mengonversi dan mengirim file YAML

<b>Format yang didukung:</b>
• <b>V2Ray:</b> VMess link, VLESS link
• <b>Trojan:</b> Trojan link

<b>Contoh VMess link:</b>
<code>vmess://ew0KICAiYWRkIjogImV4YW1wbGUuY29tIiwNCiAgInBvcnQiOiA0NDMsDQogICJ1aWQiOiAiMTIzNDU2Nzg5MCIsDQogICJhaWQiOiAwLA0KICAibmV0IjogIndzIiwNCiAgImhvc3QiOiAiZXhhbXBsZS5jb20iLA0KICAicGF0aCI6ICIvd3MiLA0KICAidGxzIjogInRscyINCn0=</code>

<b>Contoh VLESS link:</b>
<code>vless://12345678-1234-1234-1234-123456789012@example.com:443?security=tls&sni=example.com&type=ws&path=/vless#VLESS-Proxy</code>

<b>Contoh Trojan link:</b>
<code>trojan://password123@example.com:443?security=tls&sni=example.com&type=ws&path=/trojan#Trojan-Proxy</code>

<b>Keunggulan:</b>
• ⚡ Proses cepat dan akurat
• 🔒 Privasi terjaga (proses lokal)
• 📱 Support semua aplikasi (Clash, dll)
• 🆓 Gratis tanpa batas

Pilih menu di bawah untuk memulai konversi:
    `;

        const options = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🚀 Mulai Konversi', callback_data: 'xray_menu' }
                    ],
                    [
                        { text: '⬅️ Kembali', callback_data: 'xray_menu' }
                    ]
                ]
            },
            parse_mode: 'HTML'
        };

        const msg = await bot.sendMessage(chatId, helpText, options);
        
        if (!userMessages.has(chatId)) {
            userMessages.set(chatId, {
                menuMessageId: null,
                actionMessages: [],
                tempMessages: []
            });
        }
        const userData = userMessages.get(chatId);
        userData.actionMessages.push(msg.message_id);
        
    } catch (error) {
        console.error('❌ Show Xray Help Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal menampilkan bantuan convert Xray');
    }
}

// Handler untuk callback queries convert Xray - DIPERBARUI
async function handleXrayCallback(chatId, data, user, bot, userMessages, messageId = null) {
    try {
        if (data === 'xray_menu') {
            await showConvertXrayMenu(chatId, user, bot, userMessages, messageId);
        }
        else if (data === 'xray_help') {
            await showXrayHelp(chatId, bot, userMessages, messageId);
        }
        else if (data.startsWith('xray_type_')) {
            const type = data.replace('xray_type_', '');
            userStates.set(chatId, { 
                type: type,
                step: 'input_config'
            });
            
            let instructions = '';
            
            if (type === 'v2ray') {
                instructions = `🔗 <b>Konversi VMess/VLESS Link</b>\n\n` +
                             `Silakan kirim link VMess atau VLESS Anda:\n\n` +
                             `<b>Format VMess:</b> <code>vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIs...</code>\n` +
                             `<b>Format VLESS:</b> <code>vless://uuid@example.com:443?...</code>\n\n` +
                             `<i>Catatan: Bot akan otomatis menghapus pesan ini setelah 2 menit jika tidak ada respons</i>`;
            } else if (type === 'trojan') {
                instructions = `🔗 <b>Konversi Trojan Link</b>\n\n` +
                             `Silakan kirim link Trojan Anda:\n\n` +
                             `<b>Format:</b> <code>trojan://password@example.com:443?...</code>\n\n` +
                             `<i>Catatan: Bot akan otomatis menghapus pesan ini setelah 2 menit jika tidak ada respons</i>`;
            }
            
            const message = await bot.sendMessage(
                chatId,
                instructions,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '⬅️ Kembali', callback_data: 'xray_menu' }
                            ]
                        ]
                    }
                }
            );
            
            // Simpan message ID untuk auto-delete
            const userData = userMessages.get(chatId);
            userData.actionMessages.push(message.message_id);
            
            // Set timeout untuk menghapus state setelah 2 menit
            setTimeout(() => {
                if (userStates.has(chatId)) {
                    userStates.delete(chatId);
                    bot.sendMessage(chatId, '⏰ Waktu input telah habis. Kirim /convert_xray untuk memulai lagi.').then(msg => {
                        userData.tempMessages.push(msg.message_id);
                    });
                }
            }, 120000);
        }
    } catch (error) {
        console.error('❌ Xray Callback Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error, silakan coba lagi.').then(msg => {
            const userData = userMessages.get(chatId);
            userData.actionMessages.push(msg.message_id);
        });
    }
}

// Handler untuk memproses konfigurasi Xray
async function handleXrayConfig(chatId, messageText, user, bot, userMessages) {
    const userState = userStates.get(chatId);
    
    if (!userState) {
        return false; // Tidak dalam state konversi
    }
    
    try {
        console.log(`🔄 Processing ${userState.type} config`);
        console.log(`📝 Input text (first 100 chars): ${messageText.substring(0, 100)}`);
        
        // Tampilkan pesan sedang memproses
        const processingMsg = await bot.sendMessage(chatId, '🔄 Memproses konfigurasi...');
        
        // Simpan message processing untuk dihapus nanti
        const userData = userMessages.get(chatId);
        userData.tempMessages.push(processingMsg.message_id);
        
        let yamlResult = '';
        let configType = '';
        let config = {};
        
        // PROSES BERDASARKAN TIPE YANG DIPILIH
        if (userState.type === 'v2ray') {
            // Deteksi otomatis tipe link
            if (messageText.startsWith('vmess://')) {
                console.log('🔗 Processing VMess link...');
                config = parseVMessLink(messageText);
                configType = 'VMess Link';
            } else if (messageText.startsWith('vless://')) {
                console.log('🔗 Processing VLESS link...');
                config = parseVLessLink(messageText);
                configType = 'VLESS Link';
            } else {
                throw new Error('Format link tidak valid. Harus dimulai dengan vmess:// atau vless://');
            }
            
            yamlResult = generateV2RayYaml(config);
            
        } else if (userState.type === 'trojan') {
            if (messageText.startsWith('trojan://')) {
                console.log('🔗 Processing Trojan link...');
                config = parseTrojanLink(messageText);
                configType = 'Trojan Link';
            } else {
                throw new Error('Format link tidak valid. Harus dimulai dengan trojan://');
            }
            
            yamlResult = generateTrojanYaml(config);
        }
        
        // Hapus state user setelah selesai
        userStates.delete(chatId);
        
        // Hapus pesan processing
        await bot.deleteMessage(chatId, processingMsg.message_id);
        
        // Buat nama file
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `config-${userState.type}-${timestamp}.yaml`;
        
        // Simpan file sementara
        const tempDir = './temp';
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
        
        const filePath = path.join(tempDir, filename);
        fs.writeFileSync(filePath, yamlResult);
        
        // Kirim file dengan informasi lengkap
        const caption = `✅ <b>Konversi Berhasil!</b>\n\n` +
                      `📁 <b>Tipe:</b> ${userState.type.toUpperCase()}\n` +
                      `📝 <b>Format Input:</b> ${configType}\n` +
                      `🌐 <b>Server:</b> ${config.add || config.server}\n` +
                      `🔑 <b>Protocol:</b> ${config.type || 'vmess'}\n` +
                      `🛡️ <b>TLS:</b> ${config.tls ? '✅' : '❌'}\n` +
                      `🌐 <b>SNI:</b> ${config.sni || 'Tidak ada'}\n` +
                      `⏰ <b>Generated:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                      `💡 <b>Cara Penggunaan:</b>\n` +
                      `• Untuk OpenClash: Salin file ini ke konfigurasi\n` +
                      `• Untuk aplikasi lain: Import file YAML\n\n` +
                      `<b>Author:</b> PeyxDev`;
        
        await bot.sendDocument(
            chatId,
            filePath,
            {
                caption: caption,
                parse_mode: 'HTML'
            }
        ).then(msg => {
            userData.actionMessages.push(msg.message_id);
        });
        
        // Juga kirim preview teks untuk yang ingin copy-paste
        const previewText = yamlResult.length > 1000 ? 
            yamlResult.substring(0, 1000) + '\n\n... (file lengkap tersedia di dokumen di atas)' : 
            yamlResult;
            
        await bot.sendMessage(
            chatId,
            `<b>📋 Preview Hasil Konversi:</b>\n\n<code>${previewText}</code>\n\n` +
            `💡 <b>Tips:</b> Gunakan file di atas untuk aplikasi seperti Clash, Shadowrocket, dll.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔄 Konversi Lagi', callback_data: 'xray_menu' },
                            { text: '📊 Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            }
        ).then(msg => {
            userData.actionMessages.push(msg.message_id);
        });
        
        // Hapus file sementara
        fs.unlinkSync(filePath);
        
        console.log(`✅ Conversion successful for ${userState.type} ${configType}`);
        return true;
        
    } catch (error) {
        console.error('❌ Xray Conversion Error:', error);
        console.error('Error stack:', error.stack);
        
        // Hapus state user jika error
        userStates.delete(chatId);
        
        let errorMessage = '❌ <b>Gagal mengonversi konfigurasi.</b>\n\n';
        
        if (error.message.includes('vmess://') || error.message.includes('vless://') || error.message.includes('trojan://')) {
            errorMessage += 'Format link tidak valid. Pastikan:\n';
            errorMessage += '• Link lengkap dan tidak terpotong\n';
            errorMessage += '• Dimulai dengan vmess://, vless://, atau trojan://\n';
            errorMessage += '• Tidak ada spasi atau karakter tambahan di awal/akhir\n\n';
            errorMessage += '💡 <b>Contoh format yang benar:</b>\n';
            errorMessage += '• VMess: <code>vmess://eyJhZGQiOiJleGFtcGxlLmNvbSIs...</code>\n';
            errorMessage += '• VLESS: <code>vless://uuid@example.com:443?...</code>\n';
            errorMessage += '• Trojan: <code>trojan://password@example.com:443?...</code>';
        } else if (error.message.includes('URL')) {
            errorMessage += 'Format URL tidak valid. Pastikan link sesuai dengan format yang dipilih.';
        } else if (error.message.includes('valid') || error.message.includes('missing')) {
            errorMessage += error.message;
        } else {
            errorMessage += 'Error: ' + error.message;
        }
        
        errorMessage += '\n\n<b>💡 Tips:</b>\n';
        errorMessage += '• Salin lengkap link dari aplikasi client\n';
        errorMessage += '• Pastikan tidak ada karakter tambahan\n';
        errorMessage += '• Cek contoh di menu "Cara Penggunaan"\n\n';
        errorMessage += 'Kirim /convert_xray untuk mencoba lagi.';
        
        await bot.sendMessage(chatId, errorMessage, { 
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🔄 Coba Lagi', callback_data: 'xray_menu' },
                        { text: '📖 Bantuan', callback_data: 'xray_help' }
                    ]
                ]
            }
        }).then(msg => {
            userData.actionMessages.push(msg.message_id);
        });
        
        return true;
    }
}

// Export functions
module.exports = {
    showConvertXrayMenu,
    handleXrayCallback,
    handleXrayConfig,
    userStates
};