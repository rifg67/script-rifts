const https = require('https');
const fs = require('fs');
const path = require('path');

// State management untuk proses pointing domain
const pointingState = new Map();

// File untuk menyimpan credentials Cloudflare
const CLOUDFLARE_CREDENTIALS_FILE = path.join(__dirname, 'cloudflare_credentials.json');

class PointingDomain {
    constructor() {
        // Load credentials yang tersimpan
        this.loadCloudflareCredentials();
    }

    // ===============================
    // FUNGSI MANAJEMEN CREDENTIALS PERSISTEN
    // ===============================

    // Load credentials dari file
    loadCloudflareCredentials() {
        try {
            if (fs.existsSync(CLOUDFLARE_CREDENTIALS_FILE)) {
                const data = fs.readFileSync(CLOUDFLARE_CREDENTIALS_FILE, 'utf8');
                this.savedCredentials = JSON.parse(data);
                console.log('✅ Cloudflare credentials loaded from file');
            } else {
                this.savedCredentials = {};
                console.log('ℹ️ No saved Cloudflare credentials found');
            }
        } catch (error) {
            console.error('❌ Error loading Cloudflare credentials:', error);
            this.savedCredentials = {};
        }
    }

    // Save credentials ke file
    saveCloudflareCredentials(chatId, credentials) {
        try {
            this.savedCredentials[chatId] = {
                email: credentials.email,
                apiKey: credentials.apiKey,
                zoneId: credentials.zoneId,
                zoneName: credentials.zoneName,
                lastUpdated: new Date().toISOString()
            };

            fs.writeFileSync(CLOUDFLARE_CREDENTIALS_FILE, JSON.stringify(this.savedCredentials, null, 2));
            console.log(`✅ Cloudflare credentials saved for chat: ${chatId}`);
            return true;
        } catch (error) {
            console.error('❌ Error saving Cloudflare credentials:', error);
            return false;
        }
    }

    // Get credentials untuk chat tertentu
    getSavedCredentials(chatId) {
        return this.savedCredentials[chatId];
    }

    // Hapus credentials yang tersimpan
    deleteSavedCredentials(chatId) {
        try {
            if (this.savedCredentials[chatId]) {
                delete this.savedCredentials[chatId];
                fs.writeFileSync(CLOUDFLARE_CREDENTIALS_FILE, JSON.stringify(this.savedCredentials, null, 2));
                console.log(`✅ Cloudflare credentials deleted for chat: ${chatId}`);
                return true;
            }
            return false;
        } catch (error) {
            console.error('❌ Error deleting Cloudflare credentials:', error);
            return false;
        }
    }

    // ===============================
    // FUNGSI UTAMA YANG HARUS ADA - DIPERBARUI DENGAN CREDENTIALS PERSISTEN
    // ===============================

    // Menu utama pointing domain - FUNGSI WAJIB - DIPERBARUI
    async showMenu(chatId, user, bot, messageId = null) {
        try {
            // Hapus menu utama jika messageId valid
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            // Cek apakah sudah ada credentials yang tersimpan
            const savedCreds = this.getSavedCredentials(chatId);
            const hasCredentials = savedCreds && savedCreds.email && savedCreds.apiKey && savedCreds.zoneId;

            // Cek apakah credentials sudah di-load di state
            const state = pointingState.get(chatId);
            const stateHasCredentials = state && state.cfApi;

            let statusText = '';
            if (hasCredentials && stateHasCredentials) {
                statusText = `✅ <b>Status:</b> Cloudflare terkoneksi (${savedCreds.zoneName})`;
            } else if (hasCredentials && !stateHasCredentials) {
                statusText = `🔵 <b>Status:</b> Credentials tersimpan, klik "Load Credentials"`;
            } else {
                statusText = `❌ <b>Status:</b> Belum setup Cloudflare`;
            }

            const menuText = `
🔗 <b>POINTING DOMAIN MANAGER</b>

${statusText}

Fitur untuk mengelola pointing domain ke IP VPS menggunakan Cloudflare:

• 🌐 <b>List Domains</b> - Lihat semua domain yang terpointing
• ➕ <b>Add Domain</b> - Tambah pointing domain baru
• ✏️ <b>Edit Domain</b> - Edit domain atau IP yang sudah ada
• 🗑️ <b>Delete Domain</b> - Hapus pointing domain
• ⚙️ <b>Setup Cloudflare</b> - Konfigurasi API Cloudflare
• 🌟 <b>Auto Wildcard</b> - Setup wildcard domain dengan worker

📝 <b>Cara Penggunaan:</b>
1. Setup Cloudflare terlebih dahulu
2. Ikuti intruksi bot
3. Kelola domain dengan mudah

Pilih aksi yang ingin dilakukan:
        `;

            const keyboard = [
                [
                    { text: '🌐 List Domains', callback_data: 'pointing_list' },
                    { text: '➕ Add Domain', callback_data: 'pointing_add' }
                ],
                [
                    { text: '✏️ Edit Domain', callback_data: 'pointing_edit' },
                    { text: '🗑️ Delete Domain', callback_data: 'pointing_delete' }
                ],
                [
                    { text: '⚙️ Setup Cloudflare', callback_data: 'pointing_setup' },
                    { text: '🌟 Auto Wildcard', callback_data: 'pointing_wildcard' }
                ],
                [
                    { text: '📊 Menu Utama', callback_data: 'main_menu' }
                ]
            ];

            const options = {
                reply_markup: {
                    inline_keyboard: keyboard
                },
                parse_mode: 'HTML'
            };

            await bot.sendMessage(chatId, menuText, options);
        } catch (error) {
            console.error('❌ Show Menu Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal menampilkan menu pointing domain');
        }
    }

    // ===============================
    // FUNGSI EDIT DOMAIN BARU
    // ===============================

    async handleEditDomain(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '🌐 Mengambil data domain untuk diedit...');

            try {
                const records = await state.cfApi.listDNSRecords();
                
                if (!records || records.length === 0) {
                    await bot.editMessageText('📭 Tidak ada domain records ditemukan di Cloudflare.', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });
                    return;
                }

                // Tampilkan halaman pertama untuk edit
                await this.showEditDomainPage(chatId, bot, loadingMsg.message_id, records, 0, 8, Math.ceil(records.length / 8));

            } catch (apiError) {
                console.error('❌ Cloudflare API Error in edit domains:', apiError);
                await bot.editMessageText(`❌ Gagal mengambil data domain dari Cloudflare:\n\n<code>${apiError.message}</code>`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Load Credentials', callback_data: 'pointing_load_credentials' }],
                            [{ text: '⚙️ Setup Ulang', callback_data: 'pointing_setup' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ Edit Domain Process Error:', error);
            await bot.sendMessage(chatId, `❌ Terjadi error tidak terduga:\n\n<code>${error.message}</code>`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });
        }
    }

    // Tampilkan halaman edit domain
    async showEditDomainPage(chatId, bot, messageId, records, currentPage, pageSize, totalPages) {
        const startIndex = currentPage * pageSize;
        const endIndex = Math.min(startIndex + pageSize, records.length);
        const pageRecords = records.slice(startIndex, endIndex);

        // Buat keyboard dengan pagination
        const keyboard = [];

        // Tambahkan records untuk halaman ini
        pageRecords.forEach(record => {
            // Persingkat teks tombol jika terlalu panjang
            const displayName = record.name.length > 20 ? record.name.substring(0, 17) + '...' : record.name;
            const icon = record.type === 'A' ? '🅰️' : record.type === 'CNAME' ? '©️' : '📄';
            
            keyboard.push([
                { 
                    text: `${icon} ${displayName}`, 
                    callback_data: `pointing_edit_select_${record.id}` 
                }
            ]);
        });

        // Tambahkan navigasi halaman
        const navButtons = [];
        if (currentPage > 0) {
            navButtons.push({ 
                text: '⬅️ Sebelumnya', 
                callback_data: `pointing_edit_page_${currentPage - 1}` 
            });
        }
        if (currentPage < totalPages - 1) {
            navButtons.push({ 
                text: 'Selanjutnya ➡️', 
                callback_data: `pointing_edit_page_${currentPage + 1}` 
            });
        }
        
        if (navButtons.length > 0) {
            keyboard.push(navButtons);
        }

        // Tombol aksi
        keyboard.push([{ text: '🔄 Refresh', callback_data: 'pointing_edit' }]);
        keyboard.push([{ text: '❌ Batal', callback_data: 'pointing_domain' }]);

        const messageText = `✏️ <b>Edit Domain</b>\n\nHalaman ${currentPage + 1}/${totalPages}\nPilih domain yang ingin diedit:`;

        await bot.editMessageText(messageText, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    }

    // Handler untuk pagination edit domain
    async handleEditDomainPage(chatId, bot, page) {
        try {
            const state = pointingState.get(chatId);
            
            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan setup ulang Cloudflare.');
                return;
            }

            const records = await state.cfApi.listDNSRecords();
            const pageSize = 8;
            const totalPages = Math.ceil(records.length / pageSize);
            
            const loadingMsg = await bot.sendMessage(chatId, '🔄 Memuat halaman...');
            
            await this.showEditDomainPage(chatId, bot, loadingMsg.message_id, records, page, pageSize, totalPages);

        } catch (error) {
            console.error('❌ Edit Domain Page Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memuat halaman domain');
        }
    }

    // Handler untuk memilih domain yang akan diedit
    async handleEditDomainSelection(chatId, recordId, bot) {
        try {
            const state = pointingState.get(chatId);
            
            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan setup ulang Cloudflare.');
                return;
            }

            // Ambil detail record
            const records = await state.cfApi.listDNSRecords();
            const selectedRecord = records.find(record => record.id === recordId);
            
            if (!selectedRecord) {
                await bot.sendMessage(chatId, '❌ Domain tidak ditemukan.');
                return;
            }

            // Simpan record yang dipilih ke state
            state.editingRecord = selectedRecord;
            pointingState.set(chatId, state);

            // Tampilkan menu edit
            await this.showEditOptions(chatId, bot, selectedRecord);

        } catch (error) {
            console.error('❌ Edit Domain Selection Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memuat detail domain');
        }
    }

    // Tampilkan opsi edit untuk domain
    async showEditOptions(chatId, bot, record) {
        const editText = `
✏️ <b>Edit Domain</b>

🌐 <b>Domain:</b> <code>${record.name}</code>
📡 <b>Type:</b> ${record.type}
🔗 <b>Target:</b> <code>${record.content}</code>
🛡️ <b>Proxy:</b> ${record.proxied ? '✅ AKTIF' : '❌ NON-AKTIF'}
⏱️ <b>TTL:</b> ${record.ttl}

Pilih yang ingin diedit:
        `;

        await bot.sendMessage(chatId, editText, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🌐 Edit Domain Name', callback_data: 'pointing_edit_name' },
                        { text: '🔗 Edit IP/Target', callback_data: 'pointing_edit_ip' }
                    ],
                    [
                        { text: '🛡️ Toggle Proxy', callback_data: 'pointing_edit_proxy' },
                        { text: '📡 Edit Type', callback_data: 'pointing_edit_type' }
                    ],
                    [
                        { text: '❌ Batal', callback_data: 'pointing_edit' }
                    ]
                ]
            }
        });
    }

    // Handler untuk edit nama domain
    async handleEditDomainName(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            state.step = 'edit_domain_name';
            pointingState.set(chatId, state);

            const msg = await bot.sendMessage(chatId, `✏️ <b>Edit Nama Domain</b>\n\nDomain saat ini: <code>${state.editingRecord.name}</code>\n\nMasukkan nama domain baru:`, {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const newDomainName = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!this.isValidDomain(newDomainName)) {
                        await bot.sendMessage(chatId, '❌ Format domain tidak valid.\n\nContoh yang benar:\n• <code>example.com</code>\n• <code>sub.example.com</code>', {
                            parse_mode: 'HTML'
                        });
                        return;
                    }

                    // Update domain name
                    await this.updateDomainRecord(chatId, bot, { name: newDomainName });

                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);

        } catch (error) {
            console.error('❌ Edit Domain Name Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses edit nama domain');
        }
    }

    // Handler untuk edit IP/target
    async handleEditIP(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            state.step = 'edit_ip';
            pointingState.set(chatId, state);

            const validation = state.editingRecord.type === 'A' ? this.isValidIP : (value) => true;

            const msg = await bot.sendMessage(chatId, `🔗 <b>Edit ${state.editingRecord.type} Record</b>\n\nTarget saat ini: <code>${state.editingRecord.content}</code>\n\nMasukkan ${state.editingRecord.type === 'A' ? 'IP Address' : 'target'} baru:`, {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const newContent = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!validation(newContent)) {
                        await bot.sendMessage(chatId, `❌ Format ${state.editingRecord.type === 'A' ? 'IP Address' : 'target'} tidak valid.`, {
                            parse_mode: 'HTML'
                        });
                        return;
                    }

                    // Update content
                    await this.updateDomainRecord(chatId, bot, { content: newContent });

                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);

        } catch (error) {
            console.error('❌ Edit IP Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses edit IP/target');
        }
    }

    // Handler untuk toggle proxy
    async handleToggleProxy(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            const newProxiedStatus = !state.editingRecord.proxied;

            // Update proxied status
            await this.updateDomainRecord(chatId, bot, { proxied: newProxiedStatus });

        } catch (error) {
            console.error('❌ Toggle Proxy Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses toggle proxy');
        }
    }

    // Handler untuk edit tipe record
    async handleEditType(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            await bot.sendMessage(chatId, '📡 <b>Edit Tipe Record</b>\n\nPilih tipe record baru:', {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🅰️ A Record', callback_data: 'pointing_edit_type_A' },
                            { text: '©️ CNAME Record', callback_data: 'pointing_edit_type_CNAME' }
                        ],
                        [
                            { text: '❌ Batal', callback_data: 'pointing_edit_options' }
                        ]
                    ]
                }
            });

        } catch (error) {
            console.error('❌ Edit Type Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses edit tipe record');
        }
    }

    // Handler untuk konfirmasi perubahan tipe record
    async handleEditTypeSelection(chatId, newType, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            // Update record type
            await this.updateDomainRecord(chatId, bot, { type: newType });

        } catch (error) {
            console.error('❌ Edit Type Selection Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses perubahan tipe record');
        }
    }

    // Fungsi untuk update record di Cloudflare
    async updateDomainRecord(chatId, bot, updates) {
        const state = pointingState.get(chatId);
        const record = state.editingRecord;

        const loadingMsg = await bot.sendMessage(chatId, '⏳ Memperbarui domain di Cloudflare...');

        try {
            const updateData = {
                type: updates.type || record.type,
                name: updates.name || record.name,
                content: updates.content || record.content,
                ttl: 1,
                proxied: updates.proxied !== undefined ? updates.proxied : record.proxied
            };

            const result = await state.cfApi.updateDNSRecord(record.id, updateData);

            if (result.success) {
                // Clear editing state
                delete state.editingRecord;
                state.step = 'ready';
                pointingState.set(chatId, state);

                let successMessage = `✅ <b>Domain Berhasil Diperbarui!</b>\n\n`;
                
                if (updates.name) successMessage += `🌐 <b>Domain:</b> <code>${updates.name}</code>\n`;
                if (updates.type) successMessage += `📡 <b>Type:</b> ${updates.type}\n`;
                if (updates.content) successMessage += `🔗 <b>Target:</b> <code>${updates.content}</code>\n`;
                if (updates.proxied !== undefined) successMessage += `🛡️ <b>Proxy:</b> ${updates.proxied ? 'AKTIF' : 'NON-AKTIF'}\n`;

                await bot.editMessageText(successMessage, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🌐 Lihat Domains', callback_data: 'pointing_list' }],
                            [{ text: '✏️ Edit Lainnya', callback_data: 'pointing_edit' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });

            } else {
                throw new Error(result.errors[0]?.message || 'Gagal memperbarui domain');
            }

        } catch (error) {
            console.error('❌ Update Domain Record Error:', error);
            await bot.editMessageText(`❌ Gagal memperbarui domain:\n${error.message}`, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'pointing_edit_options' }],
                        [{ text: '🔙 Kembali', callback_data: 'pointing_edit' }]
                    ]
                }
            });
        }
    }

    // Handler untuk kembali ke opsi edit
    async handleBackToEditOptions(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state || !state.editingRecord) {
                await bot.sendMessage(chatId, '❌ Sesi edit telah berakhir. Silakan pilih domain lagi.');
                return;
            }

            await this.showEditOptions(chatId, bot, state.editingRecord);

        } catch (error) {
            console.error('❌ Back to Edit Options Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal kembali ke menu edit');
        }
    }

    // ===============================
    // FUNGSI LOAD CREDENTIALS YANG TERSIMPAN
    // ===============================

    async handleLoadCredentials(chatId, user, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            const savedCreds = this.getSavedCredentials(chatId);
            if (!savedCreds) {
                await bot.sendMessage(chatId, '❌ Tidak ada credentials Cloudflare yang tersimpan. Silakan setup terlebih dahulu.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '🔄 Memuat credentials Cloudflare...');

            try {
                // Test koneksi dengan credentials yang tersimpan
                const testResult = await this.testCloudflareAuth(
                    savedCreds.email, 
                    savedCreds.apiKey, 
                    savedCreds.zoneId
                );

                if (testResult.success) {
                    // Setup state dengan credentials yang tersimpan
                    pointingState.set(chatId, {
                        step: 'ready',
                        cfApi: new CloudflareAPI(savedCreds.email, savedCreds.apiKey, savedCreds.zoneId),
                        zoneName: savedCreds.zoneName,
                        userId: user.id.toString(),
                        data: {
                            email: savedCreds.email,
                            apiKey: savedCreds.apiKey,
                            zoneId: savedCreds.zoneId
                        }
                    });

                    await bot.editMessageText(`✅ <b>Credentials Berhasil Dimuat!</b>\n\n🌐 <b>Domain:</b> ${savedCreds.zoneName}\n📧 <b>Email:</b> ${savedCreds.email}\n🔑 <b>API Key:</b> ${savedCreds.apiKey.substring(0, 8)}...\n🆔 <b>Zone ID:</b> ${savedCreds.zoneId.substring(0, 8)}...\n\nSekarang Anda bisa mengelola domain.`, {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🌐 List Domains', callback_data: 'pointing_list' }],
                                [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                                [{ text: '✏️ Edit Domain', callback_data: 'pointing_edit' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });
                } else {
                    throw new Error(testResult.error);
                }

            } catch (error) {
                console.error('❌ Load Credentials Error:', error);
                
                let errorMessage = `❌ <b>Gagal memuat credentials:</b>\n\n${error.message}`;
                
                if (error.message.includes('Authentication') || error.message.includes('auth')) {
                    errorMessage += '\n\n🔐 <b>Credentials sudah tidak valid.</b>\nSilakan setup ulang Cloudflare.';
                    // Hapus credentials yang tidak valid
                    this.deleteSavedCredentials(chatId);
                }
                
                await bot.editMessageText(errorMessage, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '⚙️ Setup Ulang', callback_data: 'pointing_setup' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ Handle Load Credentials Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memuat credentials');
        }
    }

    // ===============================
    // FUNGSI MANAGE CREDENTIALS
    // ===============================

    async handleManageCredentials(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            const savedCreds = this.getSavedCredentials(chatId);
            if (!savedCreds) {
                await bot.sendMessage(chatId, '❌ Tidak ada credentials Cloudflare yang tersimpan.');
                return;
            }

            const state = pointingState.get(chatId);
            const isLoaded = state && state.cfApi;

            const credsText = `
🗂️ <b>MANAGE CLOUDFLARE CREDENTIALS</b>

🌐 <b>Domain:</b> ${savedCreds.zoneName}
📧 <b>Email:</b> <code>${savedCreds.email}</code>
🔑 <b>API Key:</b> <code>${savedCreds.apiKey.substring(0, 8)}...</code>
🆔 <b>Zone ID:</b> <code>${savedCreds.zoneId.substring(0, 8)}...</code>
📅 <b>Terakhir Update:</b> ${new Date(savedCreds.lastUpdated).toLocaleString('id-ID')}
🟢 <b>Status:</b> ${isLoaded ? 'TERLOAD' : 'BELUM DIMUAT'}

Pilih aksi untuk mengelola credentials:
            `;

            const keyboard = [];

            if (!isLoaded) {
                keyboard.push([{ text: '🔄 Load Credentials', callback_data: 'pointing_load_credentials' }]);
            }

            keyboard.push(
                [{ text: '🔄 Update Credentials', callback_data: 'pointing_setup' }],
                [{ text: '🗑️ Delete Credentials', callback_data: 'pointing_delete_creds' }],
                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
            );

            await bot.sendMessage(chatId, credsText, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });

        } catch (error) {
            console.error('❌ Manage Credentials Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat mengelola credentials');
        }
    }

    async handleDeleteCredentials(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            const success = this.deleteSavedCredentials(chatId);
            
            if (success) {
                // Juga hapus dari state
                pointingState.delete(chatId);
                
                await bot.sendMessage(chatId, '✅ Credentials Cloudflare berhasil dihapus.', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '⚙️ Setup Baru', callback_data: 'pointing_setup' }],
                            [{ text: '🔙 Menu Utama', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            } else {
                await bot.sendMessage(chatId, '❌ Gagal menghapus credentials atau credentials tidak ditemukan.');
            }

        } catch (error) {
            console.error('❌ Delete Credentials Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat menghapus credentials');
        }
    }

    // Handler untuk setup Cloudflare - FUNGSI WAJIB - DIPERBARUI
    async handleSetupCloudflare(chatId, user, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            // Inisialisasi state
            pointingState.set(chatId, {
                step: 'setup_email',
                data: {},
                userId: user.id.toString()
            });

            await this.askForCloudflareEmail(chatId, bot);

        } catch (error) {
            console.error('❌ Setup Cloudflare Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memulai setup Cloudflare');
        }
    }

    // ===============================
    // FUNGSI LIST DOMAINS - WAJIB - DIPERBARUI
    // ===============================

    async handleListDomains(chatId, bot, page = 0, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }
            
            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '🌐 Mengambil data domain dari Cloudflare...');

            try {
                const records = await state.cfApi.listDNSRecords();
                
                if (!records || records.length === 0) {
                    await bot.editMessageText('📭 Tidak ada domain records ditemukan di Cloudflare.', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });
                    return;
                }

                // Pagination settings
                const pageSize = 10;
                const totalRecords = records.length;
                const totalPages = Math.ceil(totalRecords / pageSize);
                const startIndex = page * pageSize;
                const endIndex = Math.min(startIndex + pageSize, totalRecords);
                const displayRecords = records.slice(startIndex, endIndex);

                let domainList = `<b>🌐 DAFTAR DOMAIN CLOUDFLARE</b>\n\n`;
                domainList += `<b>Domain:</b> ${state.zoneName}\n`;
                domainList += `<b>Halaman:</b> ${page + 1}/${totalPages}\n`;
                domainList += `<b>Total Records:</b> ${totalRecords}\n\n`;
                
                // Urutkan records berdasarkan type dan name
                displayRecords.sort((a, b) => {
                    if (a.type !== b.type) return a.type.localeCompare(b.type);
                    return a.name.localeCompare(b.name);
                });

                displayRecords.forEach((record, index) => {
                    const globalIndex = startIndex + index + 1;
                    const status = record.proxied ? '🟢 Proxied' : '🔵 DNS Only';
                    const icon = record.type === 'A' ? '🔗' : record.type === 'CNAME' ? '📎' : '📄';
                    
                    domainList += `<b>${globalIndex}. ${icon} ${record.name}</b> (${record.type})\n`;
                    domainList += `   📝 <b>Content:</b> <code>${record.content}</code>\n`;
                    domainList += `   ⏱️ <b>TTL:</b> ${record.ttl} | <b>Status:</b> ${status}\n\n`;
                });

                // Tambahkan pagination info
                if (totalPages > 1) {
                    domainList += `📋 <i>Menampilkan records ${startIndex + 1}-${endIndex} dari ${totalRecords}</i>\n\n`;
                }

                // Buat keyboard dengan pagination
                const keyboard = [];
                
                // Tombol navigasi halaman
                const navButtons = [];
                if (page > 0) {
                    navButtons.push({ text: '⬅️ Sebelumnya', callback_data: `pointing_list_page_${page - 1}` });
                }
                if (page < totalPages - 1) {
                    navButtons.push({ text: 'Selanjutnya ➡️', callback_data: `pointing_list_page_${page + 1}` });
                }
                if (navButtons.length > 0) {
                    keyboard.push(navButtons);
                }

                // Tombol aksi
                keyboard.push(
                    [{ text: '🔄 Refresh', callback_data: `pointing_list_page_${page}` }],
                    [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                    [{ text: '✏️ Edit Domain', callback_data: 'pointing_edit' }]
                );

                // Tombol kembali
                keyboard.push([{ text: '🔙 Kembali ke Menu', callback_data: 'pointing_domain' }]);

                await bot.editMessageText(domainList, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: keyboard
                    }
                });

            } catch (apiError) {
                console.error('❌ Cloudflare API Error in list domains:', apiError);
                await bot.editMessageText(`❌ Gagal mengambil data domain dari Cloudflare:\n\n<code>${apiError.message}</code>`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Load Credentials', callback_data: 'pointing_load_credentials' }],
                            [{ text: '⚙️ Setup Ulang', callback_data: 'pointing_setup' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ List Domains Error:', error);
            await bot.sendMessage(chatId, `❌ Terjadi error tidak terduga:\n\n<code>${error.message}</code>`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });
        }
    }

    // ===============================
    // FUNGSI ADD DOMAIN - WAJIB - DIPERBARUI
    // ===============================

    async handleAddDomain(chatId, user, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            pointingState.set(chatId, {
                ...state,
                step: 'domain_name',
                addData: {}
            });

            await this.askForDomainName(chatId, bot);

        } catch (error) {
            console.error('❌ Add Domain Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memulai proses tambah domain');
        }
    }

    // ===============================
    // FUNGSI DELETE DOMAIN - OPTIMIZED - DIPERBARUI
    // ===============================

    async handleOptimizedDeleteDomain(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '🌐 Mengambil data domain...');

            try {
                const records = await state.cfApi.listDNSRecords();
                
                if (!records || records.length === 0) {
                    await bot.editMessageText('📭 Tidak ada domain yang bisa dihapus.', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });
                    return;
                }

                // OPTIMISASI: Batasi jumlah records yang ditampilkan dan gunakan pagination
                const pageSize = 8; // Kurangi menjadi 8 untuk lebih aman
                const totalPages = Math.ceil(records.length / pageSize);
                
                // Tampilkan records halaman pertama
                await this.showDeleteDomainPage(chatId, bot, loadingMsg.message_id, records, 0, pageSize, totalPages);

            } catch (apiError) {
                console.error('❌ Cloudflare API Error in delete domains:', apiError);
                await bot.editMessageText(`❌ Gagal memuat daftar domain:\n\n<code>${apiError.message}</code>`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Load Credentials', callback_data: 'pointing_load_credentials' }],
                            [{ text: '⚙️ Setup Ulang', callback_data: 'pointing_setup' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ Delete Domain Process Error:', error);
            await bot.sendMessage(chatId, `❌ Terjadi error tidak terduga:\n\n<code>${error.message}</code>`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });
        }
    }

    // ===============================
    // FUNGSI WILDCARD - WAJIB - DIPERBARUI
    // ===============================

    async handleAutoWildcard(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            const wildcardText = `
🌟 <b>AUTO WILDCARD SETUP</b>

Fitur ini akan membuat:
• 🎯 Wildcard DNS record (*.domain.com)
• 🔄 Cloudflare Worker untuk routing
• 🚀 Auto-redirect ke target IP

<b>Keuntungan:</b>
• Semua subdomain otomatis aktif
• Routing fleksibel melalui worker
• Mudah dikelola

Lanjutkan setup?
            `;

            await bot.sendMessage(chatId, wildcardText, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🚀 Setup Wildcard', callback_data: 'pointing_wildcard_setup' },
                            { text: '📖 Cara Kerja', callback_data: 'pointing_wildcard_info' }
                        ],
                        [
                            { text: '❌ Batal', callback_data: 'pointing_domain' }
                        ]
                    ]
                }
            });

        } catch (error) {
            console.error('❌ Auto Wildcard Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memulai setup wildcard');
        }
    }

    async setupWildcardDomain(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Silakan setup Cloudflare terlebih dahulu dengan klik "Setup Cloudflare" atau "Load Credentials" jika sudah pernah setup.');
                return;
            }

            pointingState.set(chatId, {
                ...state,
                step: 'wildcard_ip',
                wildcardData: {}
            });

            await this.askForWildcardIP(chatId, bot);

        } catch (error) {
            console.error('❌ Setup Wildcard Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memulai setup wildcard');
        }
    }

    async showWildcardInfo(chatId, bot, messageId = null) {
        try {
            // Hapus pesan sebelumnya jika ada
            if (messageId) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
            }

            let state = pointingState.get(chatId);
            
            // Jika tidak ada state, coba load dari saved credentials
            if (!state || !state.cfApi) {
                const savedCreds = this.getSavedCredentials(chatId);
                if (savedCreds) {
                    await bot.sendMessage(chatId, '🔄 Credentials ditemukan, memuat otomatis...');
                    await this.handleLoadCredentials(chatId, { id: chatId }, bot);
                    state = pointingState.get(chatId); // Refresh state
                }
            }

            if (!state || !state.zoneName) {
                await bot.sendMessage(chatId, '❌ Tidak ada data domain yang aktif. Silakan setup Cloudflare terlebih dahulu.');
                return;
            }

            const infoText = `
📖 <b>CARA KERJA WILDCARD DOMAIN</b>

🌟 <b>Konsep Wildcard:</b>
• DNS Record: <code>*.${state.zoneName}</code> → IP Target
• Cloudflare Worker: Menangani routing semua subdomain
• Auto Redirect: Semua subdomain otomatis aktif

🔄 <b>Alur Kerja:</b>
1. User akses: <code>subdomain.${state.zoneName}</code>
2. DNS mengarah ke Cloudflare Worker
3. Worker forward request ke IP target
4. Response dikembalikan ke user

⚡ <b>Keuntungan:</b>
• Tidak perlu setup subdomain satu per satu
• Semua subdomain otomatis aktif
• Fleksibel untuk development
• Cocok untuk VPN/Proxy

🔧 <b>Kebutuhan:</b>
• Domain aktif di Cloudflare
• Akses API Cloudflare
• Worker quota tersedia

🚀 <b>Langkah Setup:</b>
1. Buat wildcard DNS record (*.domain.com)
2. Deploy Cloudflare Worker
3. Setup route untuk wildcard
4. Test subdomain

Pilih aksi selanjutnya:
            `;

            await bot.sendMessage(chatId, infoText, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🚀 Setup Wildcard', callback_data: 'pointing_wildcard_setup' },
                            { text: '📋 Lihat Script', callback_data: 'pointing_wildcard_script' }
                        ],
                        [
                            { text: '🔙 Kembali', callback_data: 'pointing_domain' }
                        ]
                    ]
                }
            });

        } catch (error) {
            console.error('❌ Show Wildcard Info Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal menampilkan info wildcard');
        }
    }

    // ===============================
    // FUNGSI BANTUAN TAMBAHAN YANG DIPERLUKAN
    // ===============================

    // Minta email Cloudflare - FUNGSI WAJIB
    async askForCloudflareEmail(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'setup_email';

            const msg = await bot.sendMessage(chatId, '⚙️ <b>Setup Cloudflare API - Step 1/3</b>\n\nMasukkan email akun Cloudflare Anda:', {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const email = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!email || !email.includes('@')) {
                        await bot.sendMessage(chatId, '❌ Format email tidak valid. Silakan masukkan email yang benar.');
                        return;
                    }

                    state.data.email = email;
                    pointingState.set(chatId, state);
                    
                    await this.askForCloudflareAPIKey(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask Email Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses email');
        }
    }

    // Minta API Key Cloudflare - FUNGSI WAJIB
    async askForCloudflareAPIKey(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'setup_api_key';

            const helpText = `
⚙️ <b>Setup Cloudflare API - Step 2/3</b>

<b>Cara mendapatkan Global API Key:</b>
1. Login ke <a href="https://dash.cloudflare.com">Cloudflare Dashboard</a>
2. Klik ikon profil di kanan atas → <b>My Profile</b>
3. Pilih tab <b>API Tokens</b>
4. Scroll ke section <b>API Keys</b>
5. Klik <b>View</b> di sebelah <b>Global API Key</b>
6. Masukkan password Anda
7. <b>Copy seluruh teks API Key</b>

Masukkan Global API Key Anda:
        `;

            const msg = await bot.sendMessage(chatId, helpText, {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true },
                disable_web_page_preview: true
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const apiKey = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    // Validasi dasar API Key
                    if (!apiKey || apiKey.length < 10) {
                        await bot.sendMessage(chatId, '❌ API Key terlalu pendek. Pastikan Anda copy seluruh API Key.');
                        return;
                    }

                    state.data.apiKey = apiKey;
                    pointingState.set(chatId, state);
                    
                    await this.askForCloudflareZoneID(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask API Key Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses API Key');
        }
    }

    // Minta Zone ID Cloudflare - FUNGSI WAJIB
    async askForCloudflareZoneID(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'setup_zone_id';

            const helpText = `
⚙️ <b>Setup Cloudflare API - Step 3/3</b>

<b>Cara mendapatkan Zone ID:</b>
1. Buka <a href="https://dash.cloudflare.com">Cloudflare Dashboard</a>
2. <b>Klik domain</b> yang ingin dikelola
3. Di sidebar kiri, scroll ke <b>Overview</b>
4. Di panel kanan, cari <b>API</b> section
5. Copy <b>Zone ID</b> (string panjang)

Masukkan Zone ID untuk domain Anda:
        `;

            const msg = await bot.sendMessage(chatId, helpText, {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true },
                disable_web_page_preview: true
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const zoneId = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!zoneId || zoneId.length < 10) {
                        await bot.sendMessage(chatId, '❌ Zone ID terlalu pendek. Pastikan Anda copy Zone ID yang benar.');
                        return;
                    }

                    state.data.zoneId = zoneId;
                    pointingState.set(chatId, state);
                    
                    await this.testCloudflareConnection(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask Zone ID Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses Zone ID');
        }
    }

    // Test koneksi Cloudflare - FUNGSI WAJIB - DIPERBARUI UNTUK SIMPAN CREDENTIALS
    async testCloudflareConnection(chatId, bot) {
        const state = pointingState.get(chatId);
        const { email, apiKey, zoneId } = state.data;

        const loadingMsg = await bot.sendMessage(chatId, '🔗 Testing koneksi ke Cloudflare...');

        try {
            console.log('🔧 Testing Cloudflare credentials...');
            
            // Test dengan method yang lebih reliable
            const testResult = await this.testCloudflareAuth(email, apiKey, zoneId);
            
            if (testResult.success) {
                // Simpan credentials PERSISTEN
                const saveResult = this.saveCloudflareCredentials(chatId, {
                    email: email,
                    apiKey: apiKey,
                    zoneId: zoneId,
                    zoneName: testResult.zoneName
                });

                // Simpan credentials untuk session ini
                state.cfApi = new CloudflareAPI(email, apiKey, zoneId);
                state.zoneName = testResult.zoneName;
                pointingState.set(chatId, state);

                let successMessage = `✅ <b>Setup Cloudflare Berhasil!</b>\n\n🌐 <b>Domain:</b> ${testResult.zoneName}\n📧 <b>Email:</b> ${email}\n🔑 <b>API Key:</b> ${apiKey.substring(0, 8)}...\n🆔 <b>Zone ID:</b> ${zoneId.substring(0, 8)}...\n\n`;

                if (saveResult) {
                    successMessage += `💾 <b>Credentials telah disimpan secara permanen!</b>\nAnda tidak perlu setup ulang di session berikutnya.`;
                } else {
                    successMessage += `⚠️ <b>Credentials gagal disimpan.</b>\nAnda perlu setup ulang di session berikutnya.`;
                }

                await bot.editMessageText(successMessage, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '➕ Tambah Domain', callback_data: 'pointing_add' }],
                            [{ text: '🌐 List Domains', callback_data: 'pointing_list' }],
                            [{ text: '✏️ Edit Domain', callback_data: 'pointing_edit' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            } else {
                throw new Error(testResult.error);
            }

        } catch (error) {
            console.error('❌ Cloudflare Connection Error:', error);
            
            let errorMessage = `❌ <b>Gagal terhubung ke Cloudflare:</b>\n\n${error.message}`;
            
            await bot.editMessageText(errorMessage, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'pointing_setup' }],
                        [{ text: '❌ Batalkan', callback_data: 'pointing_domain' }]
                    ]
                }
            });
            
            pointingState.delete(chatId);
        }
    }

    // ===============================
    // FUNGSI LAINNYA YANG DIPERLUKAN
    // ===============================

    async askForDomainName(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'domain_name';

            const msg = await bot.sendMessage(chatId, '🌐 <b>Tambah Domain Baru</b>\n\nMasukkan nama domain/subdomain:\n\n<code>contoh.domain.com</code> atau <code>sub.domain.com</code>', {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const domainName = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!this.isValidDomain(domainName)) {
                        await bot.sendMessage(chatId, '❌ Format domain tidak valid.\n\nContoh yang benar:\n• <code>example.com</code>\n• <code>sub.example.com</code>', {
                            parse_mode: 'HTML'
                        });
                        return;
                    }

                    state.addData.domainName = domainName;
                    pointingState.set(chatId, state);
                    
                    await this.askForIPAddress(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask Domain Name Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses nama domain');
        }
    }

    async askForIPAddress(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'ip_address';

            const msg = await bot.sendMessage(chatId, 'Masukkan IP Address tujuan:', {
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const ipAddress = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!this.isValidIP(ipAddress)) {
                        await bot.sendMessage(chatId, '❌ Format IP Address tidak valid.\n\nContoh: <code>192.168.1.1</code>', {
                            parse_mode: 'HTML'
                        });
                        return;
                    }

                    state.addData.ipAddress = ipAddress;
                    pointingState.set(chatId, state);
                    
                    await this.askForRecordType(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask IP Address Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses IP address');
        }
    }

    async askForRecordType(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'record_type';

            await bot.sendMessage(chatId, 'Pilih tipe DNS Record:', {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🅰️ A Record', callback_data: 'pointing_type_A' },
                            { text: '©️ CNAME Record', callback_data: 'pointing_type_CNAME' }
                        ],
                        [
                            { text: '❌ Batal', callback_data: 'pointing_domain' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('❌ Ask Record Type Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses tipe record');
        }
    }

    async handleRecordTypeSelection(chatId, recordType, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan mulai ulang.');
                return;
            }

            state.addData.recordType = recordType;
            pointingState.set(chatId, state);

            await this.askForProxiedStatus(chatId, bot);
        } catch (error) {
            console.error('❌ Record Type Selection Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses pilihan record type');
        }
    }

    async askForProxiedStatus(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'proxied_status';

            await bot.sendMessage(chatId, '🛡️ Aktifkan Cloudflare Proxy?\n\n• <b>Proxied:</b> Traffic melalui CDN Cloudflare\n• <b>DNS Only:</b> Langsung ke server', {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '✅ Ya (Proxied)', callback_data: 'pointing_proxied_true' },
                            { text: '❌ Tidak (DNS Only)', callback_data: 'pointing_proxied_false' }
                        ],
                        [
                            { text: '❌ Batal', callback_data: 'pointing_domain' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('❌ Ask Proxied Status Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses status proxy');
        }
    }

    async handleProxiedSelection(chatId, proxiedStatus, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan mulai ulang.');
                return;
            }

            state.addData.proxied = proxiedStatus === 'true';
            pointingState.set(chatId, state);

            await this.confirmAddDomain(chatId, bot);
        } catch (error) {
            console.error('❌ Proxied Selection Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses pilihan proxy');
        }
    }

    async confirmAddDomain(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            const { domainName, ipAddress, recordType, proxied } = state.addData;

            const confirmText = `
✅ <b>KONFIRMASI TAMBAH DOMAIN</b>

🌐 <b>Domain:</b> <code>${domainName}</code>
📡 <b>Type:</b> ${recordType}
🔗 <b>Target:</b> <code>${ipAddress}</code>
🛡️ <b>Cloudflare Proxy:</b> ${proxied ? '✅ AKTIF' : '❌ NON-AKTIF'}

Apakah data sudah benar?
        `;

            await bot.sendMessage(chatId, confirmText, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '✅ Ya, Tambahkan', callback_data: 'pointing_confirm_add' },
                            { text: '❌ Batal', callback_data: 'pointing_domain' }
                        ]
                    ]
                }
            });
        } catch (error) {
            console.error('❌ Confirm Add Domain Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal menampilkan konfirmasi');
        }
    }

    async handleConfirmAddDomain(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            if (!state) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan mulai ulang.');
                return;
            }

            const { domainName, ipAddress, recordType, proxied } = state.addData;
            const loadingMsg = await bot.sendMessage(chatId, '⏳ Menambahkan domain ke Cloudflare...');

            try {
                const recordData = {
                    type: recordType,
                    name: domainName,
                    content: ipAddress,
                    ttl: 1,
                    proxied: proxied
                };

                const result = await state.cfApi.createDNSRecord(recordData);

                if (result.success) {
                    delete state.addData;
                    state.step = 'ready';
                    pointingState.set(chatId, state);

                    await bot.editMessageText(`✅ <b>Domain Berhasil Ditambahkan!</b>\n\n🌐 <b>Domain:</b> <code>${domainName}</code>\n📡 <b>Type:</b> ${recordType}\n🔗 <b>Target:</b> <code>${ipAddress}</code>\n🛡️ <b>Proxy:</b> ${proxied ? 'AKTIF' : 'NON-AKTIF'}\n🔑 <b>Record ID:</b> <code>${result.result.id}</code>`, {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🌐 Lihat Domains', callback_data: 'pointing_list' }],
                                [{ text: '➕ Tambah Lagi', callback_data: 'pointing_add' }],
                                [{ text: '✏️ Edit Domain', callback_data: 'pointing_edit' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });

                } else {
                    throw new Error(result.errors[0]?.message || 'Gagal menambahkan domain');
                }

            } catch (error) {
                console.error('❌ Add Domain to Cloudflare Error:', error);
                await bot.editMessageText(`❌ Gagal menambahkan domain:\n${error.message}`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'pointing_add' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ Confirm Add Domain Process Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses konfirmasi tambah domain');
        }
    }

    async askForWildcardIP(chatId, bot) {
        try {
            const state = pointingState.get(chatId);
            state.step = 'wildcard_ip';

            const msg = await bot.sendMessage(chatId, '🌐 <b>Setup Wildcard Domain</b>\n\nMasukkan IP Address tujuan untuk semua subdomain:', {
                parse_mode: 'HTML',
                reply_markup: { force_reply: true }
            });

            const replyListener = async (replyMsg) => {
                if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                    const ipAddress = replyMsg.text.trim();
                    
                    bot.removeListener('message', replyListener);
                    
                    if (!this.isValidIP(ipAddress)) {
                        await bot.sendMessage(chatId, '❌ Format IP Address tidak valid.\n\nContoh: <code>192.168.1.1</code>', {
                            parse_mode: 'HTML'
                        });
                        return;
                    }

                    state.wildcardData.ipAddress = ipAddress;
                    pointingState.set(chatId, state);
                    
                    await this.createWildcardSetup(chatId, bot);
                }
            };

            bot.on('message', replyListener);
            
            setTimeout(() => {
                bot.removeListener('message', replyListener);
            }, 120000);
        } catch (error) {
            console.error('❌ Ask Wildcard IP Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memproses IP wildcard');
        }
    }

    async createWildcardSetup(chatId, bot) {
        const state = pointingState.get(chatId);
        const { ipAddress } = state.wildcardData;
        const { zoneName, cfApi } = state;

        const loadingMsg = await bot.sendMessage(chatId, '🚀 Membuat setup wildcard domain...');

        try {
            // Step 1: Cek apakah wildcard record sudah ada
            const existingRecords = await cfApi.listDNSRecords();
            const existingWildcard = existingRecords.find(record => 
                record.name === `*.${zoneName}` && record.type === 'A'
            );

            if (existingWildcard) {
                // Update existing record
                const updateResult = await cfApi.updateDNSRecord(existingWildcard.id, {
                    type: 'A',
                    name: `*.${zoneName}`,
                    content: ipAddress,
                    ttl: 1,
                    proxied: false
                });

                if (!updateResult.success) {
                    throw new Error(`Gagal update wildcard DNS: ${updateResult.errors[0]?.message}`);
                }
            } else {
                // Buat wildcard DNS record baru
                const wildcardRecord = {
                    type: 'A',
                    name: `*.${zoneName}`,
                    content: ipAddress,
                    ttl: 1,
                    proxied: false // DNS only untuk wildcard
                };

                const dnsResult = await cfApi.createDNSRecord(wildcardRecord);
                
                if (!dnsResult.success) {
                    throw new Error(`Gagal membuat wildcard DNS: ${dnsResult.errors[0]?.message}`);
                }
            }

            await bot.editMessageText(`✅ <b>Wildcard Setup Berhasil!</b>\n\n🌐 <b>Domain:</b> ${zoneName}\n🎯 <b>Wildcard:</b> *.${zoneName}\n🔗 <b>Target IP:</b> ${ipAddress}\n⚡ <b>DNS Record:</b> Aktif\n\nSekarang semua subdomain akan otomatis mengarah ke IP ${ipAddress}`, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🌐 Test Subdomain', url: `https://test.${zoneName}` }],
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });

        } catch (error) {
            console.error('❌ Wildcard Setup Error:', error);
            
            let errorMessage = `❌ Gagal setup wildcard:\n\n${error.message}`;
            
            if (error.message.includes('Authentication') || error.message.includes('auth')) {
                errorMessage += '\n\n🔐 <b>Masalah Autentikasi Cloudflare:</b>\n';
                errorMessage += '• Pastikan API Key masih valid\n';
                errorMessage += '• Coba setup ulang Cloudflare credentials\n';
                errorMessage += '• Pastikan menggunakan Global API Key\n';
            }
            
            await bot.editMessageText(errorMessage, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'pointing_wildcard_setup' }],
                        [{ text: '⚙️ Setup Ulang CF', callback_data: 'pointing_setup' }],
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });
        }
    }

    // Fungsi untuk menampilkan halaman delete domain
    async showDeleteDomainPage(chatId, bot, messageId, records, currentPage, pageSize, totalPages) {
        const startIndex = currentPage * pageSize;
        const endIndex = Math.min(startIndex + pageSize, records.length);
        const pageRecords = records.slice(startIndex, endIndex);

        // Buat keyboard dengan pagination
        const keyboard = [];

        // Tambahkan records untuk halaman ini
        pageRecords.forEach(record => {
            // Persingkat teks tombol jika terlalu panjang
            const displayName = record.name.length > 25 ? record.name.substring(0, 22) + '...' : record.name;
            keyboard.push([
                { 
                    text: `🗑️ ${displayName} (${record.type})`, 
                    callback_data: `pointing_delete_${record.id}` 
                }
            ]);
        });

        // Tambahkan navigasi halaman
        const navButtons = [];
        if (currentPage > 0) {
            navButtons.push({ 
                text: '⬅️ Sebelumnya', 
                callback_data: `pointing_delete_page_${currentPage - 1}` 
            });
        }
        if (currentPage < totalPages - 1) {
            navButtons.push({ 
                text: 'Selanjutnya ➡️', 
                callback_data: `pointing_delete_page_${currentPage + 1}` 
            });
        }
        
        if (navButtons.length > 0) {
            keyboard.push(navButtons);
        }

        // Tombol aksi
        keyboard.push([{ text: '🔄 Refresh', callback_data: 'pointing_delete' }]);
        keyboard.push([{ text: '❌ Batal', callback_data: 'pointing_domain' }]);

        const messageText = `🗑️ <b>Hapus Domain</b>\n\nHalaman ${currentPage + 1}/${totalPages}\nPilih domain yang ingin dihapus:`;

        await bot.editMessageText(messageText, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    }

    // Handler untuk pagination delete domain
    async handleDeleteDomainPage(chatId, bot, page) {
        try {
            const state = pointingState.get(chatId);
            
            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan setup ulang Cloudflare.');
                return;
            }

            const records = await state.cfApi.listDNSRecords();
            const pageSize = 8;
            const totalPages = Math.ceil(records.length / pageSize);
            
            const loadingMsg = await bot.sendMessage(chatId, '🔄 Memuat halaman...');
            
            await this.showDeleteDomainPage(chatId, bot, loadingMsg.message_id, records, page, pageSize, totalPages);

        } catch (error) {
            console.error('❌ Delete Domain Page Error:', error);
            await bot.sendMessage(chatId, '❌ Gagal memuat halaman domain');
        }
    }

    // Handler untuk konfirmasi delete domain
    async handleConfirmDeleteDomain(chatId, recordId, bot) {
        try {
            const state = pointingState.get(chatId);
            
            if (!state || !state.cfApi) {
                await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan setup ulang Cloudflare.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '⏳ Menghapus domain...');

            try {
                const result = await state.cfApi.deleteDNSRecord(recordId);

                if (result.success) {
                    await bot.editMessageText('✅ Domain berhasil dihapus dari Cloudflare!', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🌐 Lihat Domains', callback_data: 'pointing_list' }],
                                [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                            ]
                        }
                    });
                } else {
                    throw new Error(result.errors[0]?.message || 'Gagal menghapus domain');
                }

            } catch (apiError) {
                console.error('❌ Delete Domain API Error:', apiError);
                await bot.editMessageText(`❌ Gagal menghapus domain:\n\n<code>${apiError.message}</code>`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'pointing_delete' }],
                            [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                        ]
                    }
                });
            }

        } catch (error) {
            console.error('❌ Delete Domain Error:', error);
            await bot.sendMessage(chatId, `❌ Terjadi error tidak terduga:\n\n<code>${error.message}</code>`, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                    ]
                }
            });
        }
    }

    // ===============================
    // FUNGSI BANTUAN
    // ===============================

    // Fungsi untuk mendapatkan state
    getState(chatId) {
        return pointingState.get(chatId);
    }

    // Generate worker script untuk routing
    generateWorkerScript(domain, ipAddress) {
        return `
addEventListener('fetch', event => {
    event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
    const url = new URL(request.url)
    const subdomain = url.hostname.split('.')[0]
    
    // Redirect ke target IP dengan mempertahankan path
    const targetUrl = new URL(url.pathname + url.search, 'http://${ipAddress}')
    
    // Clone request headers
    const headers = new Headers(request.headers)
    
    // Forward request ke target server
    const response = await fetch(targetUrl.toString(), {
        method: request.method,
        headers: headers,
        body: request.body
    })
    
    return response
}
        `.trim();
    }

    // Fungsi test authentication
    async testCloudflareAuth(email, apiKey, zoneId) {
        return new Promise((resolve) => {
            const options = {
                hostname: 'api.cloudflare.com',
                port: 443,
                path: `/client/v4/zones/${zoneId}`,
                method: 'GET',
                headers: {
                    'X-Auth-Email': email,
                    'X-Auth-Key': apiKey,
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0'
                },
                timeout: 15000
            };

            console.log('🔧 Testing Cloudflare zone access...');

            const req = https.request(options, (res) => {
                let data = '';

                res.on('data', (chunk) => {
                    data += chunk;
                });

                res.on('end', () => {
                    console.log('📨 Zone Response status:', res.statusCode);
                    
                    try {
                        const result = JSON.parse(data);
                        
                        if (res.statusCode === 200 && result.success) {
                            resolve({ 
                                success: true, 
                                zoneName: result.result.name 
                            });
                        } else {
                            const errorMsg = result.errors ? 
                                result.errors[0].message : 
                                `Zone access denied: HTTP ${res.statusCode}`;
                            resolve({ success: false, error: errorMsg });
                        }
                    } catch (e) {
                        resolve({ success: false, error: 'Invalid zone response from Cloudflare' });
                    }
                });
            });

            req.on('error', (error) => {
                resolve({ success: false, error: `Zone request error: ${error.message}` });
            });

            req.on('timeout', () => {
                req.destroy();
                resolve({ success: false, error: 'Zone request timeout' });
            });

            req.end();
        });
    }

    // Validasi domain
    isValidDomain(domain) {
        const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
        return domainRegex.test(domain) && domain.length <= 253;
    }

    // Validasi IP address
    isValidIP(ip) {
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (!ipRegex.test(ip)) return false;
        
        const parts = ip.split('.');
        return parts.every(part => {
            const num = parseInt(part, 10);
            return num >= 0 && num <= 255;
        });
    }
}

// Cloudflare API Class
class CloudflareAPI {
    constructor(email, apiKey, zoneId) {
        this.email = email;
        this.apiKey = apiKey;
        this.zoneId = zoneId;
        this.baseURL = 'https://api.cloudflare.com/client/v4';
    }

    // Request helper
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        
        const defaultOptions = {
            headers: {
                'X-Auth-Email': this.email,
                'X-Auth-Key': this.apiKey,
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 30000
        };

        const finalOptions = { ...defaultOptions, ...options };

        return new Promise((resolve, reject) => {
            const urlObj = new URL(url);
            
            const reqOptions = {
                hostname: urlObj.hostname,
                path: urlObj.pathname + urlObj.search,
                method: finalOptions.method || 'GET',
                headers: finalOptions.headers,
                timeout: finalOptions.timeout
            };

            console.log(`🔧 Cloudflare API Request: ${reqOptions.method} ${endpoint}`);

            const req = https.request(reqOptions, (res) => {
                let data = '';

                res.on('data', (chunk) => {
                    data += chunk;
                });

                res.on('end', () => {
                    console.log(`📨 Cloudflare API Response: ${res.statusCode} ${endpoint}`);
                    
                    try {
                        const result = JSON.parse(data);
                        
                        if (res.statusCode >= 200 && res.statusCode < 300) {
                            resolve(result);
                        } else {
                            const errorMsg = result.errors ? 
                                result.errors.map(err => err.message).join(', ') : 
                                `HTTP ${res.statusCode}`;
                            reject(new Error(errorMsg));
                        }
                    } catch (e) {
                        reject(new Error(`Invalid JSON response: ${data.substring(0, 200)}`));
                    }
                });
            });

            req.on('error', (error) => {
                console.error('❌ Cloudflare API Request Error:', error.message);
                reject(error);
            });

            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            if (finalOptions.body) {
                req.write(finalOptions.body);
            }

            req.end();
        });
    }

    // List DNS records
    async listDNSRecords() {
        try {
            const result = await this.request(`/zones/${this.zoneId}/dns_records`);
            return result.result || [];
        } catch (error) {
            console.error('❌ List DNS Records Error:', error);
            throw error;
        }
    }

    // Create DNS record
    async createDNSRecord(recordData) {
        try {
            const result = await this.request(`/zones/${this.zoneId}/dns_records`, {
                method: 'POST',
                body: JSON.stringify(recordData)
            });
            return result;
        } catch (error) {
            console.error('❌ Create DNS Record Error:', error);
            throw error;
        }
    }

    // Update DNS record
    async updateDNSRecord(recordId, recordData) {
        try {
            const result = await this.request(`/zones/${this.zoneId}/dns_records/${recordId}`, {
                method: 'PUT',
                body: JSON.stringify(recordData)
            });
            return result;
        } catch (error) {
            console.error('❌ Update DNS Record Error:', error);
            throw error;
        }
    }

    // Delete DNS record
    async deleteDNSRecord(recordId) {
        try {
            console.log(`🗑️ Deleting DNS record: ${recordId}`);
            
            const result = await this.request(`/zones/${this.zoneId}/dns_records/${recordId}`, {
                method: 'DELETE'
            });
            
            console.log(`✅ Delete DNS record success: ${recordId}`);
            return result;
            
        } catch (error) {
            console.error(`❌ Delete DNS Record Error for ${recordId}:`, error);
            throw error;
        }
    }
}

module.exports = PointingDomain;