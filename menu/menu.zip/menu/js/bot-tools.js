require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const PointingDomain = require('./pointing_domain');
const pointingDomain = new PointingDomain();
const axios = require('axios');

// Import convert xray module
const { 
    showConvertXrayMenu, 
    handleXrayCallback, 
    handleXrayConfig, 
    userStates 
} = require('./convert-xray');

// ===============================
// BASH ENCRYPT MANAGER (FITUR BARU)
// ===============================

class BashEncryptManager {
    constructor() {
        this.tempDir = './temp-bash';
        this.ensureTempDir();
    }

    ensureTempDir() {
        if (!fs.existsSync(this.tempDir)) {
            fs.mkdirSync(this.tempDir, { recursive: true });
        }
    }

    // Cleanup temp files - DIPERBAIKI: Jangan hapus file hasil
    cleanupTempFiles() {
        try {
            if (fs.existsSync(this.tempDir)) {
                const files = fs.readdirSync(this.tempDir);
                files.forEach(file => {
                    // Hanya hapus file temporary, jangan hapus file hasil enkripsi/dekripsi
                    if (file.startsWith('input_') || file.startsWith('temp_')) {
                        fs.unlinkSync(path.join(this.tempDir, file));
                        console.log(`🧹 Cleanup temp file: ${file}`);
                    }
                });
            }
        } catch (error) {
            console.error('Bash encrypt cleanup error:', error);
        }
    }

    // Cleanup file hasil setelah download - FUNGSI BARU
    cleanupResultFiles() {
        try {
            if (fs.existsSync(this.tempDir)) {
                const files = fs.readdirSync(this.tempDir);
                files.forEach(file => {
                    // Hapus file hasil enkripsi/dekripsi
                    if (file.startsWith('encrypted_') || file.startsWith('decrypted_')) {
                        fs.unlinkSync(path.join(this.tempDir, file));
                        console.log(`🧹 Cleanup result file: ${file}`);
                    }
                });
            }
        } catch (error) {
            console.error('Bash encrypt result cleanup error:', error);
        }
    }

    // Encrypt bash script menggunakan bash-obfuscate
    async encryptScript(inputPath, outputFileName) {
        return new Promise((resolve, reject) => {
            const outputPath = path.join(this.tempDir, outputFileName);
            
            console.log(`🔒 Encrypting: ${inputPath} -> ${outputPath}`);
            
            exec(`bash-obfuscate ${inputPath} -o ${outputPath}`, (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Gagal mengenkripsi script: ${error.message}`));
                    return;
                }
                
                if (stderr && !stderr.includes('Warning')) {
                    reject(new Error(`Error bash-obfuscate: ${stderr}`));
                    return;
                }
                
                resolve({
                    success: true,
                    outputPath: outputPath,
                    fileName: outputFileName
                });
            });
        });
    }

    // Decrypt bash script (replace eval dengan echo) - DIPERBAIKI
    async decryptScript(inputPath, outputFileName) {
        return new Promise((resolve, reject) => {
            try {
                console.log(`🔓 Decrypting: ${inputPath}`);
                
                // Baca file terenkripsi
                const encryptedContent = fs.readFileSync(inputPath, 'utf8');
                
                // Validasi: Pastikan file mengandung eval (tanda file terenkripsi)
                if (!encryptedContent.includes('eval')) {
                    console.log('⚠️ File tidak mengandung eval, mungkin bukan file terenkripsi');
                    // Tetap lanjutkan proses, mungkin file biasa
                }
                
                // Ganti eval dengan echo (dekripsi sederhana)
                const decryptedContent = encryptedContent.replace(/eval/g, 'echo');
                
                const tempScriptPath = path.join(this.tempDir, 'temp_decrypt.sh');
                const outputPath = path.join(this.tempDir, outputFileName);
                
                // Tulis script sementara
                fs.writeFileSync(tempScriptPath, decryptedContent);
                
                // Jalankan script dan capture output
                exec(`bash ${tempScriptPath} > ${outputPath} 2>&1`, (error, stdout, stderr) => {
                    // Cleanup temp script saja
                    try {
                        if (fs.existsSync(tempScriptPath)) {
                            fs.unlinkSync(tempScriptPath);
                        }
                    } catch (e) {}
                    
                    if (error) {
                        console.error('❌ Decrypt execution error:', error);
                        // Coba metode alternatif: simpan langsung tanpa execute
                        try {
                            fs.writeFileSync(outputPath, decryptedContent);
                            console.log('✅ Fallback: File disimpan tanpa execute');
                            resolve({
                                success: true,
                                outputPath: outputPath,
                                fileName: outputFileName
                            });
                        } catch (fallbackError) {
                            reject(new Error(`Gagal mendekripsi script: ${error.message}`));
                        }
                        return;
                    }
                    
                    // Cek apakah output file berhasil dibuat
                    if (fs.existsSync(outputPath)) {
                        const outputSize = fs.statSync(outputPath).size;
                        if (outputSize > 0) {
                            resolve({
                                success: true,
                                outputPath: outputPath,
                                fileName: outputFileName
                            });
                        } else {
                            // Jika output kosong, simpan content asli
                            fs.writeFileSync(outputPath, decryptedContent);
                            resolve({
                                success: true,
                                outputPath: outputPath,
                                fileName: outputFileName
                            });
                        }
                    } else {
                        reject(new Error('Output file tidak berhasil dibuat'));
                    }
                });
                
            } catch (error) {
                reject(new Error(`Gagal memproses file: ${error.message}`));
            }
        });
    }

    // Check if bash-obfuscate is installed
    async checkBashObfuscate() {
        return new Promise((resolve) => {
            exec('which bash-obfuscate', (error) => {
                resolve(!error);
            });
        });
    }

    // Install bash-obfuscate
    async installBashObfuscate() {
        return new Promise((resolve, reject) => {
            console.log('📦 Installing bash-obfuscate...');
            exec('npm install -g bash-obfuscate', (error, stdout, stderr) => {
                if (error) {
                    reject(new Error(`Gagal install bash-obfuscate: ${error.message}`));
                    return;
                }
                console.log('✅ bash-obfuscate installed successfully');
                resolve(true);
            });
        });
    }
}

// Inisialisasi Bash Encrypt Manager
const bashEncrypt = new BashEncryptManager();

// ===============================
// KONFIGURASI AWAL (TIDAK BERUBAH)
// ===============================

// Konfigurasi dari .env
const TOKEN = process.env.BOT_TOKEN;
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const ALLOWED_USERS = process.env.ALLOWED_USERS ? process.env.ALLOWED_USERS.split(',').map(id => id.trim()) : [ADMIN_CHAT_ID];

const GITHUB_USER = process.env.GITHUB_USER;
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const GITHUB_REPO = process.env.GITHUB_REPO;
const GITHUB_EMAIL = process.env.GITHUB_EMAIL;

const UBUNTU_INSTALL_SCRIPT = process.env.UBUNTU_INSTALL_SCRIPT;
const DEBIAN_INSTALL_SCRIPT = process.env.DEBIAN_INSTALL_SCRIPT;

// TAMBAHAN: Konfigurasi Grup dan Channel Required
const REQUIRED_GROUP = process.env.REQUIRED_GROUP || '@pxstoree';
const REQUIRED_CHANNEL = process.env.REQUIRED_CHANNEL || '@pxstorech'; 

// Validasi config
if (!TOKEN || !ADMIN_CHAT_ID || !GITHUB_TOKEN) {
    console.error('❌ ERROR: Missing required environment variables');
    console.log('Please check your .env file');
    process.exit(1);
}

// Path files
const DATA_DIR = '/root/vps-data';
const IPX_FILE = path.join(DATA_DIR, 'ipx');
const IP_FILE = path.join(DATA_DIR, 'ip');
const GIT_DIR = path.join(DATA_DIR, 'repo');
const USERS_FILE = path.join(DATA_DIR, 'allowed_users.json');
const ENV_FILE = path.join(process.cwd(), '.env');

// Inisialisasi bot
const bot = new TelegramBot(TOKEN, { polling: true });

console.log('🤖 Bot VPS Manager sedang berjalan...');
console.log('📊 Admin Chat ID:', ADMIN_CHAT_ID);
console.log('🔗 GitHub User:', GITHUB_USER);
console.log('👥 Allowed Users:', ALLOWED_USERS);
console.log('📢 Required Group:', REQUIRED_GROUP);
console.log('📢 Required Channel:', REQUIRED_CHANNEL);

// Inisialisasi directory dan files
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// ===============================
// FUNGSI VALIDASI KEANGGOTAAN GRUP/CHANNEL (FITUR BARU)
// ===============================

// Fungsi untuk cek apakah user sudah join grup/channel
async function checkMembership(chatId, userId) {
    try {
        let allJoined = true;
        const results = {
            group: false,
            channel: false
        };

        // Cek keanggotaan grup
        try {
            const groupMember = await bot.getChatMember(REQUIRED_GROUP, userId);
            results.group = ['member', 'administrator', 'creator'].includes(groupMember.status);
            if (!results.group) allJoined = false;
        } catch (error) {
            console.error('❌ Error checking group membership:', error);
            results.group = false;
            allJoined = false;
        }

        // Cek keanggotaan channel
        try {
            const channelMember = await bot.getChatMember(REQUIRED_CHANNEL, userId);
            results.channel = ['member', 'administrator', 'creator'].includes(channelMember.status);
            if (!results.channel) allJoined = false;
        } catch (error) {
            console.error('❌ Error checking channel membership:', error);
            results.channel = false;
            allJoined = false;
        }

        return {
            success: allJoined,
            results: results
        };
    } catch (error) {
        console.error('❌ Membership check error:', error);
        return {
            success: false,
            results: { group: false, channel: false }
        };
    }
}

// Fungsi untuk menampilkan pesan verifikasi keanggotaan
function showMembershipVerification(chatId, user, membershipResults, messageId = null) {
    // Hapus pesan sebelumnya jika ada
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const userName = formatUserName(user);
    
    const verificationText = `
🔐 <b>VERIFIKASI KEANGGOTAAN REQUIRED</b>

👋 Halo, <b>${userName}</b>!

Untuk menggunakan bot ini, Anda harus bergabung dengan grup dan channel terlebih dahulu:

${!membershipResults.group ? '❌' : '✅'} <b>Grup:</b> ${REQUIRED_GROUP}
${!membershipResults.channel ? '❌' : '✅'} <b>Channel:</b> ${REQUIRED_CHANNEL}

📋 <b>Langkah-langkah:</b>
1. Klik tombol di bawah untuk bergabung
2. Setelah join, klik tombol "✅ Saya Sudah Join"
3. Bot akan memverifikasi keanggotaan Anda

⚠️ <b>Pastikan Anda sudah bergabung dengan kedua link di atas!</b>
    `;

    const buttons = [
        [
            { text: '📢 Join Grup', url: `https://t.me/${REQUIRED_GROUP.replace('@', '')}` },
            { text: '📢 Join Channel', url: `https://t.me/${REQUIRED_CHANNEL.replace('@', '')}` }
        ],
        [
            { text: '✅ Saya Sudah Join', callback_data: 'verify_membership' }
        ]
    ];

    // Jika admin, tambahkan tombol bypass
    if (isAdmin(user.id.toString())) {
        buttons.push([
            { text: '👑 Admin Bypass', callback_data: 'admin_bypass_membership' }
        ]);
    }

    bot.sendMessage(chatId, verificationText, {
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// ===============================
// GITHUB CONFIG MANAGER (TIDAK BERUBAH)
// ===============================

class GitHubConfigManager {
    constructor() {
        this.config = {
            username: process.env.GITHUB_USER,
            token: process.env.GITHUB_TOKEN,
            repo: process.env.GITHUB_REPO,
            branch: 'main'
        };
        
        this.baseURL = `https://api.github.com/repos/${this.config.username}/${this.config.repo}`;
        this.headers = {
            'Authorization': `token ${this.config.token}`,
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Telegram-Bot'
        };
    }

    // Mendapatkan daftar file config dari repository
    // Dalam class GitHubConfigManager - modifikasi fungsi getConfigFiles
async getConfigFiles() {
    try {
        const response = await axios.get(
            `${this.baseURL}/contents`,
            { 
                headers: this.headers,
                timeout: 15000
            }
        );
        
        const configFiles = response.data.filter(file => {
            const name = file.name.toLowerCase();
            return name.includes('.hc') || 
                   name.includes('.hi') || 
                   name.includes('.json') || 
                   name.includes('.txt') ||
                   name.includes('.config') ||
                   name.includes('.yaml') ||
                   name.includes('.yml') ||
                   name.includes('.nm') ||      // TAMBAHAN BARU
                   name.includes('.ziv') ||     // TAMBAHAN BARU
                   name.includes('.dark');      // TAMBAHAN BARU
        });
        
        return configFiles;
    } catch (error) {
        console.error('❌ Error getting config files:', error.message);
        return [];
    }
}

    // Mendapatkan file berdasarkan kategori
    // Dalam class GitHubConfigManager - modifikasi fungsi getFilesByCategory
async getFilesByCategory() {
    try {
        const files = await this.getConfigFilesFromFolder('configs');
        const categories = {
            httpCustom: [],
            httpInjector: [],
            v2ray: [],
            trojan: [],
            nm: [],           // TAMBAHAN BARU: Untuk file .nm
            ziv: [],          // TAMBAHAN BARU: Untuk file .ziv  
            dark: [],         // TAMBAHAN BARU: Untuk file .dark
            other: []
        };

        files.forEach(file => {
            const name = file.name.toLowerCase();
            if (name.includes('.hc') || name.includes('httpcustom')) {
                categories.httpCustom.push(file);
            } else if (name.includes('.hi') || name.includes('httpinjector')) {
                categories.httpInjector.push(file);
            } else if (name.includes('v2ray') || name.includes('vmess') || name.includes('vless')) {
                categories.v2ray.push(file);
            } else if (name.includes('trojan')) {
                categories.trojan.push(file);
            } else if (name.includes('.nm')) {        // TAMBAHAN BARU
                categories.nm.push(file);
            } else if (name.includes('.ziv')) {       // TAMBAHAN BARU
                categories.ziv.push(file);
            } else if (name.includes('.dark')) {      // TAMBAHAN BARU
                categories.dark.push(file);
            } else {
                categories.other.push(file);
            }
        });

        return categories;
    } catch (error) {
        console.error('❌ Error in getFilesByCategory:', error);
        return {
            httpCustom: [],
            httpInjector: [],
            v2ray: [],
            trojan: [],
            nm: [],           // TAMBAHAN BARU
            ziv: [],          // TAMBAHAN BARU
            dark: [],         // TAMBAHAN BARU
            other: []
        };
    }
}

    // Upload config file ke folder tertentu
    async uploadConfigToFolder(fileName, content, folder = 'configs') {
        try {
            const filePath = `${folder}/${fileName}`;
            
            console.log(`📤 Uploading file to: ${filePath}`);
            
            // Cek apakah file sudah ada
            let sha = null;
            try {
                const existingFile = await axios.get(
                    `${this.baseURL}/contents/${encodeURIComponent(filePath)}`,
                    { 
                        headers: this.headers,
                        timeout: 15000
                    }
                );
                sha = existingFile.data.sha;
                console.log(`📁 File exists, will update: ${fileName}`);
            } catch (error) {
                // File belum ada, akan dibuat baru
                console.log(`📁 Creating new file: ${fileName}`);
            }

            const data = {
                message: `Upload config: ${fileName} ke folder ${folder}`,
                content: Buffer.from(content).toString('base64'),
                branch: this.config.branch
            };

            if (sha) {
                data.sha = sha;
            }

            const response = await axios.put(
                `${this.baseURL}/contents/${encodeURIComponent(filePath)}`,
                data,
                { 
                    headers: this.headers,
                    timeout: 30000
                }
            );

            console.log(`✅ File uploaded successfully: ${fileName}`);

            return {
                success: true,
                data: response.data,
                message: `File ${fileName} berhasil diupload ke folder ${folder} di GitHub`
            };
        } catch (error) {
            console.error('❌ Error uploading config to folder:', error.message);
            
            let errorMsg = error.message;
            if (error.response) {
                if (error.response.status === 404) {
                    errorMsg = `Folder "${folder}" tidak ditemukan di repository`;
                } else if (error.response.status === 403) {
                    errorMsg = 'Akses ditolak ke repository GitHub';
                } else if (error.response.status === 401) {
                    errorMsg = 'Token GitHub tidak valid';
                } else if (error.response.data && error.response.data.message) {
                    errorMsg = error.response.data.message;
                }
            }
            
            return {
                success: false,
                error: errorMsg,
                message: `Gagal mengupload ${fileName} ke folder ${folder}: ${errorMsg}`
            };
        }
    }

    // Mendapatkan file dari folder tertentu
    // Dalam class GitHubConfigManager - modifikasi fungsi getConfigFilesFromFolder
async getConfigFilesFromFolder(folder = 'configs') {
    try {
        const response = await axios.get(
            `${this.baseURL}/contents/${folder}`,
            { 
                headers: this.headers,
                timeout: 15000
            }
        );
        
        console.log(`📁 Files in ${folder}:`, response.data.map(f => f.name));
        
        const configFiles = response.data.filter(file => {
            // Filter hanya file, bukan folder
            if (file.type !== 'file') return false;
            
            const name = file.name.toLowerCase();
            return name.includes('.hc') || 
                   name.includes('.hi') || 
                   name.includes('.json') || 
                   name.includes('.txt') ||
                   name.includes('.config') ||
                   name.includes('.yaml') ||
                   name.includes('.yml') ||
                   name.includes('.nm') ||      // TAMBAHAN BARU
                   name.includes('.ziv') ||     // TAMBAHAN BARU
                   name.includes('.dark');      // TAMBAHAN BARU
        });
        
        console.log(`✅ Config files found in ${folder}:`, configFiles.map(f => f.name));
        return configFiles;
    } catch (error) {
        console.error(`❌ Error getting files from ${folder}:`, error.message);
        
        // Jika folder tidak ada, return array kosong
        if (error.response && error.response.status === 404) {
            console.log(`📁 Folder ${folder} doesn't exist yet`);
            return [];
        }
        return [];
    }
}

    // Delete file dari GitHub
    async deleteFile(filePath) {
        try {
            const encodedFilePath = encodeURIComponent(filePath);
            
            // Dapatkan SHA file yang akan dihapus
            const fileInfo = await axios.get(
                `${this.baseURL}/contents/${encodedFilePath}`,
                { 
                    headers: this.headers,
                    timeout: 15000
                }
            );
            
            const sha = fileInfo.data.sha;
            
            // Hapus file
            const response = await axios.delete(
                `${this.baseURL}/contents/${encodedFilePath}`,
                {
                    headers: this.headers,
                    data: {
                        message: `Delete file: ${filePath}`,
                        sha: sha,
                        branch: this.config.branch
                    },
                    timeout: 30000
                }
            );
            
            return {
                success: true,
                data: response.data,
                message: `File ${filePath} berhasil dihapus dari GitHub`
            };
        } catch (error) {
            console.error('❌ Error deleting file:', error.message);
            
            let errorMsg = error.message;
            if (error.response) {
                if (error.response.status === 404) {
                    errorMsg = `File "${filePath}" tidak ditemukan di repository`;
                } else if (error.response.status === 403) {
                    errorMsg = 'Akses ditolak ke repository GitHub';
                } else if (error.response.status === 401) {
                    errorMsg = 'Token GitHub tidak valid';
                }
            }
            
            return {
                success: false,
                error: errorMsg,
                message: `Gagal menghapus "${filePath}"`
            };
        }
    }

    // Download file content
    async downloadFile(filePath) {
        try {
            const encodedFilePath = encodeURIComponent(filePath);
            
            console.log(`📥 Downloading file: ${filePath}`);
            
            // Coba metode 1: Download via content API
            try {
                const response = await axios.get(
                    `${this.baseURL}/contents/${encodedFilePath}`,
                    { 
                        headers: this.headers,
                        timeout: 30000
                    }
                );
                
                let fileContent, fileName, fileSize, downloadUrl;
                
                if (response.data.content) {
                    // Decode base64 content dengan error handling
                    try {
                        fileContent = Buffer.from(response.data.content, 'base64').toString('utf8');
                        fileName = response.data.name;
                        fileSize = response.data.size;
                        downloadUrl = response.data.download_url;
                        
                        console.log(`✅ File downloaded via content API: ${fileName}, size: ${fileSize}`);
                        
                        return {
                            success: true,
                            content: fileContent,
                            name: fileName,
                            size: fileSize,
                            download_url: downloadUrl,
                            method: 'content_api'
                        };
                    } catch (decodeError) {
                        console.error('❌ Base64 decode error:', decodeError);
                        // Fallback ke metode download URL
                    }
                }
            } catch (contentError) {
                console.error('❌ Content API error:', contentError.message);
                // Lanjut ke metode download URL
            }
            
            // Metode 2: Download via download URL langsung
            try {
                // Dapatkan info file dulu
                const infoResponse = await axios.get(
                    `${this.baseURL}/contents/${encodedFilePath}`,
                    { 
                        headers: this.headers,
                        timeout: 15000
                    }
                );
                
                if (!infoResponse.data.download_url) {
                    throw new Error('Download URL tidak tersedia');
                }
                
                const downloadResponse = await axios.get(infoResponse.data.download_url, {
                    responseType: 'arraybuffer',
                    timeout: 30000,
                    headers: {
                        'User-Agent': 'Telegram-Bot',
                        'Accept': 'application/octet-stream'
                    }
                });
                
                console.log(`✅ File downloaded via direct URL: ${infoResponse.data.name}, size: ${downloadResponse.data.byteLength}`);
                
                return {
                    success: true,
                    content: downloadResponse.data,
                    name: infoResponse.data.name,
                    size: downloadResponse.data.byteLength,
                    download_url: infoResponse.data.download_url,
                    method: 'direct_url'
                };
                
            } catch (downloadError) {
                console.error('❌ Direct download error:', downloadError.message);
                throw new Error(`Gagal download via semua metode: ${downloadError.message}`);
            }
            
        } catch (error) {
            console.error('❌ Error downloading file:', error.message);
            
            let errorMsg = error.message;
            if (error.response) {
                if (error.response.status === 404) {
                    errorMsg = `File "${filePath}" tidak ditemukan di repository`;
                } else if (error.response.status === 403) {
                    errorMsg = 'Akses ditolak ke repository GitHub';
                } else if (error.response.status === 401) {
                    errorMsg = 'Token GitHub tidak valid';
                }
            }
            
            return {
                success: false,
                error: errorMsg,
                message: `Gagal mengunduh "${filePath}"`
            };
        }
    }
}

// Inisialisasi GitHub Config Manager
const githubConfig = new GitHubConfigManager();

// ===============================
// FUNGSI BASH ENCRYPT HANDLER (FITUR BARU)
// ===============================

// Handler untuk menu bash encrypt
async function handleBashEncryptMenu(chatId, user, messageId = null) {
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const menuText = `
<b>🔒 BASH SCRIPT ENCRYPT/DECRYPT</b>

Fitur untuk mengenkripsi dan mendekripsi script bash menggunakan teknik obfuscation.

📁 <b>Fitur Tersedia:</b>
• 🔒 Enkripsi Script - Enkripsi script bash menggunakan bash-obfuscate
• 🔓 Dekripsi Script - Dekripsi script terenkripsi
• 📁 Upload File - Upload script bash untuk diproses

⚡ <b>Format yang didukung:</b>
• File bash script (.sh)
• File terenkripsi (.encrypted)

<b>Pilih aksi yang ingin dilakukan:</b>
    `;

    const buttons = [
        [
            { text: '🔒 Enkripsi Script', callback_data: 'bash_encrypt' },
            { text: '🔓 Dekripsi Script', callback_data: 'bash_decrypt' }
        ],
        [
            { text: '📁 Upload Script', callback_data: 'bash_upload' },
            { text: '⚙️ Cek Dependencies', callback_data: 'bash_check_deps' }
        ],
        [
            { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
        ]
    ];

    // Gunakan GIF seperti menu lainnya
    const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5alfF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

    bot.sendAnimation(chatId, gifUrl, {
        caption: menuText,
        parse_mode: 'HTML',
        reply_markup: { inline_keyboard: buttons }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendAnimation handleBashEncryptMenu error:', err);
        // Fallback ke text message jika GIF gagal
        bot.sendMessage(chatId, menuText, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: buttons }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    });
}

// Handler untuk encrypt script - DIPERBAIKI: File hasil tidak dihapus
async function handleBashEncrypt(chatId) {
    const msg = await bot.sendMessage(chatId, 
        '<b>🔒 Enkripsi Bash Script</b>\n\n' +
        'Silakan upload file bash script (.sh) yang ingin dienkripsi:\n\n' +
        '<i>File akan diproses menggunakan bash-obfuscate</i>\n' +
        '<i>⚠️ Jika file tidak berekstensi .sh, akan otomatis ditambahkan</i>',
        {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '❌ Batal', callback_data: 'bash_encrypt_menu' }]
                ]
            }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    // Buat listener function yang bisa direferensikan
    const fileListener = async (fileMsg) => {
        if (fileMsg.chat.id !== chatId) return;
        
        if (fileMsg.document) {
            // HAPUS LISTENER DI AWAL PROSES
            bot.removeListener('message', fileListener);
            clearTimeout(timeoutId);
            
            try {
                const loadingMsg = await bot.sendMessage(chatId, '🔒 Mengenkripsi script...');
                saveActionMessage(chatId, loadingMsg.message_id);
                
                const fileId = fileMsg.document.file_id;
                let fileName = fileMsg.document.file_name;
                
                if (!fileName.endsWith('.sh')) {
                    console.log(`⚠️ File ${fileName} tidak berekstensi .sh, menambahkan otomatis`);
                    const baseName = fileName.split('.').slice(0, -1).join('.') || fileName;
                    fileName = `${baseName}.sh`;
                    
                    await bot.editMessageText(
                        `⚠️ <b>File diperbaiki otomatis</b>\n\n` +
                        `Nama file asli tidak berekstensi .sh\n` +
                        `Diubah menjadi: <code>${fileName}</code>\n\n` +
                        `🔒 Melanjutkan enkripsi...`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML'
                        }
                    );
                }
                
                // Download file
                const fileStream = bot.getFileStream(fileId);
                const chunks = [];
                
                for await (const chunk of fileStream) {
                    chunks.push(chunk);
                }
                
                const fileBuffer = Buffer.concat(chunks);
                const tempInputPath = path.join(bashEncrypt.tempDir, `input_${Date.now()}.sh`);
                fs.writeFileSync(tempInputPath, fileBuffer);
                
                // Encrypt script
                const outputFileName = `encrypted_${fileName}`;
                const result = await bashEncrypt.encryptScript(tempInputPath, outputFileName);
                
                if (result.success) {
                    // Kirim file hasil enkripsi
                    await bot.sendDocument(
                        chatId,
                        result.outputPath,
                        {
                            caption: `✅ <b>Script Berhasil Dienkripsi!</b>\n\n` +
                                    `📁 <b>File:</b> ${outputFileName}\n` +
                                    `💾 <b>Size:</b> ${(fs.statSync(result.outputPath).size / 1024).toFixed(2)} KB\n` +
                                    `🔒 <b>Status:</b> Terenkripsi dengan bash-obfuscate\n\n` +
                                    `<i>File telah berhasil dienkripsi dan siap digunakan.</i>\n` +
                                    `<b>Developer Script: @PeyxDev</b>`,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '🔒 Enkripsi Lagi', callback_data: 'bash_encrypt' },
                                        { text: '🔓 Dekripsi', callback_data: 'bash_decrypt' }
                                    ],
                                    [
                                        { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                                    ]
                                ]
                            }
                        },
                        {
                            filename: outputFileName
                        }
                    );
                    
                    await bot.deleteMessage(chatId, loadingMsg.message_id);
                    
                    // PERBAIKAN: Hanya cleanup file temporary, bukan file hasil
                    setTimeout(() => {
                        bashEncrypt.cleanupTempFiles(); // Hanya hapus file temp
                    }, 30000);
                    
                } else {
                    throw new Error('Gagal mengenkripsi script');
                }
                
                // Hapus input file temporary saja
                try {
                    if (fs.existsSync(tempInputPath)) {
                        fs.unlinkSync(tempInputPath);
                    }
                } catch (e) {}
                
            } catch (error) {
                console.error('❌ Bash Encrypt Error:', error);
                await bot.sendMessage(chatId, 
                    `❌ Gagal mengenkripsi script:\n<code>${error.message}</code>`,
                    {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🔄 Coba Lagi', callback_data: 'bash_encrypt' }],
                                [{ text: '🔙 Kembali ke Menu', callback_data: 'bash_encrypt_menu' }]
                            ]
                        }
                    }
                ).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };
    
    // Tambahkan listener
    bot.on('message', fileListener);
    
    // Timeout
    const timeoutId = setTimeout(() => {
        bot.removeListener('message', fileListener);
        console.log(`⏰ Timeout: Listener dihapus untuk chat ${chatId}`);
        
        bot.sendMessage(chatId, 
            '⏰ <b>Waktu upload telah habis</b>\n\n' +
            'Silakan pilih aksi yang ingin dilakukan:',
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔒 Enkripsi Script', callback_data: 'bash_encrypt' },
                            { text: '🔓 Dekripsi Script', callback_data: 'bash_decrypt' }
                        ],
                        [
                            { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                        ]
                    ]
                }
            }
        ).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }, 120000);
}

// Handler untuk decrypt script - DIPERBAIKI: File hasil tidak dihapus
async function handleBashDecrypt(chatId) {
    const msg = await bot.sendMessage(chatId, 
        '<b>🔓 Dekripsi Bash Script</b>\n\n' +
        'Silakan upload file bash script terenkripsi yang ingin didekripsi:\n\n' +
        '<i>File akan diproses dengan teknik dekripsi eval-to-echo</i>\n' +
        '<i>📁 Format yang didukung: .sh, .encrypted, atau tanpa ekstensi</i>',
        {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '❌ Batal', callback_data: 'bash_encrypt_menu' }]
                ]
            }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    const fileListener = async (fileMsg) => {
        if (fileMsg.chat.id !== chatId) return;
        
        if (fileMsg.document) {
            // HAPUS LISTENER DI AWAL PROSES
            bot.removeListener('message', fileListener);
            clearTimeout(timeoutId);
            
            try {
                const loadingMsg = await bot.sendMessage(chatId, '🔓 Mendekripsi script...');
                saveActionMessage(chatId, loadingMsg.message_id);
                
                const fileId = fileMsg.document.file_id;
                let fileName = fileMsg.document.file_name;
                
                console.log(`📥 File diterima untuk dekripsi: ${fileName}`);
                
                // Download file
                const fileStream = bot.getFileStream(fileId);
                const chunks = [];
                
                for await (const chunk of fileStream) {
                    chunks.push(chunk);
                }
                
                const fileBuffer = Buffer.concat(chunks);
                const tempInputPath = path.join(bashEncrypt.tempDir, `input_${Date.now()}.sh`);
                fs.writeFileSync(tempInputPath, fileBuffer);
                
                // Tentukan nama output file
                let outputFileName;
                if (fileName.endsWith('.encrypted')) {
                    outputFileName = `decrypted_${fileName.replace('.encrypted', '.sh')}`;
                } else if (fileName.endsWith('.sh')) {
                    outputFileName = `decrypted_${fileName}`;
                } else {
                    outputFileName = `decrypted_${fileName}.sh`;
                }
                
                // Decrypt script
                const result = await bashEncrypt.decryptScript(tempInputPath, outputFileName);
                
                if (result.success) {
                    // Kirim file hasil dekripsi
                    await bot.sendDocument(
                        chatId,
                        result.outputPath,
                        {
                            caption: `✅ <b>Script Berhasil Didekripsi!</b>\n\n` +
                                    `📁 <b>File:</b> ${outputFileName}\n` +
                                    `💾 <b>Size:</b> ${(fs.statSync(result.outputPath).size / 1024).toFixed(2)} KB\n` +
                                    `🔓 <b>Status:</b> Terdekripsi dengan eval-to-echo\n\n` +
                                    `<i>File telah berhasil didekripsi dan siap digunakan.</i>\n` +
                                    `<b>Developer Script: @PeyxDev</b>`,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '🔒 Enkripsi', callback_data: 'bash_encrypt' },
                                        { text: '🔓 Dekripsi Lagi', callback_data: 'bash_decrypt' }
                                    ],
                                    [
                                        { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                                    ]
                                ]
                            }
                        },
                        {
                            filename: outputFileName
                        }
                    );
                    
                    await bot.deleteMessage(chatId, loadingMsg.message_id);
                    
                    // PERBAIKAN: Hanya cleanup file temporary, bukan file hasil
                    setTimeout(() => {
                        bashEncrypt.cleanupTempFiles(); // Hanya hapus file temp
                    }, 30000);
                    
                } else {
                    throw new Error('Gagal mendekripsi script');
                }
                
                // Hapus input file temporary saja
                try {
                    if (fs.existsSync(tempInputPath)) {
                        fs.unlinkSync(tempInputPath);
                    }
                } catch (e) {}
                
            } catch (error) {
                console.error('❌ Bash Decrypt Error:', error);
                await bot.sendMessage(chatId, 
                    `❌ Gagal mendekripsi script:\n<code>${error.message}</code>`,
                    {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🔄 Coba Lagi', callback_data: 'bash_decrypt' }],
                                [{ text: '🔙 Kembali ke Menu', callback_data: 'bash_encrypt_menu' }]
                            ]
                        }
                    }
                ).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };
    
    // Tambahkan listener
    bot.on('message', fileListener);
    
    // Timeout
    const timeoutId = setTimeout(() => {
        bot.removeListener('message', fileListener);
        console.log(`⏰ Timeout: Listener dihapus untuk chat ${chatId}`);
        
        bot.sendMessage(chatId, 
            '⏰ <b>Waktu upload telah habis</b>\n\n' +
            'Silakan pilih aksi yang ingin dilakukan:',
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔒 Enkripsi Script', callback_data: 'bash_encrypt' },
                            { text: '🔓 Dekripsi Script', callback_data: 'bash_decrypt' }
                        ],
                        [
                            { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                        ]
                    ]
                }
            }
        ).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }, 120000);
}

// PERBAIKAN: Juga update handler untuk cek dependencies dan install dependencies
async function handleBashCheckDeps(chatId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '⚙️ Mengecek dependencies...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const isInstalled = await bashEncrypt.checkBashObfuscate();
        
        if (isInstalled) {
            await bot.editMessageText(
                '✅ <b>Dependencies Check</b>\n\n' +
                '🔧 <b>bash-obfuscate:</b> ✅ Terinstall\n\n' +
                'Semua dependencies sudah terinstall dan siap digunakan!',
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔒 Enkripsi Script', callback_data: 'bash_encrypt' },
                                { text: '🔓 Dekripsi Script', callback_data: 'bash_decrypt' }
                            ],
                            [
                                { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                            ]
                        ]
                    }
                }
            );
        } else {
            await bot.editMessageText(
                '❌ <b>Dependencies Check</b>\n\n' +
                '🔧 <b>bash-obfuscate:</b> ❌ Tidak terinstall\n\n' +
                'Silakan install bash-obfuscate terlebih dahulu:\n' +
                '<code>npm install -g bash-obfuscate</code>',
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📦 Install Otomatis', callback_data: 'bash_install_deps' }],
                            [
                                { text: '🔒 Enkripsi', callback_data: 'bash_encrypt' },
                                { text: '🔓 Dekripsi', callback_data: 'bash_decrypt' }
                            ],
                            [
                                { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        console.error('❌ Bash Check Deps Error:', error);
        await bot.sendMessage(chatId, 
            '❌ Gagal mengecek dependencies',
            {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔄 Coba Lagi', callback_data: 'bash_check_deps' },
                            { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                        ]
                    ]
                }
            }
        ).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk install dependencies - DIPERBAIKI: Tambah button kembali
async function handleBashInstallDeps(chatId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '📦 Menginstall bash-obfuscate...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        await bashEncrypt.installBashObfuscate();
        
        await bot.editMessageText(
            '✅ <b>Installasi Berhasil!</b>\n\n' +
            'bash-obfuscate berhasil diinstall. Sekarang Anda bisa menggunakan fitur enkripsi script.',
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔒 Enkripsi Script', callback_data: 'bash_encrypt' },
                            { text: '🔓 Dekripsi Script', callback_data: 'bash_decrypt' }
                        ],
                        [
                            { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                        ]
                    ]
                }
            }
        );
    } catch (error) {
        console.error('❌ Bash Install Deps Error:', error);
        await bot.editMessageText(
            `❌ <b>Gagal Install Dependencies</b>\n\n` +
            `Error: ${error.message}\n\n` +
            `Silakan install manual:\n` +
            `<code>npm install -g bash-obfuscate</code>`,
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🔄 Coba Lagi', callback_data: 'bash_install_deps' },
                            { text: '📋 Menu Bash Encrypt', callback_data: 'bash_encrypt_menu' }
                        ]
                    ]
                }
            }
        );
    }
}

// ✅ FUNGSI INI HARUS DITARUH DI SINI - SETELAH githubConfig DIBUAT
async function ensureConfigsFolder() {
    try {
        // Cek apakah folder configs sudah ada
        const response = await axios.get(
            `${githubConfig.baseURL}/contents/configs`,
            { 
                headers: githubConfig.headers,
                timeout: 15000
            }
        );
        console.log('✅ Folder configs sudah ada');
        return true;
    } catch (error) {
        if (error.response && error.response.status === 404) {
            // Folder belum ada, buat folder dengan membuat file README
            console.log('📁 Membuat folder configs...');
            try {
                const createResponse = await axios.put(
                    `${githubConfig.baseURL}/contents/configs/README.md`,
                    {
                        message: 'Create configs folder',
                        content: Buffer.from('# Configs Folder\n\nFolder untuk menyimpan file config.').toString('base64'),
                        branch: githubConfig.config.branch
                    },
                    { 
                        headers: githubConfig.headers,
                        timeout: 30000
                    }
                );
                console.log('✅ Folder configs berhasil dibuat');
                return true;
            } catch (createError) {
                console.error('❌ Gagal membuat folder configs:', createError.message);
                return false;
            }
        }
        console.error('❌ Error checking configs folder:', error.message);
        return false;
    }
}

// Helper functions untuk config manager
function formatFileName(name) {
    if (name.length > 20) {
        return name.substring(0, 17) + '...';
    }
    return name;
}

// Tambahkan di fungsi getFileIcon
function getFileIcon(name) {
    const ext = name.toLowerCase().split('.').pop();
    const icons = {
        'hc': '⚡',
        'hi': '🔰',
        'json': '📊',
        'txt': '📄',
        'config': '⚙️',
        'yaml': '📋',
        'yml': '📋',
        'nm': '🔮',     // TAMBAHAN BARU: Icon untuk .nm
        'ziv': '🌟',     // TAMBAHAN BARU: Icon untuk .ziv  
        'dark': '🌙'     // TAMBAHAN BARU: Icon untuk .dark
    };
    return icons[ext] || '📁';
}

// Handler untuk menu config manager
// Handler untuk menu config manager - DIPERBARUI: Dengan GIF
async function handleUploadConfig(chatId, user, messageId = null) {
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const isUserAdmin = isAdmin(user.id.toString());
    
    const menuText = `
<b>📁 CONFIG PREMIUM PX STORE</b>

Download Config Premium Free Semoga Berkah

${isUserAdmin ? '• 📤 Upload Config - Upload file config baru (Admin Only)\n' : ''}
${isUserAdmin ? '• 🗑️ Delete Config - Hapus file config (Admin Only)\n' : ''}
• 📋 List Config - Lihat daftar config yang tersedia
• 📥 Download Config - Download config yang ada
• 🔄 Refresh List - Perbarui daftar config

<b> Rules config premium free</b>
• Dilarang nonton bokep
• Dilarang share
• Dilarang judol
• Dilarang multi login
• Dilarang diperjual belikan

Pilih aksi yang ingin dilakukan:
    `;

    const buttons = [];
    
    // LIST CONFIG DI ATAS (UNTUK SEMUA USER)
    buttons.push([
        { text: '📋 List Config', callback_data: 'config_list' }
    ]);
    
    // TOMBOL ADMIN ONLY
    if (isUserAdmin) {
        buttons.push([
            { text: '📤 Upload Config', callback_data: 'config_upload' },
            { text: '🗑️ Delete Config', callback_data: 'config_delete' }
        ]);
    }
    
    // TOMBOL LAINNYA
    buttons.push([
        { text: '📥 Download Config', callback_data: 'config_download_menu' },
        { text: '🔄 Refresh List', callback_data: 'config_refresh' }
    ]);
    
    // TOMBOL KEMBALI
    buttons.push([
        { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
    ]);

    const options = {
        reply_markup: { inline_keyboard: buttons },
        parse_mode: 'HTML'
    };

    // Gunakan GIF seperti di menu utama
    const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

    bot.sendAnimation(chatId, gifUrl, {
        caption: menuText,
        parse_mode: 'HTML',
        reply_markup: options.reply_markup
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendAnimation handleUploadConfig error:', err);
        // Fallback ke text message jika GIF gagal
        bot.sendMessage(chatId, menuText, options).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        }).catch(fallbackErr => {
            console.error('Fallback sendMessage error:', fallbackErr);
        });
    });
}

// Handler untuk delete config (HANYA ADMIN) - FUNGSI BARU
async function handleConfigDelete(chatId, user) {
    if (!isAdmin(user.id.toString())) {
        await bot.sendMessage(chatId, 
            '❌ <b>Akses Ditolak!</b>\n\n' +
            'Fitur hapus config hanya tersedia untuk admin.\n' +
            'Silakan hubungi admin untuk menghapus config.',
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📋 Lihat Config', callback_data: 'config_list' }],
                        [{ text: '🔙 Kembali', callback_data: 'upload_config_menu' }]
                    ]
                }
            }
        ).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
        return;
    }

    await showConfigDeleteList(chatId, 0);
}

// Fungsi untuk menampilkan list file untuk dihapus - FUNGSI BARU
// Fungsi untuk menampilkan list file untuk dihapus - DIPERBARUI: Dengan GIF
async function showConfigDeleteList(chatId, page = 0) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '🗑️ Mengambil daftar config untuk dihapus...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const categories = await githubConfig.getFilesByCategory();
        
        // Dalam fungsi handleConfigList - modifikasi allFiles
const allFiles = [
    ...categories.httpCustom,
    ...categories.httpInjector,
    ...categories.v2ray,
    ...categories.trojan,
    ...categories.nm,        // TAMBAHAN BARU
    ...categories.ziv,       // TAMBAHAN BARU  
    ...categories.dark,      // TAMBAHAN BARU
    ...categories.other
];

        if (allFiles.length === 0) {
            await bot.editMessageText(
                '📭 <b>Tidak ada config yang bisa dihapus.</b>\n\n' +
                'Folder configs kosong atau belum ada file config.',
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📤 Upload Config', callback_data: 'config_upload' }],
                            [{ text: '🔙 Kembali', callback_data: 'upload_config_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const itemsPerPage = 8;
        const totalPages = Math.ceil(allFiles.length / itemsPerPage);
        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const currentFiles = allFiles.slice(startIndex, endIndex);

        const message = `<b>🗑️ HAPUS CONFIG FILE</b>\n` +
                       `<i>📍 Pilih file yang ingin dihapus:</i>\n\n` +
                       `Total files: <b>${allFiles.length}</b>\n` +
                       `Halaman ${page + 1} dari ${totalPages}\n\n` +
                       `<i>⚠️ Hati-hati! File yang dihapus tidak bisa dikembalikan.</i>`;

        const buttons = [];

        // BUTTON VERTIKAL: Setiap file dalam baris terpisah
        currentFiles.forEach(file => {
            buttons.push([
                { 
                    text: `🗑️ ${formatFileName(file.name)}`, 
                    callback_data: `config_delete_confirm_${encodeURIComponent(file.name)}` 
                }
            ]);
        });

        // Tombol pagination
        const paginationButtons = [];
        if (page > 0) {
            paginationButtons.push({
                text: '⬅️ Sebelumnya',
                callback_data: `config_delete_page_${page - 1}`
            });
        }
        if (page < totalPages - 1) {
            paginationButtons.push({
                text: 'Selanjutnya ➡️',
                callback_data: `config_delete_page_${page + 1}`
            });
        }
        if (paginationButtons.length > 0) {
            buttons.push(paginationButtons);
        }

        // Tombol aksi
        buttons.push([
            { text: '🔄 Refresh', callback_data: 'config_delete' },
            { text: '📋 List Config', callback_data: 'config_list' }
        ]);
        buttons.push([
            { text: '🔙 Kembali', callback_data: 'upload_config_menu' }
        ]);

        // Hapus loading message
        await bot.deleteMessage(chatId, loadingMsg.message_id);

        // Gunakan GIF seperti di menu utama
        const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

        bot.sendAnimation(chatId, gifUrl, {
            caption: message,
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: buttons }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        }).catch(err => {
            console.error('sendAnimation showConfigDeleteList error:', err);
            // Fallback ke text message jika GIF gagal
            bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            }).then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
        });

    } catch (error) {
        console.error('❌ Config Delete List Error:', error);
        await bot.editMessageText(
            '❌ Gagal mengambil daftar config untuk dihapus\n\n' +
            `Error: ${error.message}`,
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'config_delete' }],
                        [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                    ]
                }
            }
        );
    }
}

// Handler untuk konfirmasi delete file - FUNGSI BARU
async function handleConfigDeleteConfirm(chatId, fileName) {
    try {
        const decodedFileName = decodeURIComponent(fileName);
        
        const confirmMessage = `
<b>🗑️ KONFIRMASI HAPUS FILE</b>

📁 <b>File:</b> <code>${decodedFileName}</code>
📂 <b>Lokasi:</b> folder configs

⚠️ <b>PERINGATAN:</b>
• File akan dihapus permanen dari repository GitHub
• Tindakan ini tidak dapat dibatalkan
• Pastikan file yang dihapus sudah benar

Apakah Anda yakin ingin menghapus file ini?
        `;

        await bot.sendMessage(chatId, confirmMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '✅ Ya, Hapus File', callback_data: `config_delete_execute_${fileName}` },
                        { text: '❌ Batal', callback_data: 'config_delete' }
                    ]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });

    } catch (error) {
        console.error('❌ Config Delete Confirm Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal memproses konfirmasi hapus file');
    }
}

// Handler untuk eksekusi delete file - FUNGSI BARU
async function handleConfigDeleteExecute(chatId, fileName) {
    try {
        const decodedFileName = decodeURIComponent(fileName);
        const filePath = `configs/${decodedFileName}`;
        
        const loadingMsg = await bot.sendMessage(chatId, `🗑️ Menghapus file "${decodedFileName}"...`);
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const result = await githubConfig.deleteFile(filePath);
        
        if (result.success) {
            await bot.editMessageText(
                `✅ <b>File Berhasil Dihapus!</b>\n\n` +
                `🗑️ <b>File:</b> <code>${decodedFileName}</code>\n` +
                `📂 <b>Lokasi:</b> folder configs\n` +
                `🔗 <b>Status:</b> Terhapus dari GitHub\n\n` +
                `File telah berhasil dihapus dari repository GitHub.`,
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🗑️ Hapus Lagi', callback_data: 'config_delete' }],
                            [{ text: '📋 List Config', callback_data: 'config_list' }],
                            [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                        ]
                    }
                }
            );
            
            console.log(`✅ File ${decodedFileName} berhasil dihapus oleh admin`);
        } else {
            throw new Error(result.error);
        }
        
    } catch (error) {
        console.error('❌ Config Delete Execute Error:', error);
        await bot.editMessageText(
            `❌ <b>Gagal Menghapus File!</b>\n\n` +
            `📁 <b>File:</b> <code>${fileName}</code>\n` +
            `❌ <b>Error:</b> ${error.message}\n\n` +
            `Silakan coba lagi atau periksa koneksi GitHub.`,
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: `config_delete_confirm_${fileName}` }],
                        [{ text: '🔙 Kembali', callback_data: 'config_delete' }]
                    ]
                }
            }
        );
    }
}

// Handler untuk upload config (HANYA ADMIN) - DIPERBARUI: Dengan GIF
async function handleConfigUpload(chatId, user) {
    if (!isAdmin(user.id.toString())) {
        // Gunakan GIF untuk error message juga
        const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';
        
        const errorMessage = '❌ <b>Akses Ditolak!</b>\n\n' +
            'Fitur upload config hanya tersedia untuk admin.\n' +
            'Silakan hubungi admin untuk upload config.';

        bot.sendAnimation(chatId, gifUrl, {
            caption: errorMessage,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '📋 Lihat Config', callback_data: 'config_list' }],
                    [{ text: '🔙 Kembali', callback_data: 'upload_config_menu' }]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        }).catch(err => {
            // Fallback ke text
            bot.sendMessage(chatId, errorMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📋 Lihat Config', callback_data: 'config_list' }],
                        [{ text: '🔙 Kembali', callback_data: 'upload_config_menu' }]
                    ]
                }
            }).then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
        });
        return;
    }

    const uploadMessage = '<b>📤 Upload Config File (Admin Only)</b>\n\n' +
        'Silakan kirim file config yang ingin diupload:\n\n' +
        'Format yang didukung:\n' +
        '⚡ .hc (HTTP Custom)\n' +
        '🔰 .hi (HTTP Injector)\n' +
        '🔮 .nm (Netmod)\n' +
        '🌟 .ziv (Zivpn)\n' +
        '🌙 .dark (Dark Tunnel)\n' +
        '📊 .json\n' +
        '📄 .txt\n' +
        '⚙️ .config\n' +
        '📋 .yaml, .yml\n\n' +
        '<i>File akan otomatis tersimpan di folder <b>configs</b></i>';

    // Gunakan GIF untuk upload prompt
    const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

    bot.sendAnimation(chatId, gifUrl, {
        caption: uploadMessage,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '❌ Batal', callback_data: 'upload_config_menu' }]
            ]
        }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendAnimation handleConfigUpload error:', err);
        // Fallback ke text message jika GIF gagal
        bot.sendMessage(chatId, uploadMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '❌ Batal', callback_data: 'upload_config_menu' }]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    });

    // ... dalam fileListener async (fileMsg) ...
const fileListener = async (fileMsg) => {
    if (fileMsg.document) {
        try {
            const loadingMsg = await bot.sendMessage(chatId, '📤 Mengupload file config ke folder configs...');
            saveActionMessage(chatId, loadingMsg.message_id);
            
            const fileId = fileMsg.document.file_id;
            const fileName = fileMsg.document.file_name;
            
            // PERBAIKAN: Definisikan allowedExtensions dengan benar
            const allowedExtensions = ['.hc', '.hi', '.txt', '.json', '.config', '.yaml', '.yml', '.nm', '.ziv', '.dark'];
            const fileExtension = fileName.toLowerCase().substring(fileName.lastIndexOf('.'));
            
            if (!allowedExtensions.includes(fileExtension)) {
                await bot.editMessageText(
                    `❌ Format file tidak didukung!\n\n` +
                    `Format yang diperbolehkan: ${allowedExtensions.join(', ')}\n\n` +
                    `File Anda: ${fileName}`,
                    {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🔄 Coba Lagi', callback_data: 'config_upload' }],
                                [{ text: '📤 Menu Upload', callback_data: 'upload_config_menu' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            const fileStream = bot.getFileStream(fileId);
            const chunks = [];
            
            for await (const chunk of fileStream) {
                chunks.push(chunk);
            }
            
            const fileBuffer = Buffer.concat(chunks);
            const fileContent = fileBuffer.toString('utf8');
            
            // PASTIKAN FOLDER CONFIGS ADA SEBELUM UPLOAD
            const folderReady = await ensureConfigsFolder();
            if (!folderReady) {
                await bot.editMessageText('❌ Gagal mempersiapkan folder configs', {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id
                });
                return;
            }
            
            const result = await githubConfig.uploadConfigToFolder(fileName, fileContent, 'configs');
            
            if (result.success) {
                await bot.editMessageText(
                    `✅ <b>Config Berhasil Diupload!</b>\n\n` +
                    `📁 <b>File:</b> <code>configs/${fileName}</code>\n` +
                    `💾 <b>Size:</b> ${(fileBuffer.length / 1024).toFixed(2)} KB\n` +
                    `👤 <b>Oleh:</b> Admin\n` +
                    `📂 <b>Lokasi:</b> Folder configs\n` +
                    `🔗 <b>Status:</b> Tersimpan di GitHub\n\n` +
                    `File config telah berhasil diupload ke folder configs di repository GitHub.`,
                    {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '📋 Lihat Semua Config', callback_data: 'config_list' }],
                                [{ text: '📤 Upload Lagi', callback_data: 'config_upload' }],
                                [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                            ]
                        }
                    }
                );
            } else {
                throw new Error(result.error);
            }
            
        } catch (error) {
            console.error('❌ Upload Config Error:', error);
            await bot.sendMessage(chatId, 
                `❌ Gagal mengupload config:\n<code>${error.message}</code>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'config_upload' }],
                            [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                        ]
                    }
                }
            ).then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
        }
    }
};
    
    bot.on('message', fileListener);
    
    setTimeout(() => {
        bot.removeListener('message', fileListener);
    }, 120000);
}

// Handler untuk list config dengan button otomatis (UNTUK SEMUA USER)
// Handler untuk list config dengan button otomatis - DIPERBARUI: Dengan GIF
async function handleConfigList(chatId, page = 0) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '📋 Mengambil daftar config dari folder configs...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        console.log('🔄 Getting files from configs folder...');
        const categories = await githubConfig.getFilesByCategory();
        
        console.log('📊 Categories result:', {
            httpCustom: categories.httpCustom.length,
            httpInjector: categories.httpInjector.length,
            v2ray: categories.v2ray.length,
            trojan: categories.trojan.length,
            other: categories.other.length
        });
        
        // Dalam fungsi handleConfigList - modifikasi allFiles
const allFiles = [
    ...categories.httpCustom,
    ...categories.httpInjector,
    ...categories.v2ray,
    ...categories.trojan,
    ...categories.nm,        // TAMBAHAN BARU
    ...categories.ziv,       // TAMBAHAN BARU  
    ...categories.dark,      // TAMBAHAN BARU
    ...categories.other
];

        console.log('📁 Total files found:', allFiles.length);
        console.log('📝 File names:', allFiles.map(f => f.name));

        if (allFiles.length === 0) {
            await bot.editMessageText(
                '📭 <b>Tidak ada config yang tersedia di folder configs.</b>\n\n' +
                'Kemungkinan penyebab:\n' +
                '• Folder configs belum ada\n' + 
                '• Belum ada file yang diupload\n' +
                '• File tidak sesuai format\n\n' +
                'Silakan upload config terlebih dahulu.',
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📤 Upload Config', callback_data: 'config_upload' }],
                            [{ text: '🔄 Refresh', callback_data: 'config_list' }],
                            [{ text: '🔙 Kembali', callback_data: 'upload_config_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const itemsPerPage = 10;
        const totalPages = Math.ceil(allFiles.length / itemsPerPage);
        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const currentFiles = allFiles.slice(startIndex, endIndex);

        // Dalam fungsi handleConfigList - modifikasi bagian message
const message = `<b>📂 DAFTAR CONFIG TERSEDIA</b>\n` +
       `<i>• Config sepenuhnya gratis</i>\n` +
       `<i>• Config sudah di tes dan connect</i>\n` +
       `<i>• Jangan lupa laporannya</i>\n` +
       `<i>• Tidak semua TKP support</i>\n` +
       `<i>• Kalo sunek mode pesawat dulu</i>\n\n` +
       `<i> ☕ <a href="https://t.me/payqris_bot"><b>Traktir kopi</b></a></i>\n\n` +
       `${categories.httpCustom.length > 0 ? `⚡ <b>HTTP Custom:</b> ${categories.httpCustom.length} file\n` : ''}` +
       `${categories.httpInjector.length > 0 ? `🔰 <b>HTTP Injector:</b> ${categories.httpInjector.length} file\n` : ''}` +
       `${categories.v2ray.length > 0 ? `🌐 <b>V2Ray:</b> ${categories.v2ray.length} file\n` : ''}` +
       `${categories.trojan.length > 0 ? `🐎 <b>Trojan:</b> ${categories.trojan.length} file\n` : ''}` +
       `${categories.nm.length > 0 ? `🔮 <b>Netmod:</b> ${categories.nm.length} file\n` : ''}` +        // TAMBAHAN BARU
       `${categories.ziv.length > 0 ? `🌟 <b>ZIVPN:</b> ${categories.ziv.length} file\n` : ''}` +      // TAMBAHAN BARU
       `${categories.dark.length > 0 ? `🌙 <b>Dark Tunnel:</b> ${categories.dark.length} file\n` : ''}` +   // TAMBAHAN BARU
       `${categories.other.length > 0 ? `📄 <b>Lainnya:</b> ${categories.other.length} file\n` : ''}` +
       `\nTotal: <b>${allFiles.length} config files</b>\n` +
       `Halaman ${page + 1} dari ${totalPages}\n\n` +
       `<b>Klik nama file untuk download:</b>`;

        const buttons = [];

        // BUTTON VERTIKAL: Setiap file dalam baris terpisah
        currentFiles.forEach(file => {
            buttons.push([
                { 
                    text: `${getFileIcon(file.name)} ${formatFileName(file.name)}`, 
                    callback_data: `config_download_${encodeURIComponent(file.name)}`
                }
            ]);
        });

        // Tombol pagination
        const paginationButtons = [];
        if (page > 0) {
            paginationButtons.push({
                text: '⬅️ Sebelumnya',
                callback_data: `config_list_page_${page - 1}`
            });
        }
        if (page < totalPages - 1) {
            paginationButtons.push({
                text: 'Selanjutnya ➡️',
                callback_data: `config_list_page_${page + 1}`
            });
        }
        if (paginationButtons.length > 0) {
            buttons.push(paginationButtons);
        }

        // Tombol aksi
        buttons.push([
            { text: '🔄 Refresh', callback_data: 'config_refresh' },
            { text: '📥 Download Menu', callback_data: 'config_download_menu' }
        ]);
        buttons.push([
            { text: '🔙 Kembali', callback_data: 'upload_config_menu' }
        ]);

        // Hapus loading message
        await bot.deleteMessage(chatId, loadingMsg.message_id);

        // Gunakan GIF seperti di menu utama
        const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

        bot.sendAnimation(chatId, gifUrl, {
            caption: message,
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: buttons }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        }).catch(err => {
            console.error('sendAnimation handleConfigList error:', err);
            // Fallback ke text message jika GIF gagal
            bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            }).then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
        });

    } catch (error) {
        console.error('❌ Config List Error:', error);
        await bot.editMessageText(
            '❌ Gagal mengambil daftar config\n\n' +
            `Error: ${error.message}`,
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'config_list' }],
                        [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                    ]
                }
            }
        );
    }
}

// Handler untuk download config (UNTUK SEMUA USER) - VERSI DIPERBAIKI
// Handler untuk download config - VERSI DIPERBAIKI UNTUK HANDLE BERBAGAI FORMAT
async function handleConfigDownload(chatId, fileName) {
    try {
        const decodedFileName = decodeURIComponent(fileName);
        const filePath = `configs/${decodedFileName}`;
        
        console.log(`📥 Starting download: ${filePath}`);
        
        const loadingMsg = await bot.sendMessage(chatId, `📥 Mengunduh "${decodedFileName}" dari folder configs...`);
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const result = await githubConfig.downloadFile(filePath);
        
        if (result.success) {
            let fileBuffer;
            let fileExtension = decodedFileName.toLowerCase().split('.').pop();
            
            console.log(`📊 Download result:`, {
                method: result.method,
                size: result.size,
                type: typeof result.content,
                isBuffer: result.content instanceof Buffer,
                extension: fileExtension
            });
            
            // Handle different content types
            if (result.content instanceof Buffer) {
                fileBuffer = result.content;
            } else if (typeof result.content === 'string') {
                // Jika content adalah string, convert ke Buffer
                fileBuffer = Buffer.from(result.content, 'utf8');
            } else if (result.content instanceof ArrayBuffer) {
                fileBuffer = Buffer.from(result.content);
            } else {
                // Fallback: convert ke string lalu ke buffer
                fileBuffer = Buffer.from(String(result.content), 'utf8');
            }
            
            // Tentukan MIME type berdasarkan ekstensi file
           // Dalam fungsi handleConfigDownload - modifikasi mimeTypes
const mimeTypes = {
    'hc': 'text/plain',
    'hi': 'text/plain', 
    'txt': 'text/plain',
    'json': 'application/json',
    'config': 'text/plain',
    'yaml': 'text/yaml',
    'yml': 'text/yaml',
    'nm': 'text/plain',     // TAMBAHAN BARU
    'ziv': 'text/plain',    // TAMBAHAN BARU
    'dark': 'text/plain'    // TAMBAHAN BARU
};
            
            const mimeType = mimeTypes[fileExtension] || 'application/octet-stream';
            
            console.log(`📁 Sending document: ${result.name}, size: ${fileBuffer.length}, mime: ${mimeType}`);
            
            // Kirim file sebagai document
            await bot.sendDocument(
                chatId,
                fileBuffer,
                {
                    caption: `📁 <b>${result.name}</b>\n\n` +
                            `✅ Berhasil diunduh\n` +
                            `📏 Size: ${(fileBuffer.length / 1024).toFixed(2)} KB\n` +
                            `📂 <b>Jenis:</b> Configs\n` +
                            `🔗 <b>Method:</b> ${result.method}\n` +
                            `💾 <b>Format:</b> ${fileExtension.toUpperCase()}`,
                    parse_mode: 'HTML'
                },
                {
                    filename: result.name,
                    contentType: mimeType
                }
            );
            
            await bot.deleteMessage(chatId, loadingMsg.message_id);
            console.log(`✅ Download successful: ${result.name}`);
            
        } else {
            throw new Error(result.error || 'Gagal mengunduh file');
        }
        
    } catch (error) {
        console.error('❌ Config Download Error:', error);
        
        let errorMessage = `❌ Gagal mengunduh "${fileName}"`;
        
        if (error.message.includes('404') || error.message.includes('Not Found')) {
            errorMessage += '\n\n⚠️ File tidak ditemukan di folder configs.';
            errorMessage += '\nMungkin file sudah dihapus atau dipindahkan.';
        } else if (error.message.includes('401') || error.message.includes('403')) {
            errorMessage += '\n\n🔐 Akses ditolak. Periksa token GitHub.';
        } else if (error.message.includes('EFATAL') || error.message.includes('Buffer')) {
            errorMessage += '\n\n⚙️ Format file tidak didukung. Coba upload ulang file.';
            errorMessage += '\n💡 Tips: Pastikan file berformat text (bukan binary).';
        } else if (error.message.includes('timeout')) {
            errorMessage += '\n\n⏰ Timeout: Koneksi ke GitHub terlalu lama.';
        } else {
            errorMessage += `\n\nError: ${error.message}`;
        }
        
        // Coba hapus loading message jika masih ada
        try {
            await bot.deleteMessage(chatId, loadingMsg.message_id);
        } catch (e) {
            // Ignore delete errors
        }
        
        await bot.sendMessage(chatId, errorMessage, {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Refresh List', callback_data: 'config_list' }],
                    [{ text: '📤 Menu Config', callback_data: 'upload_config_menu' }]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk refresh config list
async function handleConfigRefresh(chatId) {
    await bot.sendMessage(chatId, '🔄 Memperbarui daftar config...').then(async msg => {
        saveActionMessage(chatId, msg.message_id);
        await handleConfigList(chatId);
    });
}

// Handler untuk download config menu
async function handleConfigDownloadMenu(chatId) {
    await handleConfigList(chatId);
}

// ===============================
// SISTEM BARU: AUTO DELETE MESSAGE
// ===============================

// Store untuk menyimpan message ID per user
const userMessages = new Map(); // { chatId: { menuMessageId, actionMessages: [], tempMessages: [] } }

// Fungsi untuk menyimpan message ID menu utama
function saveMenuMessage(chatId, messageId) {
    if (!userMessages.has(chatId)) {
        userMessages.set(chatId, {
            menuMessageId: null,
            actionMessages: [],
            tempMessages: []
        });
    }
    
    const userData = userMessages.get(chatId);
    userData.menuMessageId = messageId;
}

// Fungsi untuk menyimpan message ID aksi
function saveActionMessage(chatId, messageId) {
    if (!userMessages.has(chatId)) {
        userMessages.set(chatId, {
            menuMessageId: null,
            actionMessages: [],
            tempMessages: []
        });
    }
    
    const userData = userMessages.get(chatId);
    userData.actionMessages.push(messageId);
    
    // Batasi jumlah action messages untuk menghindari memory leak
    if (userData.actionMessages.length > 10) {
        userData.actionMessages = userData.actionMessages.slice(-5);
    }
}

// Fungsi untuk menambah message temporary
function addTempMessage(chatId, messageId) {
    if (!userMessages.has(chatId)) {
        userMessages.set(chatId, {
            menuMessageId: null,
            actionMessages: [],
            tempMessages: []
        });
    }
    
    const userData = userMessages.get(chatId);
    userData.tempMessages.push(messageId);
    
    // Batasi jumlah temp messages untuk menghindari memory leak
    if (userData.tempMessages.length > 10) {
        userData.tempMessages = userData.tempMessages.slice(-5);
    }
}

// Fungsi untuk menghapus pesan lama user
async function cleanupOldMessages(chatId, keepMenu = false) {
    try {
        if (!userMessages.has(chatId)) return;
        
        const userData = userMessages.get(chatId);
        const messagesToDelete = [];
        
        // Hapus action messages
        if (userData.actionMessages.length > 0) {
            messagesToDelete.push(...userData.actionMessages);
            userData.actionMessages = [];
        }
        
        // Hapus temp messages
        if (userData.tempMessages.length > 0) {
            messagesToDelete.push(...userData.tempMessages);
            userData.tempMessages = [];
        }
        
        // Hapus menu message jika tidak di-keep
        if (!keepMenu && userData.menuMessageId) {
            messagesToDelete.push(userData.menuMessageId);
            userData.menuMessageId = null;
        }
        
        // Delete messages secara batch
        for (const messageId of messagesToDelete) {
            try {
                await bot.deleteMessage(chatId, messageId);
                await new Promise(resolve => setTimeout(resolve, 100)); // Delay kecil antara delete
            } catch (deleteError) {
                // Ignore delete errors (message mungkin sudah dihapus)
            }
        }
        
        console.log(`🧹 Cleanup selesai untuk chat ${chatId}, dihapus: ${messagesToDelete.length} pesan`);
        
    } catch (error) {
        console.error('❌ Cleanup error:', error);
    }
}

// Load allowed users dari file
function loadAllowedUsers() {
    try {
        if (fs.existsSync(USERS_FILE)) {
            const data = fs.readFileSync(USERS_FILE, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('❌ Error loading users file:', error);
    }
    
    // Default users dari .env
    return {
        allowedUsers: ALLOWED_USERS,
        temporaryAccess: {}, // { userId: timestamp }
        pendingRequests: []
    };
}

// Save allowed users ke file
function saveAllowedUsers(usersData) {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(usersData, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Error saving users file:', error);
        return false;
    }
}

// Update environment variable di .env file
function updateEnvVariable(key, value) {
    try {
        let envContent = '';
        if (fs.existsSync(ENV_FILE)) {
            envContent = fs.readFileSync(ENV_FILE, 'utf8');
        }
        
        const lines = envContent.split('\n');
        let found = false;
        const newLines = lines.map(line => {
            if (line.startsWith(key + '=')) {
                found = true;
                return `${key}=${value}`;
            }
            return line;
        });
        
        if (!found) {
            newLines.push(`${key}=${value}`);
        }
        
        fs.writeFileSync(ENV_FILE, newLines.join('\n'));
        
        // Update process.env juga
        process.env[key] = value;
        
        console.log(`✅ Environment variable ${key} berhasil diupdate`);
        return true;
    } catch (error) {
        console.error(`❌ Error updating ${key}:`, error);
        return false;
    }
}

// Cek apakah user adalah admin
function isAdmin(userId) {
    return userId.toString() === ADMIN_CHAT_ID;
}

// ===============================
// HANDLER BARU: AUTO WILDCARD CALLBACK
// ===============================

// Handler untuk wildcard callback - FUNGSI BARU
async function handleWildcardCallback(chatId, data, user, bot) {
    try {
        switch (data) {
            case 'pointing_wildcard_setup':
                await pointingDomain.setupWildcardDomain(chatId, bot);
                break;
            case 'pointing_wildcard_info':
                await pointingDomain.showWildcardInfo(chatId, bot);
                break;
            case 'pointing_wildcard_script':
                await handleWildcardScriptView(chatId, bot);
                break;
            default:
                await bot.sendMessage(chatId, '❌ Aksi wildcard tidak dikenali').then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
        }
    } catch (error) {
        console.error('❌ Wildcard Callback Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memproses wildcard').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk pointing domain callback - FUNGSI BARU YANG LENGKAP
async function handlePointingCallback(chatId, data, user, bot) {
    try {
        switch (data) {
            case 'pointing_domain':
                await pointingDomain.showMenu(chatId, user, bot);
                break;
            case 'pointing_setup':
                await pointingDomain.handleSetupCloudflare(chatId, user, bot);
                break;
            case 'pointing_list':
                await pointingDomain.handleListDomains(chatId, bot, 0);
                break;
            case 'pointing_add':
                await pointingDomain.handleAddDomain(chatId, user, bot);
                break;
            case 'pointing_delete':
                await pointingDomain.handleDeleteDomain(chatId, bot);
                break;
            case 'pointing_wildcard':
                await pointingDomain.handleAutoWildcard(chatId, bot);
                break;
            case 'pointing_confirm_add':
                await pointingDomain.handleConfirmAddDomain(chatId, bot);
                break;
            case 'pointing_type_A':
            case 'pointing_type_CNAME':
                const recordType = data.replace('pointing_type_', '');
                await pointingDomain.handleRecordTypeSelection(chatId, recordType, bot);
                break;
            case 'pointing_proxied_true':
            case 'pointing_proxied_false':
                const proxiedStatus = data.replace('pointing_proxied_', '');
                await pointingDomain.handleProxiedSelection(chatId, proxiedStatus, bot);
                break;
            default:
                // Handle wildcard callbacks
                if (data.startsWith('pointing_wildcard')) {
                    await handleWildcardCallback(chatId, data, user, bot);
                }
                // Handle delete domain callbacks
                else if (data.startsWith('pointing_delete_')) {
                    const recordId = data.replace('pointing_delete_', '');
                    await pointingDomain.handleConfirmDeleteDomain(chatId, recordId, bot);
                }
                // Handle pagination
                else if (data.startsWith('pointing_list_page_')) {
                    const pageNum = parseInt(data.replace('pointing_list_page_', ''));
                    await pointingDomain.handleListDomains(chatId, bot, pageNum);
                }
                else {
                    await bot.sendMessage(chatId, '❌ Aksi pointing tidak dikenali').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
        }
    } catch (error) {
        console.error('❌ Pointing Callback Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memproses pointing domain').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk melihat worker script - FUNGSI BARU
async function handleWildcardScriptView(chatId, bot) {
    try {
        // Gunakan state dari pointing_domain.js
        const pointingState = pointingDomain.getState(chatId);
        if (!pointingState || !pointingState.zoneName) {
            await bot.sendMessage(chatId, '❌ Tidak ada data domain yang aktif. Silakan setup Cloudflare terlebih dahulu.');
            return;
        }

        const workerScript = pointingDomain.generateWorkerScript(pointingState.zoneName, pointingState.wildcardData?.ipAddress || 'YOUR_IP_HERE');
        
        await bot.sendMessage(chatId, `<b>📋 Worker Script untuk ${pointingState.zoneName}</b>\n\n<pre><code>${workerScript}</code></pre>\n\nSalin script di atas dan deploy di Cloudflare Workers.`, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🚀 Setup Wildcard', callback_data: 'pointing_wildcard_setup' }],
                    [{ text: '🔙 Kembali', callback_data: 'pointing_domain' }]
                ]
            }
        });

    } catch (error) {
        console.error('❌ Wildcard Script View Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal mengambil worker script');
    }
}

// Cek apakah user memiliki akses sementara untuk add IP
function hasTemporaryAccess(userId) {
    const usersData = loadAllowedUsers();
    const userAccess = usersData.temporaryAccess[userId];
    
    if (userAccess) {
        // Cek apakah akses masih valid (1 jam)
        const now = Date.now();
        const accessTime = userAccess.timestamp;
        const oneHour = 60 * 60 * 1000; // 1 jam dalam milliseconds
        
        if (now - accessTime < oneHour) {
            return true;
        } else {
            // Hapus akses yang sudah expired
            delete usersData.temporaryAccess[userId];
            saveAllowedUsers(usersData);
            return false;
        }
    }
    return false;
}

// Beri akses sementara untuk user
function grantTemporaryAccess(userId) {
    const usersData = loadAllowedUsers();
    usersData.temporaryAccess[userId] = {
        timestamp: Date.now(),
        grantedBy: 'system'
    };
    return saveAllowedUsers(usersData);
}

// Hapus akses sementara setelah add IP
function revokeTemporaryAccess(userId) {
    const usersData = loadAllowedUsers();
    if (usersData.temporaryAccess[userId]) {
        delete usersData.temporaryAccess[userId];
        return saveAllowedUsers(usersData);
    }
    return true;
}

// Helper function untuk execute command
function runCommand(command) {
    return new Promise((resolve, reject) => {
        exec(command, { timeout: 30000 }, (error, stdout, stderr) => {
            if (error) {
                reject(error);
                return;
            }
            resolve(stdout || stderr);
        });
    });
}

// Setup Git config
async function setupGit() {
    try {
        await runCommand(`git config --global user.email "${GITHUB_EMAIL}"`);
        await runCommand(`git config --global user.name "${GITHUB_USER}"`);
        console.log('✅ Git config setup completed');
    } catch (error) {
        console.error('❌ Git setup error:', error);
    }
}

// Clone repository dari GitHub
async function cloneRepo() {
    try {
        if (fs.existsSync(GIT_DIR)) {
            // Update existing repo instead of re-cloning
            try {
                await runCommand(`cd ${GIT_DIR} && git pull origin main`);
                console.log('✅ Repository updated successfully');
                return true;
            } catch (pullError) {
                console.log('🔄 Git pull failed, doing fresh clone...');
                fs.rmSync(GIT_DIR, { recursive: true });
            }
        }
        
        const repoUrl = `https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${GITHUB_REPO}.git`;
        // Gunakan shallow clone untuk lebih cepat
        await runCommand(`git clone --depth 1 ${repoUrl} ${GIT_DIR}`);
        console.log('✅ Repository cloned successfully (shallow)');
        return true;
    } catch (error) {
        console.error('❌ Clone error:', error);
        return false;
    }
}

// Push changes ke GitHub
async function pushToGitHub(message) {
    try {
        await runCommand(`cd ${GIT_DIR} && git add .`);
        await runCommand(`cd ${GIT_DIR} && git commit -m "${message}"`);
        await runCommand(`cd ${GIT_DIR} && git push origin main`);
        console.log('✅ Changes pushed to GitHub');
        return true;
    } catch (error) {
        console.error('❌ Push error:', error);
        return false;
    }
}

// Check GitHub connection
async function checkGitHubConnection() {
    try {
        const result = await runCommand(`curl -s -H "Authorization: token ${GITHUB_TOKEN}" "https://api.github.com/user"`);
        const userInfo = JSON.parse(result);
        
        if (userInfo && userInfo.login) {
            return { success: true, message: `✅ Koneksi GitHub OK\n<b>User:</b> ${userInfo.login}\n<b>Token:</b> ${GITHUB_TOKEN.substring(0, 8)}...` };
        } else {
            return { success: false, message: '❌ Gagal terhubung ke GitHub' };
        }
    } catch (error) {
        return { success: false, message: '❌ Gagal terhubung ke GitHub' };
    }
}

// Load data dari GitHub
// 1. OPTIMASI: Load data dari GitHub dengan cache
async function loadDataFromGitHub() {
    try {
        // Cek apakah data sudah ada di local dan masih fresh (5 menit)
        const cacheTime = 5 * 60 * 1000; // 5 menit
        const now = Date.now();
        
        if (fs.existsSync(IPX_FILE) && fs.existsSync(IP_FILE)) {
            const stats = fs.statSync(IPX_FILE);
            const fileAge = now - stats.mtime.getTime();
            
            if (fileAge < cacheTime) {
                console.log('📦 Menggunakan data lokal (cache)');
                return true; // Gunakan data lokal tanpa sync
            }
        }
        
        console.log('🔄 Sync data dari GitHub...');
        const cloned = await cloneRepo();
        if (!cloned) return false;

        // Copy files dari repo ke local
        const repoIpx = path.join(GIT_DIR, 'ipx');
        const repoIp = path.join(GIT_DIR, 'ip');
        
        if (fs.existsSync(repoIpx)) {
            fs.copyFileSync(repoIpx, IPX_FILE);
        }
        if (fs.existsSync(repoIp)) {
            fs.copyFileSync(repoIp, IP_FILE);
        }
        
        return true;
    } catch (error) {
        console.error('❌ Load data error:', error);
        // Fallback ke data lokal jika ada
        if (fs.existsSync(IPX_FILE) && fs.existsSync(IP_FILE)) {
            console.log('🔄 Fallback ke data lokal');
            return true;
        }
        return false;
    }
}

// Save data ke GitHub
async function saveDataToGitHub(commitMessage) {
    try {
        const cloned = await cloneRepo();
        if (!cloned) return false;

        // Copy files dari local ke repo
        if (fs.existsSync(IPX_FILE)) {
            fs.copyFileSync(IPX_FILE, path.join(GIT_DIR, 'ipx'));
        }
        if (fs.existsSync(IP_FILE)) {
            fs.copyFileSync(IP_FILE, path.join(GIT_DIR, 'ip'));
        }

        return await pushToGitHub(commitMessage);
    } catch (error) {
        console.error('❌ Save data error:', error);
        return false;
    }
}

// Baca data IP dari file
function readIPData() {
    const ips = [];
    
    try {
        if (fs.existsSync(IPX_FILE)) {
            const content = fs.readFileSync(IPX_FILE, 'utf8');
            const lines = content.split('\n');
            
            for (const line of lines) {
                if (line.startsWith('###')) {
                    const parts = line.split(' ').filter(part => part.trim() !== '');
                    if (parts.length >= 4) {
                        ips.push({
                            username: parts[1],
                            expired: parts[2],
                            ip: parts[3],
                            status: parts[4] || ''
                        });
                    }
                }
                // Batasi parsing untuk performa
                if (ips.length >= 1000) break; // Maksimal 1000 IP
            }
        }
    } catch (error) {
        console.error('Read IP Data Error:', error);
    }
    
    return ips;
}

// Tambah IP baru
function addIP(username, ip, days) {
    const expired = new Date();
    expired.setDate(expired.getDate() + parseInt(days));
    const expiredStr = expired.toISOString().split('T')[0];
    
    // Tambah ke ipx file
    if (!fs.existsSync(IPX_FILE)) {
        fs.writeFileSync(IPX_FILE, '# ADMIN\n');
    }
    
    let ipxContent = fs.readFileSync(IPX_FILE, 'utf8');
    ipxContent += `### ${username} ${expiredStr} ${ip} @VIP\n`;
    fs.writeFileSync(IPX_FILE, ipxContent);
    
    // Tambah ke ip file
    if (!fs.existsSync(IP_FILE)) {
        fs.writeFileSync(IP_FILE, '# SSHWS\n');
    }
    
    let ipContent = fs.readFileSync(IP_FILE, 'utf8');
    ipContent += `### ${username} ${expiredStr} ${ip} ON SSHWS @VIP\n`;
    fs.writeFileSync(IP_FILE, ipContent);
    
    return expiredStr;
}

// Hapus IP
function deleteIP(ip) {
    let deleted = false;
    
    // Hapus dari ipx file
    if (fs.existsSync(IPX_FILE)) {
        let ipxContent = fs.readFileSync(IPX_FILE, 'utf8');
        const lines = ipxContent.split('\n');
        const newLines = lines.filter(line => !line.includes(ip));
        
        if (newLines.length !== lines.length) {
            fs.writeFileSync(IPX_FILE, newLines.join('\n'));
            deleted = true;
        }
    }
    
    // Hapus dari ip file
    if (fs.existsSync(IP_FILE)) {
        let ipContent = fs.readFileSync(IP_FILE, 'utf8');
        const lines = ipContent.split('\n');
        const newLines = lines.filter(line => !line.includes(ip));
        
        if (newLines.length !== lines.length) {
            fs.writeFileSync(IP_FILE, newLines.join('\n'));
            deleted = true;
        }
    }
    
    return deleted;
}

// Perpanjang IP
function renewIP(ip, additionalDays) {
    let renewed = false;
    
    // Update di ipx file
    if (fs.existsSync(IPX_FILE)) {
        let ipxContent = fs.readFileSync(IPX_FILE, 'utf8');
        const lines = ipxContent.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes(ip)) {
                const parts = lines[i].split(' ').filter(part => part.trim() !== '');
                if (parts.length >= 4) {
                    const oldExpired = parts[2];
                    const newExpired = new Date(oldExpired);
                    newExpired.setDate(newExpired.getDate() + parseInt(additionalDays));
                    const newExpiredStr = newExpired.toISOString().split('T')[0];
                    
                    lines[i] = lines[i].replace(oldExpired, newExpiredStr);
                    renewed = true;
                }
            }
        }
        
        if (renewed) {
            fs.writeFileSync(IPX_FILE, lines.join('\n'));
        }
    }
    
    // Update di ip file
    if (fs.existsSync(IP_FILE)) {
        let ipContent = fs.readFileSync(IP_FILE, 'utf8');
        const lines = ipContent.split('\n');
        
        for (let i = 0; i < lines.length; i++) {
            if (lines[i].includes(ip)) {
                const parts = lines[i].split(' ').filter(part => part.trim() !== '');
                if (parts.length >= 4) {
                    const oldExpired = parts[2];
                    const newExpired = new Date(oldExpired);
                    newExpired.setDate(newExpired.getDate() + parseInt(additionalDays));
                    const newExpiredStr = newExpired.toISOString().split('T')[0];
                    
                    lines[i] = lines[i].replace(oldExpired, newExpiredStr);
                    renewed = true;
                }
            }
        }
        
        if (renewed) {
            fs.writeFileSync(IP_FILE, lines.join('\n'));
        }
    }
    
    return renewed;
}

// Format data IP untuk ditampilkan
function formatIPList() {
    try {
        const ips = readIPData();
        const now = new Date();
        
        if (ips.length === 0) {
            return '📭 Tidak ada data IP VPS terdaftar';
        }
        
        let result = '<b>📋 DAFTAR IP VPS</b>\n\n';
        result += '<pre>';
        result += '┌─────────────────────────────────────────┐\n';
        result += '│ USERNAME            EXPIRED        IP VPS     \n';
        result += '├─────────────────────────────────────────┘\n';
        
        // Batasi jumlah IP yang ditampilkan untuk performa
        const displayIps = ips.slice(0, 50); // Maksimal 50 IP
        
        displayIps.forEach(ipData => {
            const expired = new Date(ipData.expired);
            const isExpired = expired < now;
            
            const username = (ipData.username || '').substring(0, 15).padEnd(15);
            const expiredStr = (ipData.expired || '').substring(0, 10).padEnd(12);
            const ip = (ipData.ip || '').padEnd(15);
            
            if (isExpired) {
                result += `│ ❌ ${username} ${expiredStr} ${ip} \n`;
            } else {
                result += `│ ✅ ${username} ${expiredStr} ${ip} \n`;
            }
        });
        
        // Tambahkan info jika ada IP lebih dari 50
        if (ips.length > 50) {
            result += `│ ... ${ips.length - 50} IP lainnya ...    \n`;
        }
        
        result += '└─────────────────────────────────────────┘\n';
        result += '</pre>';
        
        // Tambahkan info total
        const activeIPs = ips.filter(ip => new Date(ip.expired) > now).length;
        const expiredIPs = ips.length - activeIPs;
        
        result += `\n📊 <b>Total:</b> ${ips.length} IP | ✅ <b>Aktif:</b> ${activeIPs} | ❌ <b>Expired:</b> ${expiredIPs}`;
        
        return result;
    } catch (error) {
        console.error('Format IP List Error:', error);
        return '❌ Error memformat data IP';
    }
}

// ===============================
// FUNGSI BARU: TAMPILAN HARGA DENGAN BUTTON
// ===============================

// Fungsi untuk menampilkan menu harga dengan button
function showPriceMenu(chatId, user, messageId = null) {
    // Hapus menu utama jika messageId valid
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const priceText = `
<b>💳 DAFTAR HARGA AUTOSCRIPT</b>

🌟 <b>PAKET REGULER:</b>
• 1 IP → Rp 15.000 / Bulan
• 2 IP → Rp 25.000 / Bulan  
• 3 IP → Rp 35.000 / Bulan

🔥 <b>PAKET SPESIAL:</b>
• 📅 LIFETIME → Rp 200.000 (Bebas Sewa Selamanya!)
• 🔓 OPENSOURCE → Rp 300.000 (Tanpa Bot Seller)
• 🚀 FULL OPENSOURCE → Rp 450.000 (Include Bot Seller)

💼 <b>BOT SELLER ONLY:</b>
• MENYEWAKAN JUGA BOT SELLER ONLY, PM ADMIN

🗣️ Kok mahal amat?
👤 Maaf ya bukan script hasil nyomot/nyolong

💬 <b>Info & Pemesanan:</b>
Silakan hubungi admin untuk pemesanan dan informasi lebih lanjut.

<a href="https://t.me/pxstorech/21">💫TAMPILAN SCRIPT KLIK DISINI</a>
    `;

    const options = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💰 1 IP /Bulan', callback_data: 'price_1ip' },
                    { text: '💰 2 IP /Bulan', callback_data: 'price_2ip' }
                ],
                [
                    { text: '💰 3 IP /Bulan', callback_data: 'price_3ip' },
                    { text: '🚀 LIFETIME', callback_data: 'price_lifetime' }
                ],
                [
                    { text: '🔓 OPENSOURCE', callback_data: 'price_opensource' },
                    { text: '🎯 FULL PACKAGE', callback_data: 'price_full_opensource' }
                ],
                [
                    { text: '💼 BOT SELLER', callback_data: 'price_bot_seller' },
                    { text: '👨‍💻 HUBUNGI ADMIN', url: 'https://t.me/PeyxDev' }
                ],
                [
                    { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        },
        parse_mode: 'HTML'
    };

    bot.sendMessage(chatId, priceText, options).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// Handler untuk callback price
async function handlePriceCallback(chatId, data, user) {
    let priceDetail = '';
    
    switch (data) {
        case 'price_1ip':
            priceDetail = `
<b>💰 PAKET 1 IP</b>

💵 <b>Harga:</b> Rp 15.000 / Bulan
🌐 <b>Fitur:</b> 1 IP VPS
✅ <b>Akses:</b> Fitur bot pribadi
📅 <b>Masa Aktif:</b> 30 hari

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_2ip':
            priceDetail = `
<b>💰 PAKET 2 IP</b>

💵 <b>Harga:</b> Rp 25.000 / Bulan  
🌐 <b>Fitur:</b> 2 IP VPS
✅ <b>Akses:</b> Fitur bot pribadi
📅 <b>Masa Aktif:</b> 30 hari
🎁 <b>Bonus:</b> Lebih hemat dari paket 1 IP

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_3ip':
            priceDetail = `
<b>💰 PAKET 3 IP</b>

💵 <b>Harga:</b> Rp 35.000 / Bulan
🌐 <b>Fitur:</b> 3 IP VPS  
✅ <b>Akses:</b> Fitur bot pribadi
📅 <b>Masa Aktif:</b> 30 hari
🎁 <b>Bonus:</b> Paling hemat untuk kebutuhan multiple IP

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_lifetime':
            priceDetail = `
<b>🚀 PAKET LIFETIME</b>

💵 <b>Harga:</b> Rp 200.000 (Sekali Bayar)
🌐 <b>Fitur:</b> Bebas tambah IP (Fair Use)
✅ <b>Akses:</b> Semua fitur bot
📅 <b>Masa Aktif:</b> SELAMANYA
💎 <b>Keuntungan:</b> Tidak perlu renew bulanan

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_opensource':
            priceDetail = `
<b>🔓 PAKET OPENSOURCE</b>

💵 <b>Harga:</b> Rp 300.000 (Sekali Bayar)
📦 <b>Fitur:</b> Script autoscript lengkap
🤖 <b>Tanpa:</b> Bot seller
🔧 <b>Kustomisasi:</b> Bisa modifikasi script
📚 <b>Dokumentasi:</b> Lengkap

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_full_opensource':
            priceDetail = `
<b>🎯 PAKET FULL OPENSOURCE</b>

💵 <b>Harga:</b> Rp 450.000 (Sekali Bayar)
📦 <b>Fitur:</b> Script autoscript lengkap
🤖 <b>Include:</b> Bot seller lengkap
🔧 <b>Kustomisasi:</b> Bebas modifikasi
🚀 <b>Support:</b> Bantuan

💬 <b>Pemesanan:</b> Hubungi admin @PeyxDev
            `;
            break;
            
        case 'price_bot_seller':
            priceDetail = `
<b>💼 BOT SELLER ONLY</b>

🤖 <b>Fitur:</b> Bot management VPS lengkap
💰 <b>Harga:</b> Menyesuaikan kebutuhan
⚡ <b>Fitur:</b> Customizable sesuai kebutuhan
🔧 <b>Support:</b> Sales 24/7, Setup dan maintenance

💬 <b>Info Detail:</b> Langsung chat admin @PeyxDev
            `;
            break;
    }
    
    const options = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💬 Pesan Sekarang', url: 'https://t.me/PeyxDev' },
                    { text: '📋 Lihat Semua Harga', callback_data: 'show_prices' }
                ],
                [
                    { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        },
        parse_mode: 'HTML'
    };

    await bot.sendMessage(chatId, priceDetail, options).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// Generate script install berdasarkan OS
function generateInstallScript(osType, ipAddress, username) {
    let script = '';
    
    if (osType === 'ubuntu') {
        script = UBUNTU_INSTALL_SCRIPT;
    } else if (osType === 'debian') {
        script = DEBIAN_INSTALL_SCRIPT;
    }
    
    const installMessage = `
🔄 <b>SCRIPT INSTALL UNTUK VPS</b>

🌐 <b>IP VPS:</b> <code>${ipAddress}</code>
👤 <b>Username:</b> <code>${username}</code>
📦 <b>OS:</b> ${osType === 'ubuntu' ? 'Ubuntu' : 'Debian'}

📝 <b>Salin script berikut dan jalankan di VPS:</b>

<pre><code>${script}</code></pre>

<b>Cara penggunaan:</b>
1. SSH ke VPS: <code>ssh root@${ipAddress}</code>
2. Paste dan jalankan script di atas
3. Tunggu hingga proses install selesai
4. VPS siap digunakan!

⚠️ <b>Pastikan VPS sudah terinstall OS Ubuntu/Debian fresh</b>
    `;
    
    return installMessage;
}

// Format nama user
function formatUserName(user) {
    if (user.first_name && user.last_name) {
        return `${user.first_name} ${user.last_name}`;
    } else if (user.first_name) {
        return user.first_name;
    } else if (user.username) {
        return `@${user.username}`;
    } else {
        return 'User';
    }
}

// Header dengan info user
// Header dengan info user - FORMAT WAKTU DIUBAH MENJADI JAM SAJA
function getUserInfoHeader(user) {
    const userName = formatUserName(user);
    const userId = user.id;
    const currentTime = new Date().toLocaleString('id-ID', {
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });

    const userStatus = isAdmin(userId) ? '👑 ADMIN' : '👤 USER';

    return `
<b>Selamat Datang di bot TOOLS PX STORE</b>

👋 Halo, <b>${userName}</b>!
🆔 ID Telegram: <code>${userId}</code>
👤 Status: <b>${userStatus}</b>
🕐 Jam: ${currentTime}

<b>Silahkan pilih menu dibawah ini 👇</b>
    `;
}

// ===============================
// FUNGSI BARU: CEK BUG TUNNELING REAL UNTUK TUNNELING
// ===============================

// Fungsi untuk cek status bug tunneling dengan port scanning yang lebih luas
async function checkBugTunneling(target) {
    try {
        let results = [];
        let detectedServices = [];
        let openPorts = [];
        
        // Cek HTTP
        try {
            const httpResult = await runCommand(`timeout 10 curl -s -o /dev/null -w "%{http_code}" http://${target} 2>/dev/null || echo "FAILED"`);
            const httpCode = httpResult.trim();
            if (httpCode === '200' || httpCode === '301' || httpCode === '302') {
                results.push(`🌐 HTTP: ✅ ${httpCode}`);
                detectedServices.push('HTTP Web Server');
            } else if (httpCode === 'FAILED') {
                results.push(`🌐 HTTP: ❌ Gagal`);
            } else {
                results.push(`🌐 HTTP: ⚠️ ${httpCode}`);
            }
        } catch (error) {
            results.push(`🌐 HTTP: ❌ Error`);
        }
        
        // Cek HTTPS
        try {
            const httpsResult = await runCommand(`timeout 10 curl -s -o /dev/null -w "%{http_code}" https://${target} 2>/dev/null || echo "FAILED"`);
            const httpsCode = httpsResult.trim();
            if (httpsCode === '200' || httpsCode === '301' || httpsCode === '302') {
                results.push(`🔐 HTTPS: ✅ ${httpsCode}`);
                detectedServices.push('HTTPS Web Server');
            } else if (httpsCode === 'FAILED') {
                results.push(`🔐 HTTPS: ❌ Gagal`);
            } else {
                results.push(`🔐 HTTPS: ⚠️ ${httpsCode}`);
            }
        } catch (error) {
            results.push(`🔐 HTTPS: ❌ Error`);
        }
        
        // Cek port-port umum untuk SSH dan tunneling
        const commonPorts = [
            // SSH Ports
            {port: 22, service: 'SSH Default'},
            {port: 80, service: 'SSH Over HTTP'},
            {port: 443, service: 'SSH Over HTTPS'},
            {port: 2222, service: 'SSH Alternative'},
            {port: 222, service: 'SSH Alternative 2'},
            // Web Ports
            {port: 8080, service: 'HTTP Proxy'},
            {port: 8443, service: 'HTTPS Alternative'},
            {port: 2080, service: 'cPanel/Web'},
            {port: 2083, service: 'cPanel SSL'},
            {port: 2087, service: 'WHM SSL'},
            // VPN/Proxy Ports
            {port: 1080, service: 'SOCKS Proxy'},
            {port: 3128, service: 'Squid Proxy'},
            {port: 8888, service: 'HTTP Proxy 2'},
            {port: 9090, service: 'Web Proxy'},
            // Custom Ports untuk tunneling
            {port: 1194, service: 'OpenVPN'},
            {port: 1723, service: 'PPTP'},
            {port: 3389, service: 'RDP'},
            {port: 5900, service: 'VNC'}
        ];
        
        // Scan port secara paralel dengan timeout pendek
        const portPromises = commonPorts.map(async ({port, service}) => {
            try {
                const portResult = await runCommand(`timeout 3 nc -z -w 2 ${target} ${port} 2>/dev/null && echo "OPEN" || echo "CLOSED"`);
                if (portResult.includes('OPEN')) {
                    openPorts.push({port, service, status: 'OPEN'});
                    return `🔑 ${service}: ✅ Port ${port} Terbuka`;
                }
                return null;
            } catch (error) {
                return null;
            }
        });
        
        const portResults = await Promise.all(portPromises);
        const validPortResults = portResults.filter(result => result !== null);
        
        results = results.concat(validPortResults);
        
        // Analisis hasil untuk deteksi mode tunneling
        const sshPorts = openPorts.filter(p => 
            p.service.includes('SSH') || 
            [22, 80, 443, 2222, 222].includes(p.port)
        );
        
        const webPorts = openPorts.filter(p => 
            p.service.includes('HTTP') || 
            p.service.includes('HTTPS') ||
            [80, 443, 8080, 8443, 2080, 2083, 2087].includes(p.port)
        );
        
        const proxyPorts = openPorts.filter(p => 
            p.service.includes('Proxy') ||
            [1080, 3128, 8888, 9090].includes(p.port)
        );
        
        // Deteksi mode tunneling berdasarkan port yang terbuka
        let tunnelingMode = '';
        let tunnelingDescription = '';
        
        if (sshPorts.length > 0 && webPorts.length > 0) {
            tunnelingMode = 'SSH + Web Server';
            tunnelingDescription = 'Bisa untuk SSH Tunneling, HTTP/HTTPS Proxy';
            
            // Deteksi mode khusus
            const hasPort80 = sshPorts.some(p => p.port === 80);
            const hasPort443 = sshPorts.some(p => p.port === 443);
            
            if (hasPort80) {
                tunnelingMode += ' (SSH Over HTTP)';
                tunnelingDescription += ', SSH Over Port 80';
            }
            if (hasPort443) {
                tunnelingMode += ' (SSH Over HTTPS)';
                tunnelingDescription += ', SSH Over Port 443';
            }
            
        } else if (sshPorts.length > 0) {
            tunnelingMode = 'SSH Only';
            tunnelingDescription = 'Bisa untuk SSH Tunneling biasa';
            
        } else if (webPorts.length > 0) {
            tunnelingMode = 'Web Server Only';
            tunnelingDescription = 'Bisa untuk HTTP/HTTPS Proxy';
            
        } else if (proxyPorts.length > 0) {
            tunnelingMode = 'Proxy Server';
            tunnelingDescription = 'Bisa untuk SOCKS/HTTP Proxy';
            
        } else if (openPorts.length > 0) {
            tunnelingMode = 'Custom Ports';
            tunnelingDescription = 'Port terbuka tapi tidak dikenali';
            
        } else {
            tunnelingMode = 'Tidak Terdeteksi';
            tunnelingDescription = 'Tidak ada service yang terdeteksi';
        }
        
        // Cek ping (jika IP)
        if (target.match(/^(\d{1,3}\.){3}\d{1,3}$/)) {
            try {
                const pingResult = await runCommand(`timeout 10 ping -c 2 ${target} 2>/dev/null | grep "packet loss" | awk '{print $6}' || echo "100%"`);
                const packetLoss = pingResult.trim();
                if (packetLoss === '0%') {
                    results.push(`📡 Ping: ✅ Berhasil (0% loss)`);
                } else {
                    results.push(`📡 Ping: ⚠️ ${packetLoss} loss`);
                }
            } catch (error) {
                results.push(`📡 Ping: ❌ Gagal`);
            }
        }
        
        return {
            results: results.join('\n'),
            services: detectedServices,
            openPorts: openPorts,
            tunnelingMode: tunnelingMode,
            tunnelingDescription: tunnelingDescription
        };
    } catch (error) {
        return {
            results: '❌ Error saat mengecek bug tunneling',
            services: [],
            openPorts: [],
            tunnelingMode: 'Error',
            tunnelingDescription: 'Gagal melakukan pengecekan'
        };
    }
}

// Handler untuk Check Bug Tunneling
async function handleCheckBug(chatId, user, messageId = null) {
    // Hapus menu utama jika messageId valid
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const msg = await bot.sendMessage(chatId, 
        '<b>🐛 CEK BUG TUNNELING REAL</b>\n\n' +
        'Masukkan target yang ingin dicek:\n' +
        '• IP Address (contoh: 192.168.1.1)\n' +
        '• Domain (contoh: example.com)\n\n' +
        '<i>Fitur ini mengecek service dan port yang terbuka untuk keperluan tunneling</i>',
        {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        }
    );

    addTempMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const target = replyMsg.text.trim();
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            // Validasi input
            if (!target) {
                await bot.sendMessage(chatId, '❌ Target tidak boleh kosong!');
                return;
            }
            
            // Validasi format
            const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
            
            if (!domainRegex.test(target) && !ipRegex.test(target)) {
                await bot.sendMessage(chatId, '❌ Format target tidak valid! Gunakan IP atau domain yang benar.');
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, 
                '🔍 <b>Mengecek bug tunneling real...</b>\n\n' +
                '⏳ Scanning port dan service...\n' +
                '📡 Mohon tunggu ±30 detik',
                {
                    parse_mode: 'HTML'
                }
            );
            
            addTempMessage(chatId, loadingMsg.message_id);
            
            try {
                const { results, services, openPorts, tunnelingMode, tunnelingDescription } = await checkBugTunneling(target);
                
                // Format hasil
                let portInfo = '';
                if (openPorts.length > 0) {
                    portInfo = `\n\n<b>🔓 PORT TERBUKA:</b>\n`;
                    openPorts.forEach(({port, service}) => {
                        portInfo += `✅ ${service} - Port ${port}\n`;
                    });
                } else {
                    portInfo = `\n\n<b>🔒 TIDAK ADA PORT TERBUKA</b>\n`;
                }
                
                let serviceInfo = '';
                if (services.length > 0) {
                    serviceInfo = `\n\n<b>🌐 SERVICE AKTIF:</b>\n`;
                    services.forEach(service => {
                        serviceInfo += `✅ ${service}\n`;
                    });
                }
                
                const resultText = `
<b>🔍 HASIL CEK BUG TUNNELING REAL</b>

🎯 <b>Target:</b> <code>${target}</code>
⏰ <b>Waktu Check:</b> ${new Date().toLocaleString('id-ID')}

📊 <b>STATUS:</b>
${results}
${portInfo}
${serviceInfo}

<b>🚀 MODE TUNNELING:</b>
🔧 <b>${tunnelingMode}</b>
💡 <b>Keterangan:</b> ${tunnelingDescription}

<b>💡 REKOMENDASI:</b>
${getTunnelingRecommendation(tunnelingMode, openPorts)}

<b>📝 STATUS SYSTEM:</b>
✅ = Aktif dan berfungsi
⚠️ = Ada masalah/respons tidak normal  
❌ = Gagal/tidak aktif
                `;
                
                await bot.editMessageText(resultText, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Cek Lagi', callback_data: 'check_bug' }],
                            [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                });
                
            } catch (error) {
                console.error('❌ Check Bug Error:', error);
                await bot.editMessageText('❌ Gagal mengecek bug tunneling. Target mungkin tidak dapat diakses.', {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id
                });
            }
        }
    };

    // Tambahkan listener untuk message
    bot.on('message', replyListener);
    
    // Set timeout untuk menghapus listener setelah 2 menit
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi untuk memberikan rekomendasi tunneling
function getTunnelingRecommendation(mode, openPorts) {
    const sshPorts = openPorts.filter(p => 
        p.service.includes('SSH') || 
        [22, 80, 443, 2222, 222].includes(p.port)
    );
    
    const webPorts = openPorts.filter(p => 
        p.service.includes('HTTP') || 
        p.service.includes('HTTPS')
    );
    
    let recommendations = [];
    
    if (sshPorts.length > 0) {
        recommendations.push('• SSH Tunneling untuk port forwarding');
        recommendations.push('• Dynamic SOCKS proxy via SSH');
        
        // Rekomendasi khusus berdasarkan port SSH
        sshPorts.forEach(({port, service}) => {
            if (port === 80) {
                recommendations.push('• SSH Over HTTP (port 80) - bypass firewall');
            }
            if (port === 443) {
                recommendations.push('• SSH Over HTTPS (port 443) - encrypted tunneling');
            }
        });
    }
    
    if (webPorts.length > 0) {
        recommendations.push('• HTTP/HTTPS Proxy');
        recommendations.push('• WebSocket tunneling');
    }
    
    if (openPorts.some(p => [1080, 3128].includes(p.port))) {
        recommendations.push('• SOCKS/HTTP Proxy langsung');
    }
    
    if (recommendations.length === 0) {
        recommendations.push('• Tidak ada rekomendasi tunneling');
    }
    
    return recommendations.join('\n');
}

// ===============================
// FUNGSI BARU: VERIFIKASI PASSWORD UNTUK LIST IP
// ===============================

// Handler untuk List IP dengan verifikasi password
async function handleListIP(chatId, user) {
    console.log(`🔐 Meminta password untuk list IP, chatId: ${chatId}, user: ${user.id}`);
    
    const msg = await bot.sendMessage(chatId, '<b>🔐 Verifikasi Password</b>\n\nMasukkan password untuk melihat daftar IP VPS:', {
        parse_mode: 'HTML',
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const password = replyMsg.text;
            console.log(`🔑 Password diterima: ${password}`);
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            if (password === ADMIN_PASSWORD) {
                console.log('✅ Password benar, menampilkan list IP...');
                
                // Konfirmasi password benar dengan loading cepat
                const successMsg = await bot.sendMessage(chatId, '✅ Password benar! Mengambil data IP...');
                addTempMessage(chatId, successMsg.message_id);
                
                // Hapus pesan konfirmasi setelah 1 detik
                setTimeout(async () => {
                    try {
                        await bot.deleteMessage(chatId, successMsg.message_id);
                    } catch (error) {
                        // Ignore delete errors
                    }
                }, 1000);
                
                // Panggil fungsi list IP asli
                await showIPList(chatId);
            } else {
                console.log('❌ Password salah');
                await bot.sendMessage(chatId, '❌ Password salah! Akses ditolak.', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };

    // Tambahkan listener untuk message
    bot.on('message', replyListener);
    
    // Set timeout untuk menghapus listener setelah 2 menit
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi asli untuk menampilkan list IP (dipindah dari handleListIP)
async function showIPList(chatId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '📋 Mengambil data IP VPS...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        // Gunakan data lokal dulu untuk tampilan cepat
        let ipList = '';
        if (fs.existsSync(IPX_FILE) && fs.existsSync(IP_FILE)) {
            ipList = formatIPList();
            
            // Tampilkan data lokal secepatnya
            await bot.editMessageText(ipList + '\n\n🔄 <i>Menyinkronisasi dengan GitHub...</i>', {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML'
            });
        }
        
        // Sync data dari GitHub di background (non-blocking)
        setTimeout(async () => {
            try {
                await loadDataFromGitHub();
                const updatedIpList = formatIPList();
                
                // Update dengan data terbaru jika berbeda
                if (updatedIpList !== ipList) {
                    await bot.editMessageText(updatedIpList, {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id,
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🔄 Refresh', callback_data: 'list_ip' }],
                                [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                            ]
                        }
                    });
                }
            } catch (syncError) {
                console.error('Background sync error:', syncError);
                // Tetap pertahankan data lokal jika sync gagal
            }
        }, 100);
        
        // Tampilkan final data setelah sync
        const finalIpList = formatIPList();
        await bot.editMessageText(finalIpList, {
            chat_id: chatId,
            message_id: loadingMsg.message_id,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Refresh', callback_data: 'list_ip' }],
                    [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                ]
            }
        });
        
    } catch (error) {
        console.error('❌ List IP Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal mengambil data IP VPS').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// ===============================
// FUNGSI BARU: EDIT PASSWORD VERIFIKASI
// ===============================

// Handler untuk Edit Password Verifikasi
async function handleEditPassword(chatId) {
    const msg = await bot.sendMessage(chatId, 
        `<b>🔑 Edit Password Verifikasi</b>\n\n` +
        `Password saat ini: <code>${ADMIN_PASSWORD}</code>\n\n` +
        `Masukkan password baru:`,
        {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const newPassword = replyMsg.text;
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            if (newPassword && newPassword.length >= 4) {
                const loadingMsg = await bot.sendMessage(chatId, '⏳ Mengupdate password...');
                saveActionMessage(chatId, loadingMsg.message_id);
                
                try {
                    const success = updateEnvVariable('ADMIN_PASSWORD', newPassword);
                    
                    if (success) {
                        await bot.editMessageText(
                            `<b>✅ Password Berhasil Diupdate!</b>\n\n` +
                            `🔑 <b>Password Baru:</b> <code>${newPassword}</code>\n\n` +
                            `Password verifikasi telah diperbarui. Semua user harus menggunakan password baru ini untuk mengakses fitur yang memerlukan verifikasi.`,
                            {
                                chat_id: chatId,
                                message_id: loadingMsg.message_id,
                                parse_mode: 'HTML',
                                reply_markup: {
                                    inline_keyboard: [
                                        [{ text: '⚙️ Admin Settings', callback_data: 'admin_settings' }],
                                        [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                                    ]
                                }
                            }
                        );
                        
                        console.log(`✅ Password verifikasi diupdate oleh admin ${chatId}`);
                    } else {
                        throw new Error('Gagal mengupdate password di file .env');
                    }
                } catch (error) {
                    console.error('❌ Edit Password Error:', error);
                    await bot.editMessageText('❌ Gagal mengupdate password. Pastikan file .env dapat diakses.', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id
                    });
                }
            } else {
                await bot.sendMessage(chatId, '❌ Password tidak valid! Password harus minimal 4 karakter.', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'edit_password' }],
                            [{ text: '⚙️ Admin Settings', callback_data: 'admin_settings' }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };

    // Tambahkan listener untuk message
    bot.on('message', replyListener);
    
    // Set timeout untuk menghapus listener setelah 2 menit
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// ===============================
// MAIN MENU DENGAN TAMBAHAN CONVERT XRAY
// ===============================

// showMainMenu menerima optional messageIdToDelete
// showMainMenu menerima optional messageIdToDelete
function showMainMenu(chatId, user, messageIdToDelete = null) {
    if (messageIdToDelete) {
        bot.deleteMessage(chatId, messageIdToDelete).catch(() => {});
    }

    const menuText = getUserInfoHeader(user);

    // UPDATE: Gabung beberapa fitur ke dalam menu TOOLS
    const options = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🌐 IZIN IP', callback_data: 'izin_ip_menu' }],
                [{ text: '🛠️ TOOLS', callback_data: 'tools_menu' }, { text: '💰 HARGA SC', callback_data: 'show_prices' }],
                [{ text: '📦 CONFIG', callback_data: 'upload_config_menu' }, { text: '📱 SIDOMPUL', web_app: { url: 'https://sidompul.violetvpn.biz.id' } }],
                [{ text: '🆘 HELP', callback_data: 'help' }, { text: '🔄 REFRESH BOT', callback_data: 'refresh_bot' }],
                isAdmin(user.id.toString()) ? [{ text: '⚙️ ADMIN PANEL', callback_data: 'admin_settings' }] : []
            ].filter(row => row.length > 0),
        },
        parse_mode: 'HTML'
    };

    const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

    bot.sendAnimation(chatId, gifUrl, {
        caption: menuText,
        parse_mode: 'HTML',
        reply_markup: options.reply_markup
    }).then(msg => {
        saveMenuMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendAnimation showMainMenu error:', err);
        bot.sendMessage(chatId, menuText, options).then(msg => {
            saveMenuMessage(chatId, msg.message_id);
        }).catch(fallbackErr => {
            console.error('Fallback sendMessage error:', fallbackErr);
        });
    });
}

// Menu Tools - Gabung beberapa fitur
function showToolsMenu(chatId, user, messageId = null) {
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const menuText = `
<b>🛠️ TOOLS COLLECTION</b>

Kumpulan berbagai tools yang tersedia:

• ⚡ Convert Xray - Konversi config Xray/V2Ray/Trojan
• 🐛 Cek Bug - Deteksi service dan port untuk tunneling  
• 🔗 Pointing Domain - Management domain Cloudflare
• 🔒 Bash Encrypt - Enkripsi/dekripsi script bash

Pilih tools yang ingin digunakan:
    `;

    const options = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '⚡ CONVERT XRAY', callback_data: 'convert_xray' },
                    { text: '🐛 CEK BUG', callback_data: 'check_bug' }
                ],
                [
                    { text: '🔗 POINTING', callback_data: 'pointing_domain' },
                    { text: '🔒 BASH ENCRYPT', callback_data: 'bash_encrypt_menu' }
                ],
                [
                    { text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        },
        parse_mode: 'HTML'
    };

    const gifUrl = process.env.MENU_GIF_URL || 'https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExa2Nra2FscDJoZ2t5NTExOGQ5ZWVwZDNtbG0wczNjZmN0bjcxaDFaMyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/fTn01fiFdTd5pL60ln/giphy.gif';

    bot.sendAnimation(chatId, gifUrl, {
        caption: menuText,
        parse_mode: 'HTML',
        reply_markup: options.reply_markup
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendAnimation showToolsMenu error:', err);
        bot.sendMessage(chatId, menuText, options).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        }).catch(fallbackErr => {
            console.error('Fallback sendMessage error:', fallbackErr);
        });
    });
}

function showIzinIpMenu(chatId, messageId) {
    // Hapus menu utama jika messageId valid
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const options = {
    reply_markup: {
        inline_keyboard: [
            [{ text: '📋 LIST IP', callback_data: 'list_ip' }, { text: '🔄 SYNC DATA', callback_data: 'sync_data' }],
            [{ text: '➕ ADD IP', callback_data: 'add_ip' }, { text: '✏️ EDIT IP', callback_data: 'edit_ip' }], // TAMBAHAN EDIT IP
            [{ text: '🔁 RENEW IP', callback_data: 'renew_ip' }, { text: '🗑️ DELETE IP', callback_data: 'delete_ip' }],
            [{ text: '⬅️ Kembali ke Menu Utama', callback_data: 'main_menu' }]
        ]
    },
    parse_mode: 'HTML'
};

    const menuText = `
🌐 <b>IZIN IP MANAGEMENT</b>
━━━━━━━━━━━━━━
Kelola izin IP Anda dengan mudah:
• Lihat daftar IP aktif
• Tambahkan IP baru
• Edit data IP yang sudah ada
• Perpanjang masa aktif IP
• Hapus IP yang tidak digunakan
• Sinkronkan data IP ke server
━━━━━━━━━━━━━━
Pilih aksi yang diinginkan ⬇️
`;

    bot.sendMessage(chatId, menuText, options).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    }).catch(err => {
        console.error('sendMessage showIzinIpMenu error:', err);
    });
}

// Admin Menu - DIPERBARUI: Tambah menu Edit Password
function showAdminMenu(chatId, user, messageId = null) {
    // Hapus menu utama jika messageId valid
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const adminText = `
<b>⚙️ MENU ADMIN</b>

👋 Halo, <b>${formatUserName(user)}</b>!
👑 Status: <b>ADMIN</b>

<b>Fitur Admin:</b>
• Edit Token GitHub
• Edit Password Verifikasi
• Cek Koneksi GitHub
• Kelola User Access
• System Info
• GitHub File Manager

Pilih aksi yang ingin dilakukan:
    `;

    const options = {
    reply_markup: {
        inline_keyboard: [
            [
                { text: '🔑 EDIT GITHUB TOKEN', callback_data: 'edit_github_token' }
            ],
            [
                { text: '🔐 EDIT PASSWORD', callback_data: 'edit_password' }
            ],
            [
                { text: '🌐 CHECK GITHUB', callback_data: 'check_github' }
            ],
            [
                { text: '📊 SYSTEM INFO', callback_data: 'system_info' }
            ],
            [
                { text: '👥 MANAGE USERS', callback_data: 'manage_users' }
            ],
            [
                { text: '📁 GITHUB MANAGER', callback_data: 'github_manager' }
            ],
            [
                { text: '📊 MENU UTAMA', callback_data: 'main_menu' }
            ]
        ]
    },
    parse_mode: 'HTML'
};

bot.sendMessage(chatId, adminText, options).then(msg => {
    saveActionMessage(chatId, msg.message_id);
 });
}

// GitHub Manager Menu - FUNGSI BARU
function showGitHubManagerMenu(chatId) {
    const menuText = `
<b>📁 GITHUB REPOSITORY MANAGER</b>

Fitur untuk mengelola file di repository GitHub:

• 📤 Upload File - Upload file ke repository
• 📋 List Files - Lihat daftar file di repository  
• 🗑️ Delete File - Hapus file dari repository
• 🔄 Sync Repo - Sinkronisasi repository

Pilih aksi yang ingin dilakukan:
    `;

    const options = {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '📤 Upload File', callback_data: 'github_upload' },
                    { text: '📋 List Files', callback_data: 'github_list' }
                ],
                [
                    { text: '🗑️ Delete File', callback_data: 'github_delete' },
                    { text: '🔄 Sync Repo', callback_data: 'github_sync' }
                ],
                [
                    { text: '⬅️ Kembali', callback_data: 'admin_settings' }
                ]
            ]
        },
        parse_mode: 'HTML'
    };

    bot.sendMessage(chatId, menuText, options).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// ===============================
// MODIFIKASI START COMMAND DENGAN VALIDASI KEANGGOTAAN
// ===============================

// Start command dengan validasi keanggotaan
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const user = msg.from;
    
    console.log(`👤 User ${user.id} (${formatUserName(user)}) memulai bot`);
    
    // Hapus pesan aksi sebelumnya
    await cleanupOldMessages(chatId, true);
    
    // Setup git pertama kali
    await setupGit();
    
    // Cek apakah user adalah admin (bypass validasi)
    if (isAdmin(user.id.toString())) {
        console.log(`👑 Admin ${user.id} bypass membership check`);
        showMainMenu(chatId, user);
        return;
    }
    
    // Validasi keanggotaan untuk non-admin
    const membership = await checkMembership(chatId, user.id);
    
    if (membership.success) {
        // User sudah join semua, tampilkan menu utama
        console.log(`✅ User ${user.id} sudah join semua grup/channel`);
        showMainMenu(chatId, user);
    } else {
        // User belum join, tampilkan verifikasi
        console.log(`❌ User ${user.id} belum join semua grup/channel:`, membership.results);
        showMembershipVerification(chatId, user, membership.results);
    }
});

// Handler untuk Edit IP - DIMODIFIKASI: Semua user wajib verifikasi password
async function handleEditIP(chatId, user) {
    await askForPassword(chatId, 'edit_ip', user);
}

// Proses Edit IP - FUNGSI BARU
async function startEditIPProcess(chatId) {
    console.log('✏️ Memulai proses edit IP untuk chatId:', chatId);
    
    try {
        // Load data terbaru dari GitHub
        const loadingMsg = await bot.sendMessage(chatId, '📋 Mengambil data IP...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        await loadDataFromGitHub();
        
        const ips = readIPData();
        
        await bot.deleteMessage(chatId, loadingMsg.message_id);
        
        if (ips.length === 0) {
            await bot.sendMessage(chatId, '❌ Tidak ada IP VPS yang bisa diedit').then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
            return;
        }
        
        // Buat keyboard dengan daftar IP
        const keyboard = [];
        ips.forEach(ipData => {
            const status = new Date(ipData.expired) > new Date() ? '✅' : '❌';
            keyboard.push([{ 
                text: `${status} ${ipData.ip} (${ipData.username})`, 
                callback_data: `edit_ip_select_${ipData.ip}` 
            }]);
        });
        
        keyboard.push([{ text: '❌ Batal', callback_data: 'izin_ip_menu' }]);
        
        await bot.sendMessage(chatId, '✏️ <b>Edit IP VPS</b>\n\nPilih IP yang ingin diedit:', {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    } catch (error) {
        console.error('❌ Start Edit IP Process Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memulai proses edit IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk edit IP selection - FUNGSI BARU
async function handleEditIPSelection(chatId, ipToEdit) {
    try {
        // Load data IP yang akan diedit
        await loadDataFromGitHub();
        const ips = readIPData();
        const ipData = ips.find(ip => ip.ip === ipToEdit);
        
        if (!ipData) {
            await bot.sendMessage(chatId, '❌ Data IP tidak ditemukan').then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
            return;
        }

        // Tampilkan menu edit dengan data saat ini
        const editMenuText = `
✏️ <b>Edit IP VPS</b>

📝 <b>Data Saat Ini:</b>
👤 <b>Username:</b> <code>${ipData.username}</code>
🌐 <b>IP:</b> <code>${ipData.ip}</code>
📅 <b>Expired:</b> <code>${ipData.expired}</code>

<b>Pilih data yang ingin diedit:</b>
        `;

        const options = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '👤 Edit Username', callback_data: `edit_ip_username_${ipToEdit}` },
                        { text: '🌐 Edit IP', callback_data: `edit_ip_address_${ipToEdit}` }
                    ],
                    [
                        { text: '📅 Edit Expired', callback_data: `edit_ip_expired_${ipToEdit}` },
                        { text: '🗑️ Hapus IP', callback_data: `delete_ip_${ipToEdit}` }
                    ],
                    [
                        { text: '🔙 Kembali', callback_data: 'edit_ip' }
                    ]
                ]
            },
            parse_mode: 'HTML'
        };

        await bot.sendMessage(chatId, editMenuText, options).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
        
    } catch (error) {
        console.error('❌ Edit IP Selection Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memproses edit IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk edit username - FUNGSI BARU
async function handleEditUsername(chatId, ipToEdit) {
    const msg = await bot.sendMessage(chatId, 
        `✏️ <b>Edit Username</b>\n\nIP: <code>${ipToEdit}</code>\n\nMasukkan username baru:`,
        {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const newUsername = replyMsg.text;
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            if (newUsername && newUsername.trim() !== '') {
                const loadingMsg = await bot.sendMessage(chatId, '⏳ Mengupdate username...');
                saveActionMessage(chatId, loadingMsg.message_id);
                
                try {
                    const success = updateIPData(ipToEdit, 'username', newUsername);
                    
                    if (success) {
                        await saveDataToGitHub(`Edit username IP ${ipToEdit} menjadi ${newUsername}`);
                        
                        await bot.editMessageText(
                            `✅ <b>Username Berhasil Diupdate!</b>\n\n` +
                            `🌐 <b>IP:</b> <code>${ipToEdit}</code>\n` +
                            `👤 <b>Username Baru:</b> <code>${newUsername}</code>`,
                            {
                                chat_id: chatId,
                                message_id: loadingMsg.message_id,
                                parse_mode: 'HTML',
                                reply_markup: {
                                    inline_keyboard: [
                                        [{ text: '✏️ Edit Lainnya', callback_data: `edit_ip_select_${ipToEdit}` }],
                                        [{ text: '📋 Menu IP', callback_data: 'izin_ip_menu' }]
                                    ]
                                }
                            }
                        );
                    } else {
                        throw new Error('Gagal mengupdate username');
                    }
                } catch (error) {
                    console.error('❌ Edit Username Error:', error);
                    await bot.editMessageText('❌ Gagal mengupdate username', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id
                    });
                }
            } else {
                await bot.sendMessage(chatId, '❌ Username tidak boleh kosong!', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `edit_ip_username_${ipToEdit}` }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };

    bot.on('message', replyListener);
    
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Handler untuk edit IP address - FUNGSI BARU
async function handleEditIPAddress(chatId, oldIP) {
    const msg = await bot.sendMessage(chatId, 
        `✏️ <b>Edit IP Address</b>\n\nIP Lama: <code>${oldIP}</code>\n\nMasukkan IP address baru:`,
        {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const newIP = replyMsg.text.trim();
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            // Validasi format IP
            const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
            if (!ipRegex.test(newIP)) {
                await bot.sendMessage(chatId, '❌ Format IP tidak valid!', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `edit_ip_address_${oldIP}` }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '⏳ Mengupdate IP address...');
            saveActionMessage(chatId, loadingMsg.message_id);
            
            try {
                const success = updateIPData(oldIP, 'ip', newIP);
                
                if (success) {
                    await saveDataToGitHub(`Edit IP ${oldIP} menjadi ${newIP}`);
                    
                    await bot.editMessageText(
                        `✅ <b>IP Address Berhasil Diupdate!</b>\n\n` +
                        `🔄 <b>IP Lama:</b> <code>${oldIP}</code>\n` +
                        `🌐 <b>IP Baru:</b> <code>${newIP}</code>`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '✏️ Edit Lainnya', callback_data: `edit_ip_select_${newIP}` }],
                                    [{ text: '📋 Menu IP', callback_data: 'izin_ip_menu' }]
                                ]
                            }
                        }
                    );
                } else {
                    throw new Error('Gagal mengupdate IP address');
                }
            } catch (error) {
                console.error('❌ Edit IP Address Error:', error);
                await bot.editMessageText('❌ Gagal mengupdate IP address', {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id
                });
            }
        }
    };

    bot.on('message', replyListener);
    
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Handler untuk edit expired date - FUNGSI BARU
async function handleEditExpired(chatId, ipToEdit) {
    const msg = await bot.sendMessage(chatId, 
        `✏️ <b>Edit Tanggal Expired</b>\n\nIP: <code>${ipToEdit}</code>\n\nMasukkan tanggal expired baru (format: YYYY-MM-DD):`,
        {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        }
    );

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const newExpired = replyMsg.text.trim();
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            // Validasi format tanggal
            const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!dateRegex.test(newExpired)) {
                await bot.sendMessage(chatId, '❌ Format tanggal tidak valid! Gunakan format: YYYY-MM-DD', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `edit_ip_expired_${ipToEdit}` }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
                return;
            }

            // Validasi apakah tanggal valid
            const expiredDate = new Date(newExpired);
            if (isNaN(expiredDate.getTime())) {
                await bot.sendMessage(chatId, '❌ Tanggal tidak valid!', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `edit_ip_expired_${ipToEdit}` }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
                return;
            }

            const loadingMsg = await bot.sendMessage(chatId, '⏳ Mengupdate tanggal expired...');
            saveActionMessage(chatId, loadingMsg.message_id);
            
            try {
                const success = updateIPData(ipToEdit, 'expired', newExpired);
                
                if (success) {
                    await saveDataToGitHub(`Edit expired IP ${ipToEdit} menjadi ${newExpired}`);
                    
                    await bot.editMessageText(
                        `✅ <b>Tanggal Expired Berhasil Diupdate!</b>\n\n` +
                        `🌐 <b>IP:</b> <code>${ipToEdit}</code>\n` +
                        `📅 <b>Expired Baru:</b> <code>${newExpired}</code>`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '✏️ Edit Lainnya', callback_data: `edit_ip_select_${ipToEdit}` }],
                                    [{ text: '📋 Menu IP', callback_data: 'izin_ip_menu' }]
                                ]
                            }
                        }
                    );
                } else {
                    throw new Error('Gagal mengupdate tanggal expired');
                }
            } catch (error) {
                console.error('❌ Edit Expired Error:', error);
                await bot.editMessageText('❌ Gagal mengupdate tanggal expired', {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id
                });
            }
        }
    };

    bot.on('message', replyListener);
    
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi untuk update data IP - FUNGSI BARU
function updateIPData(oldIP, field, newValue) {
    try {
        let updated = false;
        
        // Update di ipx file
        if (fs.existsSync(IPX_FILE)) {
            let ipxContent = fs.readFileSync(IPX_FILE, 'utf8');
            const lines = ipxContent.split('\n');
            
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].includes(oldIP)) {
                    const parts = lines[i].split(' ').filter(part => part.trim() !== '');
                    if (parts.length >= 4) {
                        if (field === 'username') {
                            parts[1] = newValue;
                        } else if (field === 'ip') {
                            parts[3] = newValue;
                        } else if (field === 'expired') {
                            parts[2] = newValue;
                        }
                        
                        lines[i] = parts.join(' ');
                        updated = true;
                    }
                }
            }
            
            if (updated) {
                fs.writeFileSync(IPX_FILE, lines.join('\n'));
            }
        }
        
        // Update di ip file
        if (fs.existsSync(IP_FILE)) {
            let ipContent = fs.readFileSync(IP_FILE, 'utf8');
            const lines = ipContent.split('\n');
            
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].includes(oldIP)) {
                    const parts = lines[i].split(' ').filter(part => part.trim() !== '');
                    if (parts.length >= 4) {
                        if (field === 'username') {
                            parts[1] = newValue;
                        } else if (field === 'ip') {
                            parts[3] = newValue;
                        } else if (field === 'expired') {
                            parts[2] = newValue;
                        }
                        
                        lines[i] = parts.join(' ');
                        updated = true;
                    }
                }
            }
            
            if (updated) {
                fs.writeFileSync(IP_FILE, lines.join('\n'));
            }
        }
        
        return updated;
    } catch (error) {
        console.error('❌ Update IP Data Error:', error);
        return false;
    }
}

// Handler untuk callback verify membership
async function handleVerifyMembership(chatId, user, messageId = null) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '🔍 Memverifikasi keanggotaan...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const membership = await checkMembership(chatId, user.id);
        
        if (membership.success) {
            // Verifikasi berhasil
            await bot.editMessageText('✅ <b>Verifikasi Berhasil!</b>\n\nSelamat! Anda sudah bergabung dengan grup dan channel yang diperlukan. Sekarang Anda dapat mengakses semua fitur bot.', {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🚀 Mulai Menggunakan Bot', callback_data: 'main_menu' }]
                    ]
                }
            });
            
            console.log(`✅ User ${user.id} berhasil verifikasi keanggotaan`);
        } else {
            // Verifikasi gagal
            await bot.editMessageText('❌ <b>Verifikasi Gagal!</b>\n\nAnda belum bergabung dengan grup dan channel yang diperlukan:', {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML'
            });
            
            // Tampilkan kembali menu verifikasi
            showMembershipVerification(chatId, user, membership.results);
        }
    } catch (error) {
        console.error('❌ Verify Membership Error:', error);
        await bot.editMessageText('❌ Gagal memverifikasi keanggotaan. Silakan coba lagi.', {
            chat_id: chatId,
            message_id: loadingMsg.message_id
        });
    }
}

// Handler untuk admin bypass membership
async function handleAdminBypassMembership(chatId, user, messageId = null) {
    if (!isAdmin(user.id.toString())) {
        await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa menggunakan fitur ini.').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
        return;
    }
    
    console.log(`👑 Admin ${user.id} menggunakan bypass membership`);
    showMainMenu(chatId, user, messageId);
}

// Handler untuk message text - TAMBAHAN BARU UNTUK CONVERT XRAY
bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const user = msg.from;
    const messageText = msg.text;

    // Skip jika bukan text message atau dari bot
    if (!messageText || msg.from.is_bot) return;

    try {
        // Cek apakah user sedang dalam state convert xray
        const isXrayProcessing = await handleXrayConfig(chatId, messageText, user, bot, userMessages);
        
        // Jika sedang proses convert xray, tidak perlu proses lebih lanjut
        if (isXrayProcessing) return;
        
        // Tambahkan handler lain di sini jika diperlukan
        
    } catch (error) {
        console.error('❌ Message Handler Error:', error);
    }
});

// Handle callback queries (button clicks) - DITAMBAH HANDLER WILDCARD DAN MEMBERSHIP
bot.on('callback_query', async (callbackQuery) => {
    const message = callbackQuery.message;
    const chatId = message.chat.id;
    const user = callbackQuery.from;
    const data = callbackQuery.data;

    await bot.answerCallbackQuery(callbackQuery.id);

    // Ambil messageId dengan aman (undefined jika tidak ada)
    const messageId = message ? message.message_id : null;

    // Dalam callback handler, tambahkan case ini:
if (data === 'tools_menu') {
    await showToolsMenu(chatId, user, messageId);
    return;
}

    // Routing tombol
    if (data === 'izin_ip_menu') {
        return showIzinIpMenu(chatId, messageId);
    }

    if (data === 'main_menu') {
        return showMainMenu(chatId, user, messageId);
    }

    // TAMBAHAN: Handler untuk bash encrypt menu
    if (data === 'bash_encrypt_menu') {
        await handleBashEncryptMenu(chatId, user, messageId);
        return;
    }

    // Dalam callback handler, tambahkan case ini:
    if (data === 'upload_config_menu') {
        await handleUploadConfig(chatId, user, messageId);
        return;
    }

    // TAMBAHAN: Handler untuk verifikasi membership
    if (data === 'verify_membership') {
        await handleVerifyMembership(chatId, user, messageId);
        return;
    }

    // TAMBAHAN: Handler untuk admin bypass membership
    if (data === 'admin_bypass_membership') {
        await handleAdminBypassMembership(chatId, user, messageId);
        return;
    }

    // ===============================
    // TAMBAHAN: HANDLER UNTUK EDIT DOMAIN
    // ===============================
    if (data.startsWith('pointing_edit')) {
        try {
            if (data === 'pointing_edit') {
                await pointingDomain.handleEditDomain(chatId, bot, messageId);
                return;
            }
            else if (data.startsWith('pointing_edit_page_')) {
                const page = parseInt(data.split('_')[3]);
                await pointingDomain.handleEditDomainPage(chatId, bot, page);
                return;
            }
            else if (data.startsWith('pointing_edit_select_')) {
                const recordId = data.split('_')[3];
                await pointingDomain.handleEditDomainSelection(chatId, recordId, bot);
                return;
            }
            else if (data === 'pointing_edit_name') {
                await pointingDomain.handleEditDomainName(chatId, bot);
                return;
            }
            else if (data === 'pointing_edit_ip') {
                await pointingDomain.handleEditIP(chatId, bot);
                return;
            }
            else if (data === 'pointing_edit_proxy') {
                await pointingDomain.handleToggleProxy(chatId, bot);
                return;
            }
            else if (data === 'pointing_edit_type') {
                await pointingDomain.handleEditType(chatId, bot);
                return;
            }
            else if (data === 'pointing_edit_type_A') {
                await pointingDomain.handleEditTypeSelection(chatId, 'A', bot);
                return;
            }
            else if (data === 'pointing_edit_type_CNAME') {
                await pointingDomain.handleEditTypeSelection(chatId, 'CNAME', bot);
                return;
            }
            else if (data === 'pointing_edit_options') {
                await pointingDomain.handleBackToEditOptions(chatId, bot);
                return;
            }
        } catch (error) {
            console.error('❌ Edit Domain Callback Error:', error);
            await bot.sendMessage(chatId, '❌ Terjadi error saat memproses edit domain').then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
        }
        return;
    }

    try {
        // Hapus pesan aksi sebelumnya sebelum memproses aksi baru
        await cleanupOldMessages(chatId, true);

        // TAMBAHAN: Handler untuk edit IP callbacks
        if (data.startsWith('edit_ip_')) {
            if (data.startsWith('edit_ip_select_')) {
                const ipToEdit = data.replace('edit_ip_select_', '');
                await handleEditIPSelection(chatId, ipToEdit);
            }
            else if (data.startsWith('edit_ip_username_')) {
                const ipToEdit = data.replace('edit_ip_username_', '');
                await handleEditUsername(chatId, ipToEdit);
            }
            else if (data.startsWith('edit_ip_address_')) {
                const ipToEdit = data.replace('edit_ip_address_', '');
                await handleEditIPAddress(chatId, ipToEdit);
            }
            else if (data.startsWith('edit_ip_expired_')) {
                const ipToEdit = data.replace('edit_ip_expired_', '');
                await handleEditExpired(chatId, ipToEdit);
            }
            else {
                await bot.sendMessage(chatId, '❌ Aksi edit IP tidak dikenali').then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
            return; // Penting: return setelah handle edit IP callback
        }

        // TAMBAHAN: Handler untuk bash encrypt callbacks
        if (data.startsWith('bash_')) {
            switch (data) {
                case 'bash_encrypt':
                    await handleBashEncrypt(chatId);
                    break;
                case 'bash_decrypt':
                    await handleBashDecrypt(chatId);
                    break;
                case 'bash_upload':
                    await handleBashEncrypt(chatId); // Reuse encrypt handler for upload
                    break;
                case 'bash_check_deps':
                    await handleBashCheckDeps(chatId);
                    break;
                case 'bash_install_deps':
                    await handleBashInstallDeps(chatId);
                    break;
                default:
                    await bot.sendMessage(chatId, '❌ Aksi bash encrypt tidak dikenali').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
            }
            return;
        }

        // Dalam callback handler, tambahkan case untuk delete config
        if (data.startsWith('config_')) {
            switch (data) {
                case 'config_upload':
                    await handleConfigUpload(chatId, user);
                    break;
                case 'config_list':
                    await handleConfigList(chatId);
                    break;
                case 'config_download_menu':
                    await handleConfigDownloadMenu(chatId);
                    break;
                case 'config_refresh':
                    await handleConfigRefresh(chatId);
                    break;
                case 'config_delete': // TAMBAHAN BARU
                    await handleConfigDelete(chatId, user);
                    break;
                default:
                    if (data.startsWith('config_download_')) {
                        const fileName = data.replace('config_download_', '');
                        await handleConfigDownload(chatId, fileName);
                    }
                    else if (data.startsWith('config_list_page_')) {
                        const pageNum = parseInt(data.replace('config_list_page_', ''));
                        await handleConfigList(chatId, pageNum);
                    }
                    else if (data.startsWith('config_delete_page_')) { // TAMBAHAN BARU
                        const pageNum = parseInt(data.replace('config_delete_page_', ''));
                        await showConfigDeleteList(chatId, pageNum);
                    }
                    else if (data.startsWith('config_delete_confirm_')) { // TAMBAHAN BARU
                        const fileName = data.replace('config_delete_confirm_', '');
                        await handleConfigDeleteConfirm(chatId, fileName);
                    }
                    else if (data.startsWith('config_delete_execute_')) { // TAMBAHAN BARU
                        const fileName = data.replace('config_delete_execute_', '');
                        await handleConfigDeleteExecute(chatId, fileName);
                    }
            }
            return;
        }

        // HANDLER POINTING DOMAIN - PERBAIKI UNTUK MENERUSKAN MESSAGE ID
        if (data.startsWith('pointing_')) {
            try {
                // Handle pointing domain callbacks dengan routing yang benar
                if (data === 'pointing_domain') {
                    await pointingDomain.showMenu(chatId, user, bot, messageId);
                }
                else if (data === 'pointing_setup') {
                    await pointingDomain.handleSetupCloudflare(chatId, user, bot, messageId);
                }
                else if (data === 'pointing_list') {
                    await pointingDomain.handleListDomains(chatId, bot, 0, messageId);
                }
                else if (data === 'pointing_add') {
                    await pointingDomain.handleAddDomain(chatId, user, bot, messageId);
                }
                else if (data === 'pointing_delete') {
                    await pointingDomain.handleOptimizedDeleteDomain(chatId, bot, messageId);
                }
                // TAMBAHAN: Handler untuk edit domain
                else if (data === 'pointing_edit') {
                    await pointingDomain.handleEditDomain(chatId, bot, messageId);
                }
                else if (data === 'pointing_wildcard') {
                    await pointingDomain.handleAutoWildcard(chatId, bot, messageId);
                }
                else if (data === 'pointing_confirm_add') {
                    await pointingDomain.handleConfirmAddDomain(chatId, bot);
                }
                else if (data === 'pointing_type_A' || data === 'pointing_type_CNAME') {
                    const recordType = data.replace('pointing_type_', '');
                    await pointingDomain.handleRecordTypeSelection(chatId, recordType, bot);
                }
                else if (data === 'pointing_proxied_true' || data === 'pointing_proxied_false') {
                    const proxiedStatus = data.replace('pointing_proxied_', '');
                    await pointingDomain.handleProxiedSelection(chatId, proxiedStatus, bot);
                }
                else if (data.startsWith('pointing_wildcard_setup')) {
                    await pointingDomain.setupWildcardDomain(chatId, bot);
                }
                else if (data.startsWith('pointing_wildcard_info')) {
                    await pointingDomain.showWildcardInfo(chatId, bot);
                }
                else if (data.startsWith('pointing_wildcard_script')) {
                    await handleWildcardScriptView(chatId, bot);
                }
                else if (data.startsWith('pointing_delete_')) {
                    const recordId = data.replace('pointing_delete_', '');
                    await pointingDomain.handleConfirmDeleteDomain(chatId, recordId, bot);
                }
                else if (data.startsWith('pointing_list_page_')) {
                    const pageNum = parseInt(data.replace('pointing_list_page_', ''));
                    await pointingDomain.handleListDomains(chatId, bot, pageNum);
                }
                else if (data.startsWith('pointing_delete_page_')) {
                    const pageNum = parseInt(data.replace('pointing_delete_page_', ''));
                    await pointingDomain.handleDeleteDomainPage(chatId, bot, pageNum);
                }
                // TAMBAHAN: Handler untuk pagination edit domain
                else if (data.startsWith('pointing_edit_page_')) {
                    const pageNum = parseInt(data.replace('pointing_edit_page_', ''));
                    await pointingDomain.handleEditDomainPage(chatId, bot, pageNum);
                }
                // TAMBAHAN: Handler untuk select domain untuk edit
                else if (data.startsWith('pointing_edit_select_')) {
                    const recordId = data.replace('pointing_edit_select_', '');
                    await pointingDomain.handleEditDomainSelection(chatId, recordId, bot);
                }
                else {
                    await bot.sendMessage(chatId, '❌ Aksi pointing tidak dikenali').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                return; // Penting: return setelah handle pointing callback
            } catch (error) {
                console.error('❌ Pointing Callback Error:', error);
                await bot.sendMessage(chatId, '❌ Terjadi error saat memproses pointing domain').then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }

        if (data.startsWith('xray_')) {
            try {
                const xrayModule = require('./convert-xray');
                await xrayModule.handleXrayCallback(chatId, data, user, bot, userMessages, messageId);
                return; // Penting: return setelah handle xray callback
            } catch (error) {
                console.error('❌ Xray Callback Error:', error);
                await bot.sendMessage(chatId, '❌ Terjadi error saat memproses convert Xray').then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }

        // HANDLER HARGA - TAMBAHKAN DI SINI SEBELUM SWITCH
        if (data.startsWith('price_')) {
            await handlePriceCallback(chatId, data, user);
            return; // Penting: return setelah handle price
        }

        switch (data) {
            // Dalam switch case - PASTIKAN ADA INI:
            case 'convert_xray':
                const xrayModule = require('./convert-xray');
                await xrayModule.showConvertXrayMenu(chatId, user, bot, userMessages, messageId);
                break;
            case 'show_prices': // TAMBAHAN BARU UNTUK MENU HARGA
                await showPriceMenu(chatId, user, messageId);
                break;
            case 'list_ip':
                await handleListIP(chatId, user);
                break;
            case 'check_github':
                await handleCheckGitHub(chatId, user);
                break;
            case 'add_ip':
                await handleAddIP(chatId, user);
                break;
            case 'edit_ip': // TAMBAHAN BARU: Handler untuk Edit IP
                await handleEditIP(chatId, user);
                break;
            case 'delete_ip':
                await handleDeleteIP(chatId, user);
                break;
            case 'renew_ip':
                await handleRenewIP(chatId, user);
                break;
            case 'sync_data':
                await handleSyncData(chatId);
                break;
            case 'refresh_bot':
                await handleRefreshBot(chatId, user);
                break;
            case 'help':
                await handleHelp(chatId, user, messageId);
                break;
            case 'pointing_domain':
                await pointingDomain.showMenu(chatId, user, bot);
                break;
            case 'pointing_edit': // TAMBAHAN: Handler untuk Edit Domain
                await pointingDomain.handleEditDomain(chatId, bot, messageId);
                break;
            case 'pointing_delete':
                await handleOptimizedDeleteDomain(chatId, bot);
                break;
            case 'check_bug':
                await handleCheckBug(chatId, user, messageId);
                break;
            case 'edit_password':
                if (isAdmin(user.id.toString())) {
                    await handleEditPassword(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            
            case 'main_menu':
                await cleanupOldMessages(chatId, false);
                showMainMenu(chatId, user);
                break;
            case 'admin_settings':
                if (isAdmin(user.id.toString())) {
                    await showAdminMenu(chatId, user, messageId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'edit_github_token':
                if (isAdmin(user.id.toString())) {
                    await handleEditGitHubToken(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'system_info':
                if (isAdmin(user.id.toString())) {
                    await handleSystemInfo(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'manage_users':
                if (isAdmin(user.id.toString())) {
                    await handleManageUsers(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            
            // GITHUB MANAGER CASES
            case 'github_manager':
                if (isAdmin(user.id.toString())) {
                    await showGitHubManagerMenu(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'github_upload':
                if (isAdmin(user.id.toString())) {
                    await handleGitHubUpload(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'github_list':
                if (isAdmin(user.id.toString())) {
                    await handleGitHubListFiles(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'github_delete':
                if (isAdmin(user.id.toString())) {
                    await handleGitHubDeleteFile(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
            case 'github_sync':
                if (isAdmin(user.id.toString())) {
                    await handleGitHubSync(chatId);
                } else {
                    await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengakses menu ini.').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
                break;
                
            case 'request_access':
                await handleRequestAccess(chatId, user);
                break;
                
            default:
                // Handle OS selection
                if (data.startsWith('add_ip_os_')) {
                    const selectedOS = data.replace('add_ip_os_', '');
                    await handleOSSelection(chatId, selectedOS, user);
                }
                // Handle delete IP selection
                else if (data.startsWith('delete_ip_')) {
                    const ipToDelete = data.replace('delete_ip_', '');
                    await handleDeleteIPSelection(chatId, ipToDelete, user);
                }
                // Handle renew IP selection
                else if (data.startsWith('renew_ip_')) {
                    const ipToRenew = data.replace('renew_ip_', '');
                    await handleRenewIPSelection(chatId, ipToRenew, user);
                }
                // Handle GitHub file selection untuk delete
                else if (data.startsWith('github_delete_')) {
                    const fileToDelete = data.replace('github_delete_', '');
                    await handleGitHubDeleteFileSelection(chatId, fileToDelete);
                }
                else {
                    await bot.sendMessage(chatId, '❌ Aksi tidak dikenali: ' + data).then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
        }
    } catch (error) {
        console.error('❌ Callback Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error, coba lagi nanti').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
});

// ===============================
// FUNGSI BAWAAN (TIDAK DIUBAH) - KECUALI LIST IP YANG SUDAH DIMODIFIKASI
// ===============================

// Handler untuk Check GitHub - DIMODIFIKASI: Hanya admin
async function handleCheckGitHub(chatId, user) {
    // Cek apakah user adalah admin
    if (!isAdmin(user.id.toString())) {
        await bot.sendMessage(chatId, '❌ Akses ditolak. Hanya admin yang bisa mengecek koneksi GitHub.', {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
        return;
    }

    try {
        const loadingMsg = await bot.sendMessage(chatId, '🌐 Memeriksa koneksi GitHub...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const result = await checkGitHubConnection();
        
        await bot.editMessageText(result.message, {
            chat_id: chatId,
            message_id: loadingMsg.message_id,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔑 Edit Token', callback_data: 'edit_github_token' }],
                    [{ text: '🔄 Test Lagi', callback_data: 'check_github' }],
                    [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                ]
            }
        });
    } catch (error) {
        console.error('❌ Check GitHub Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal memeriksa koneksi GitHub').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk Edit GitHub Token - FUNGSI BARU
async function handleEditGitHubToken(chatId) {
    const msg = await bot.sendMessage(chatId, '<b>🔑 Edit GitHub Token</b>\n\nToken saat ini: <code>' + GITHUB_TOKEN.substring(0, 8) + '...</code>\n\nMasukkan token GitHub baru:', {
        parse_mode: 'HTML',
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const newToken = replyMsg.text;
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            if (newToken && newToken.length > 10) {
                const success = updateEnvVariable('GITHUB_TOKEN', newToken);
                
                if (success) {
                    await bot.sendMessage(chatId, `✅ GitHub Token berhasil diupdate!\n\nToken baru: <code>${newToken.substring(0, 8)}...</code>\n\nKlik tombol di bawah untuk test koneksi:`, {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🌐 Test Koneksi', callback_data: 'check_github' }],
                                [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                            ]
                        }
                    }).then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                } else {
                    await bot.sendMessage(chatId, '❌ Gagal mengupdate GitHub Token').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                }
            } else {
                await bot.sendMessage(chatId, '❌ Token tidak valid. Pastikan token memiliki panjang yang cukup.').then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };

    // Tambahkan listener untuk message
    bot.on('message', replyListener);
    
    // Set timeout untuk menghapus listener setelah 2 menit
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Handler untuk System Info - FUNGSI BARU
async function handleSystemInfo(chatId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '📊 Mengambil informasi sistem...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        // Dapatkan info dasar
        const nodeVersion = process.version;
        const platform = process.platform;
        const arch = process.arch;
        const uptime = Math.floor(process.uptime() / 60) + ' menit';
        
        // Hitung jumlah IP
        const ips = readIPData();
        const activeIPs = ips.filter(ip => new Date(ip.expired) > new Date()).length;
        const expiredIPs = ips.length - activeIPs;
        
        const systemInfo = `
<b>📊 SYSTEM INFORMATION</b>

<b>Bot Info:</b>
🤖 <b>Node.js Version:</b> <code>${nodeVersion}</code>
💻 <b>Platform:</b> <code>${platform} ${arch}</code>
⏰ <b>Uptime:</b> <code>${uptime}</code>

<b>GitHub Info:</b>
👤 <b>User:</b> <code>${GITHUB_USER}</code>
🔑 <b>Token:</b> <code>${GITHUB_TOKEN.substring(0, 8)}...</code>
📁 <b>Repo:</b> <code>${GITHUB_REPO}</code>

<b>Data Info:</b>
📋 <b>Total IP:</b> <code>${ips.length}</code>
✅ <b>IP Aktif:</b> <code>${activeIPs}</code>
❌ <b>IP Expired:</b> <code>${expiredIPs}</code>

<b>Password Info:</b>
🔐 <b>Password Verifikasi:</b> <code>${ADMIN_PASSWORD}</code>

<b>Server Time:</b>
🕐 ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
        `;
        
        await bot.editMessageText(systemInfo, {
            chat_id: chatId,
            message_id: loadingMsg.message_id,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Refresh', callback_data: 'system_info' }],
                    [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                ]
            }
        });
    } catch (error) {
        console.error('❌ System Info Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal mengambil informasi sistem').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk Manage Users - FUNGSI BARU (placeholder)
async function handleManageUsers(chatId) {
    const usersData = loadAllowedUsers();
    const totalUsers = usersData.allowedUsers.length;
    const pendingRequests = usersData.pendingRequests.length;
    
    const usersInfo = `
<b>👥 USER MANAGEMENT</b>

📊 <b>Statistik:</b>
✅ <b>Total Allowed Users:</b> <code>${totalUsers}</code>
📩 <b>Pending Requests:</b> <code>${pendingRequests}</code>

⚠️ <b>Fitur dalam pengembangan</b>
Fitur manajemen user lengkap akan segera hadir!
    `;
    
    await bot.sendMessage(chatId, usersInfo, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
            ]
        }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// Handler untuk Sync Data
async function handleSyncData(chatId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '🔄 Menyinkronisasi data dengan GitHub...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const success = await loadDataFromGitHub();
        
        if (success) {
            await bot.editMessageText('✅ Data berhasil disinkronisasi dari GitHub', {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📋 Lihat Data', callback_data: 'list_ip' }],
                        [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                    ]
                }
            });
        } else {
            await bot.editMessageText('❌ Gagal menyinkronisasi data', {
                chat_id: chatId,
                message_id: loadingMsg.message_id
            });
        }
    } catch (error) {
        console.error('❌ Sync Data Error:', error);
        await bot.sendMessage(chatId, '❌ Gagal menyinkronisasi data').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk Refresh Bot - DIPERBAIKI: Loading lebih cepat
async function handleRefreshBot(chatId, user) {
    try {
        // Hapus semua pesan lama
        await cleanupOldMessages(chatId, false);
        
        // Kirim pesan loading dengan spinner
        let loadingMsg = await bot.sendMessage(chatId, '🔄 Merefresh bot...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        // Animasi spinner yang lebih cepat
        const spinnerFrames = ['🔄', '⏳', '⌛'];
        let spinnerIndex = 0;
        
        const spinnerInterval = setInterval(async () => {
            try {
                spinnerIndex = (spinnerIndex + 1) % spinnerFrames.length;
                await bot.editMessageText(`${spinnerFrames[spinnerIndex]} Merefresh bot...`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id
                });
            } catch (error) {
                // Ignore edit errors
            }
        }, 300); // Lebih cepat: 300ms
        
        // Hapus state yang aktif
        addIPState.delete(chatId);
        
        // Reload data dari GitHub (tanpa sync untuk mempercepat)
        try {
            if (fs.existsSync(IPX_FILE) && fs.existsSync(IP_FILE)) {
                // Langsung baca dari file lokal tanpa sync GitHub
                console.log('🔄 Refresh: Menggunakan data lokal');
            } else {
                await loadDataFromGitHub();
            }
        } catch (error) {
            console.error('❌ Refresh data error:', error);
        }
        
        // Hentikan animasi spinner
        clearInterval(spinnerInterval);
        
        // Update pesan menjadi sukses dengan centang
        await bot.editMessageText('✅ Bot berhasil di-refresh!', {
            chat_id: chatId,
            message_id: loadingMsg.message_id
        });
        
        // Tunggu sebentar sebelum kembali ke menu (lebih cepat)
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Hapus pesan loading
        await bot.deleteMessage(chatId, loadingMsg.message_id);
        
        // Langsung kembali ke menu utama
        await showMainMenu(chatId, user);
        
        console.log(`🔄 Bot di-refresh oleh user ${user.id} (${formatUserName(user)})`);
        
    } catch (error) {
        console.error('❌ Refresh Bot Error:', error);
        // Hentikan spinner jika error
        if (spinnerInterval) clearInterval(spinnerInterval);
        
        await bot.sendMessage(chatId, '❌ Gagal merefresh bot', {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                ]
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk Add IP - DIMODIFIKASI: Semua user wajib verifikasi password
async function handleAddIP(chatId, user) {
    await askForPassword(chatId, 'add_ip', user);
}

// Handler untuk Delete IP - DIMODIFIKASI: Semua user wajib verifikasi password
async function handleDeleteIP(chatId, user) {
    await askForPassword(chatId, 'delete_ip', user);
}

// Handler untuk Renew IP - DIMODIFIKASI: Semua user wajib verifikasi password
async function handleRenewIP(chatId, user) {
    await askForPassword(chatId, 'renew_ip', user);
}

// Handler untuk Help
async function handleHelp(chatId, user, messageId = null) {
    // Hapus menu utama jika messageId valid
    if (messageId) {
        bot.deleteMessage(chatId, messageId).catch(() => {});
    }

    const helpText = `
<b>🆘 Bantuan VPS Manager Bot</b>

👋 Halo, <b>${formatUserName(user)}</b>!
🆔 ID Telegram: <code>${user.id}</code>
👤 Status: <b>${isAdmin(user.id.toString()) ? 'ADMIN 👑' : 'USER 👤'}</b>

<b>Cara Penggunaan:</b>
1. Gunakan button untuk memilih aksi
2. Untuk semua fitur (List, Add, Delete, Renew IP) wajib verifikasi password
3. Data otomatis tersinkronisasi dengan GitHub

<b>Fitur User:</b>
• <b>LIST IP</b> - Lihat semua IP VPS yang terdaftar (wajib password)
• <b>CEK BUG</b> - Cek status bug tunneling dengan deteksi service
• <b>CONVERT XRAY</b> - Konversi konfigurasi Xray/V2Ray/Trojan ke YAML
• <b>REFRESH BOT</b> - Refresh bot dan reset state

<b>Fitur dengan Password:</b>
• <b>LIST IP</b> - Lihat daftar IP VPS (wajib password)
• <b>ADD IP</b> - Tambah IP baru (wajib password)
• <b>DELETE IP</b> - Hapus IP (wajib password)
• <b>RENEW IP</b> - Perpanjang masa aktif IP (wajib password)

<b>Fitur Admin Only:</b>
• <b>EDIT PASSWORD</b> - Ubah password verifikasi
• <b>CHECK GITHUB</b> - Test koneksi ke repository GitHub
• <b>EDIT GITHUB TOKEN</b> - Update token GitHub
• <b>SYSTEM INFO</b> - Informasi sistem bot
• <b>GITHUB MANAGER</b> - Kelola file di repository GitHub

<b>🐛 FITUR CEK BUG TUNNELING:</b>
• Deteksi HTTP/HTTPS Web Server
• Deteksi SSH Server
• Deteksi Xray/V2Ray VPN
• Deteksi Trojan VPN
• Deteksi mode tunneling yang aktif

<b>⚡ FITUR CONVERT XRAY:</b>
• Konversi VMess/VLESS/Trojan link ke YAML
• Konversi JSON config ke format Clash/Shadowrocket
• Support V2Ray, VLESS, VMess, Trojan protocols
• Generate file YAML siap pakai

<b>Sistem Keamanan:</b>
- Semua aksi memerlukan verifikasi password
- Password dapat diubah oleh admin
- Data tersinkronisasi otomatis dengan GitHub
- Fitur GitHub hanya untuk admin

👨‍💻 <b>Developer:</b> <b>PeyxDev</b>
    `;

    await bot.sendMessage(chatId, helpText, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
            ]
        }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// Variabel global untuk menyimpan state proses add IP
const addIPState = new Map();

// Fungsi untuk meminta password (untuk semua user) - DIPERBAIKI: Konfirmasi lebih jelas
async function askForPassword(chatId, action, user) {
    console.log(`🔐 Meminta password untuk action: ${action}, chatId: ${chatId}, user: ${user.id}`);
    
    const msg = await bot.sendMessage(chatId, '<b>🔐 Verifikasi Password</b>\n\nMasukkan password untuk melanjutkan:', {
        parse_mode: 'HTML',
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const password = replyMsg.text;
            console.log(`🔑 Password diterima: ${password}`);
            
            // Hapus listener setelah digunakan
            bot.removeListener('message', replyListener);
            
            if (password === ADMIN_PASSWORD) {
                console.log('✅ Password benar, melanjutkan proses...');
                
                // Konfirmasi password benar dengan loading cepat
                const successMsg = await bot.sendMessage(chatId, '✅ Password benar! Memproses...');
                addTempMessage(chatId, successMsg.message_id);
                
                // Hapus pesan konfirmasi setelah 1 detik
                setTimeout(async () => {
                    try {
                        await bot.deleteMessage(chatId, successMsg.message_id);
                    } catch (error) {
                        // Ignore delete errors
                    }
                }, 1000);
                
                switch (action) {
                    case 'add_ip':
                        await startAddIPProcess(chatId, user);
                        break;
                    case 'delete_ip':
                        await startDeleteIPProcess(chatId);
                        break;
                    case 'renew_ip':
                        await startRenewIPProcess(chatId);
                        break;
                    case 'list_ip':
                        await showIPList(chatId);
                        break;
                    case 'edit_ip': // TAMBAHAN BARU
                        await startEditIPProcess(chatId);
                        break;
                }
            } else {
                console.log('❌ Password salah');
                await bot.sendMessage(chatId, '❌ Password salah! Akses ditolak.', {
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }).then(msg => {
                    saveActionMessage(chatId, msg.message_id);
                });
            }
        }
    };

    // Tambahkan listener untuk message
    bot.on('message', replyListener);
    
    // Set timeout untuk menghapus listener setelah 2 menit
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Proses Add IP - DIPERBAIKI: Loading lebih cepat
async function startAddIPProcess(chatId, user) {
    console.log('➕ Memulai proses add IP untuk chatId:', chatId);
    
    try {
        // Inisialisasi state untuk chat ini
        addIPState.set(chatId, {
            step: 'ip',
            data: {},
            userId: user.id.toString(),
            isAdmin: isAdmin(user.id.toString())
        });

        await askForIPAddress(chatId);
    } catch (error) {
        console.error('❌ Start Add IP Process Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memulai proses tambah IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Fungsi untuk meminta IP Address
async function askForIPAddress(chatId) {
    const state = addIPState.get(chatId);
    state.step = 'ip';
    
    const msg = await bot.sendMessage(chatId, '<b>➕ Tambah IP VPS</b>\n\nMasukkan IP Address:', {
        parse_mode: 'HTML',
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const ipAddress = replyMsg.text;
            
            // Hapus listener
            bot.removeListener('message', replyListener);
            
            console.log('🌐 IP Address diterima:', ipAddress);
            state.data.ip = ipAddress;
            addIPState.set(chatId, state);
            
            await askForUsername(chatId);
        }
    };

    bot.on('message', replyListener);
    
    // Timeout
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi untuk meminta Username
async function askForUsername(chatId) {
    const state = addIPState.get(chatId);
    state.step = 'username';
    
    const msg = await bot.sendMessage(chatId, 'Masukkan Username:', {
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const username = replyMsg.text;
            
            // Hapus listener
            bot.removeListener('message', replyListener);
            
            console.log('👤 Username diterima:', username);
            state.data.username = username;
            addIPState.set(chatId, state);
            
            await askForDays(chatId);
        }
    };

    bot.on('message', replyListener);
    
    // Timeout
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi untuk meminta Days
async function askForDays(chatId) {
    const state = addIPState.get(chatId);
    state.step = 'days';
    
    const msg = await bot.sendMessage(chatId, 'Masukkan masa aktif (hari):', {
        reply_markup: { force_reply: true }
    });

    saveActionMessage(chatId, msg.message_id);

    const replyListener = async (replyMsg) => {
        if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
            const days = replyMsg.text;
            
            // Hapus listener
            bot.removeListener('message', replyListener);
            
            console.log('⏰ Days diterima:', days);
            state.data.days = days;
            addIPState.set(chatId, state);
            
            await askForOS(chatId);
        }
    };

    bot.on('message', replyListener);
    
    // Timeout
    setTimeout(() => {
        bot.removeListener('message', replyListener);
    }, 120000);
}

// Fungsi untuk meminta OS
async function askForOS(chatId) {
    const state = addIPState.get(chatId);
    state.step = 'os';
    
    const msg = await bot.sendMessage(chatId, 'Pilih OS VPS:', {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '🟠 Ubuntu', callback_data: 'add_ip_os_ubuntu' }
                ],
                [
                    { text: '🔴 Debian', callback_data: 'add_ip_os_debian' }
                ]
            ]
        }
    });

    saveActionMessage(chatId, msg.message_id);
}

// Handler untuk OS selection - DIPERBAIKI: Loading lebih cepat
async function handleOSSelection(chatId, osType, user) {
    console.log('🐧 OS dipilih:', osType, 'untuk chatId:', chatId);
    
    const state = addIPState.get(chatId);
    if (!state) {
        await bot.sendMessage(chatId, '❌ Sesi telah berakhir. Silakan mulai ulang.').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
        return;
    }
    
    state.data.os = osType;
    
    const loadingMsg = await bot.sendMessage(chatId, '⏳ Menambahkan IP VPS...');
    saveActionMessage(chatId, loadingMsg.message_id);
    
    try {
        const { ip, username, days, os } = state.data;
        const userId = state.userId;
        
        console.log('📝 Data untuk add IP:', { ip, username, days, os, userId });
        
        const expiredDate = addIP(username, ip, days);
        const saved = await saveDataToGitHub(`Add IP ${ip} oleh ${userId}`);
        
        if (saved) {
            // Hapus state
            addIPState.delete(chatId);
            
            // Kirim konfirmasi sukses
            await bot.editMessageText(`<b>✅ IP VPS Berhasil Ditambahkan!</b>\n\n📝 <b>Username:</b> ${username}\n🌐 <b>IP:</b> ${ip}\n📅 <b>Expired:</b> ${expiredDate}\n⏰ <b>Masa Aktif:</b> ${days} hari\n🐧 <b>OS:</b> ${os === 'ubuntu' ? 'Ubuntu' : 'Debian'}`, {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML'
            });

            // Kirim script install
            const installScript = generateInstallScript(os, ip, username);
            await bot.sendMessage(chatId, installScript, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📋 Lihat Semua IP', callback_data: 'list_ip' }],
                        [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                    ]
                }
            }).then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
            
            console.log(`✅ IP ${ip} berhasil ditambahkan oleh user ${userId}`);
        } else {
            throw new Error('Gagal menyimpan ke GitHub');
        }
    } catch (error) {
        console.error('❌ Add IP Error:', error);
        await bot.editMessageText('❌ Gagal menambahkan IP VPS', {
            chat_id: chatId,
            message_id: loadingMsg.message_id
        });
        
        // Hapus state jika error
        addIPState.delete(chatId);
    }
}

// Proses Delete IP - DIPERBAIKI: Loading lebih cepat
async function startDeleteIPProcess(chatId) {
    console.log('🗑️ Memulai proses delete IP untuk chatId:', chatId);
    
    try {
        // Load data terbaru dari GitHub
        const loadingMsg = await bot.sendMessage(chatId, '📋 Mengambil data IP...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        await loadDataFromGitHub();
        
        const ips = readIPData();
        
        await bot.deleteMessage(chatId, loadingMsg.message_id);
        
        if (ips.length === 0) {
            await bot.sendMessage(chatId, '❌ Tidak ada IP VPS yang bisa dihapus').then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
            return;
        }
        
        // Buat keyboard dengan daftar IP
        const keyboard = [];
        ips.forEach(ipData => {
            keyboard.push([{ 
                text: `🗑️ ${ipData.ip} (${ipData.username})`, 
                callback_data: `delete_ip_${ipData.ip}` 
            }]);
        });
        
        keyboard.push([{ text: '❌ Batal', callback_data: 'main_menu' }]);
        
        await bot.sendMessage(chatId, '🗑️ <b>Hapus IP VPS</b>\n\nPilih IP yang ingin dihapus:', {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    } catch (error) {
        console.error('❌ Start Delete IP Process Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memulai proses hapus IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk delete IP selection - DIPERBAIKI: Loading lebih cepat
async function handleDeleteIPSelection(chatId, ipToDelete, user) {
    try {
        const loadingMsg = await bot.sendMessage(chatId, '⏳ Menghapus IP VPS...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        const deleted = deleteIP(ipToDelete);
        
        if (deleted) {
            const saved = await saveDataToGitHub(`Delete IP ${ipToDelete} oleh ${user.id}`);
            
            if (saved) {
                await bot.editMessageText(`<b>✅ IP VPS Berhasil Dihapus!</b>\n\n🌐 <b>IP:</b> ${ipToDelete}`, {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📋 Lihat Data', callback_data: 'list_ip' }],
                            [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                });
                
                console.log(`✅ IP ${ipToDelete} berhasil dihapus oleh user ${user.id}`);
            } else {
                throw new Error('Gagal menyimpan ke GitHub');
            }
        } else {
            await bot.editMessageText('❌ IP tidak ditemukan', {
                chat_id: chatId,
                message_id: loadingMsg.message_id
            });
        }
    } catch (error) {
        console.error('❌ Delete IP Error:', error);
        await bot.editMessageText('❌ Gagal menghapus IP VPS', {
            chat_id: chatId,
            message_id: loadingMsg.message_id
        });
    }
}

// Proses Renew IP - DIPERBAIKI: Loading lebih cepat dan fix callback
async function startRenewIPProcess(chatId) {
    console.log('🔄 Memulai proses renew IP untuk chatId:', chatId);
    
    try {
        // Load data terbaru dari GitHub
        const loadingMsg = await bot.sendMessage(chatId, '📋 Mengambil data IP...');
        saveActionMessage(chatId, loadingMsg.message_id);
        
        await loadDataFromGitHub();
        
        const ips = readIPData();
        
        await bot.deleteMessage(chatId, loadingMsg.message_id);
        
        if (ips.length === 0) {
            await bot.sendMessage(chatId, '❌ Tidak ada IP VPS yang bisa diperpanjang').then(msg => {
                saveActionMessage(chatId, msg.message_id);
            });
            return;
        }
        
        // Buat keyboard dengan daftar IP
        const keyboard = [];
        ips.forEach(ipData => {
            keyboard.push([{ 
                text: `🔄 ${ipData.ip} (${ipData.username} - ${ipData.expired})`, 
                callback_data: `renew_ip_${ipData.ip}` 
            }]);
        });
        
        keyboard.push([{ text: '❌ Batal', callback_data: 'main_menu' }]);
        
        await bot.sendMessage(chatId, '🔄 <b>Perpanjang IP VPS</b>\n\nPilih IP yang ingin diperpanjang:', {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        }).then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    } catch (error) {
        console.error('❌ Start Renew IP Process Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memulai proses perpanjang IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk renew IP selection - FUNGSI BARU YANG DIPERBAIKI
async function handleRenewIPSelection(chatId, ipToRenew, user) {
    try {
        // Minta jumlah hari tambahan
        const msg = await bot.sendMessage(chatId, `🔄 <b>Perpanjang IP: ${ipToRenew}</b>\n\nMasukkan jumlah hari tambahan:`, {
            parse_mode: 'HTML',
            reply_markup: { force_reply: true }
        });

        saveActionMessage(chatId, msg.message_id);

        const replyListener = async (replyMsg) => {
            if (replyMsg.reply_to_message && replyMsg.reply_to_message.message_id === msg.message_id) {
                const additionalDays = replyMsg.text;
                
                // Hapus listener
                bot.removeListener('message', replyListener);
                
                // Validasi input
                if (isNaN(additionalDays) || parseInt(additionalDays) <= 0) {
                    await bot.sendMessage(chatId, '❌ Jumlah hari harus angka positif!').then(msg => {
                        saveActionMessage(chatId, msg.message_id);
                    });
                    return;
                }

                const loadingMsg = await bot.sendMessage(chatId, '⏳ Memperpanjang IP VPS...');
                saveActionMessage(chatId, loadingMsg.message_id);
                
                try {
                    const renewed = renewIP(ipToRenew, additionalDays);
                    
                    if (renewed) {
                        const saved = await saveDataToGitHub(`Renew IP ${ipToRenew} +${additionalDays} hari oleh ${user.id}`);
                        
                        if (saved) {
                            // Dapatkan data IP yang diperbarui untuk menampilkan expired baru
                            await loadDataFromGitHub();
                            const ips = readIPData();
                            const renewedIP = ips.find(ip => ip.ip === ipToRenew);
                            
                            let successMessage = `<b>✅ IP VPS Berhasil Diperpanjang!</b>\n\n🌐 <b>IP:</b> ${ipToRenew}\n⏰ <b>Tambahan:</b> ${additionalDays} hari`;
                            
                            if (renewedIP) {
                                successMessage += `\n📅 <b>Expired Baru:</b> ${renewedIP.expired}`;
                            }
                            
                            await bot.editMessageText(successMessage, {
                                chat_id: chatId,
                                message_id: loadingMsg.message_id,
                                parse_mode: 'HTML',
                                reply_markup: {
                                    inline_keyboard: [
                                        [{ text: '📋 Lihat Data', callback_data: 'list_ip' }],
                                        [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
                                    ]
                                }
                            });
                            
                            console.log(`✅ IP ${ipToRenew} berhasil diperpanjang ${additionalDays} hari oleh user ${user.id}`);
                        } else {
                            throw new Error('Gagal menyimpan ke GitHub');
                        }
                    } else {
                        await bot.editMessageText('❌ IP tidak ditemukan', {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id
                        });
                    }
                } catch (error) {
                    console.error('❌ Renew IP Error:', error);
                    await bot.editMessageText('❌ Gagal memperpanjang IP VPS', {
                        chat_id: chatId,
                        message_id: loadingMsg.message_id
                    });
                }
            }
        };

        bot.on('message', replyListener);
        
        // Timeout
        setTimeout(() => {
            bot.removeListener('message', replyListener);
        }, 120000);
        
    } catch (error) {
        console.error('❌ Renew IP Selection Error:', error);
        await bot.sendMessage(chatId, '❌ Terjadi error saat memproses perpanjang IP').then(msg => {
            saveActionMessage(chatId, msg.message_id);
        });
    }
}

// Handler untuk request access (jika diperlukan)
async function handleRequestAccess(chatId, user) {
    const usersData = loadAllowedUsers();
    const userName = formatUserName(user);
    
    // Tambah ke pending requests
    usersData.pendingRequests.push({
        userId: user.id.toString(),
        userName: userName,
        timestamp: Date.now()
    });
    
    saveAllowedUsers(usersData);
    
    // Kirim notifikasi ke admin
    const adminMessage = `📩 <b>Request Akses Baru</b>\n\n👤 <b>User:</b> ${userName}\n🆔 <b>ID:</b> <code>${user.id}</code>\n⏰ <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}`;
    
    await bot.sendMessage(ADMIN_CHAT_ID, adminMessage, {
        parse_mode: 'HTML'
    });
    
    await bot.sendMessage(chatId, '✅ Request akses telah dikirim ke admin. Tunggu konfirmasi.', {
        reply_markup: {
            inline_keyboard: [
                [{ text: '📊 Menu Utama', callback_data: 'main_menu' }]
            ]
        }
    }).then(msg => {
        saveActionMessage(chatId, msg.message_id);
    });
}

// Error handling
bot.on('error', (error) => {
    console.error('❌ Bot Error:', error);
});

bot.on('polling_error', (error) => {
    console.error('❌ Polling Error:', error);
});

console.log('✅ Bot berhasil diinisialisasi');